/**
 * @brief Модуль обработки сигналов
 */

const {
    SELFTEST_MODE,
    AUTHORIZATION_MODE,
    DEVICE_SELECTION_MODE,
    LOADING_MODE,    
    CELL_STATUS_SERIAL_WAITING,
    CELL_STATUS_START_RUNNING_WAITING,
    CELL_STATUS_READY,
    ENTER_STANDBY_MODE,
    DOOR_CLOSING_WAITING_MODE,
    STANDBY_CHECKUP_MODE,
    IR_CHECKUP_BEFORE_RUNNING_MODE,
    LOWFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE,
    HIGHFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE,
    SOUND_ALARM_CHECKUP_BEFORE_RUNNING_MODE,
    RUNNING_MODE,
    CHECKUP_IR_AFTER_RUNNING_MODE,
    LOWFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE,
    HIGHFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE,
    SOUND_ALARM_CHECKUP_AFTER_RUNNING_MODE,
    REPORT_PREPARING_MODE,
    REPORT_MODE,
    UNLOADING_GOOD_MODE,
    UNLOADING_BAD_MODE,
    UNLOADING_UNKNOWN_MODE,
    IDLE_MODE,
    UNLOADING_BAD_DEVICES,
    UNLOADING_UNKNOWN_DEVICES,
    UNLOADING_GOOD_DEVICES,
    LOADING_MODE_NEXT_CELL_SIGNAL,
    LOADING_MODE_PREV_CELL_SIGNAL,
    LOADING_MODE_GOTO_CELL_SIGNAL,
    SCREEN_KEYBOARD_BARCODE_SIGNAL
} = require("./model_constants.js");

const {
    getData,
    getBenchStatus,
    synchronizeCell,
    synchronizePC,
    getOperatorDataFromDB
} = require("./REST.js");

const {
    goToCell
} =  require("./loading_mode.js");

const {
    ResultObject
} =  require("./ResultObject.js");

const{
    CheckUpResultObject
} = require("./CheckUpResultObject.js");


const {
    logger,
    saveLogsToDB,
    clearLogsArray,
    errorCodeToString   
} = require("./logger.js");


const {
    convertCurrent,
    } = require("./convertations.js");




//===========================================================================================================
    /**
     * @brief 
     * Создание массива состояния ячеек
     * 
    */
const generateCellSConditionArray = (glVars) => {
    glVars.cellsCondArray.length = 0;  // удаляем все элементы
    for (let i = 0; i < glVars.NUM_CELLS; i++){        
        glVars.cellsCondArray.push(
            {
                serial: "", 
                line_12V: 0, 
                current_mA: 0, 
                redLED: 0, 
                greenLED: 0,
                LED_flash_period: 0
            });
    }   
}


//=======================================================================================================
/**
 * @brief Конвертирует время в секундах в строку вида "0:00:00"
 * @param seconds - время в секундах
 * @return строка времени вида "0:00:00"
 */
const convertSecondsToTimeString = (seconds) => {
    let hours = Math.trunc(seconds/3600);
    let minutes = Math.trunc((seconds - hours*3600)/60);
    let left_sec = seconds - hours*3600 - minutes*60;
    let timeString = "" + hours + ":";
    timeString = (minutes < 10) ? (timeString + "0" + minutes): (timeString + minutes);
    timeString += ":";
    timeString = (left_sec < 10) ? (timeString + "0" + left_sec): (timeString + left_sec);
    return timeString;
}


//===========================================================================================================
/**
 * @brief Проверка наличия номера в массиве
 * @param faultyCellsNumArray - массив номеров неисправных ячеек
 * @return true - если номер есть в массиве, false - если нет
 */
const numberInArray = (numCell, faultyCellsNumArray) => {
    for (let i = 0; i < faultyCellsNumArray.length;i++){
        if (faultyCellsNumArray[i] === numCell) return true;
    }
    return false;
}

//===========================================================================================================
    /**
     * @brief  Выполнение самотестирования
     * 
     * 
    */

const performSelfTest = (benchStatusData, glVars) => {
    benchStatusData.selfTestingResult = "";
    benchStatusData.startAppButtonDisabled = true;
    benchStatusData.startAppButtonColor = glVars.BACKGROUND_COLOR;
    return new Promise((resolve) => {
        benchStatusData.operatorCodeInputValue = "";
        logger("Старт самотестирования стенда");
        benchStatusData.selfTestingResult = "Идет самотестирование ...";
        // проверка связи со сканером штрихкодов
        benchStatusData.selfTestingResult+="<br>Проверка связи со сканером штрихкодов ...<br>"; 
        // проверка связи со сканером
        logger("Проверка связи со сканером штрихкодов");
        getData("localhost", "3032", "/barcodescanner/getdata")
        .then((answerObject) => {
            if (answerObject.scannerStatus === "None connection") {
                logger("Нет связи со сканером штрихкодов");
                glVars.scannerStatusIndicatorColor = glVars.ORANGE_COLOR;
                benchStatusData.selfTestingResult += "<span style ='color: "+ glVars.ORANGE_COLOR+ ";'>Нет связи со сканером штрихкодов</span><br>";
            }
            else{
                logger("Связь со сканером штрихкодов установлена");
                glVars.scannerStatusIndicatorColor = glVars.GREEN_COLOR;
                benchStatusData.selfTestingResult += "<span style ='color:"+ glVars.DARK_GREEN_COLOR +";'>Связь со сканером установлена</span><br>";
            }               
                glVars.scanerPollEnabledFlag = true;                  
                glVars.barcodeRequestEnabled = 1;
    
                const succesfulTestFlag = {
                    value: true
                }
                logger("Проверка связи с блоком управления");
                benchStatusData.selfTestingResult += "Проверка связи с блоком управления ...<br>";
                return succesfulTestFlag;            
        })
        .then((succesfulTestFlag) => {
            // проверка связи с блоком управления
            getData("localhost", "3030","/te1570/exec?command=sync_pc&address=220&led_status=0&led_flash_period=0&buzzer_time=2&relay_status=0")
            .then((answerObject) => {
                if (answerObject.errorCode === 0){
                    logger("Связь с блоком управления установлена");
                    if (answerObject.doorTS === 1){
                        glVars.doorStatusIndicatorColor = glVars.GREEN_COLOR;
                        logger("Дверь стенда закрыта");
                    }
                    else{
                        glVars.doorStatusIndicatorColor = glVars.ORANGE_COLOR;
                        logger("Дверь стенда открыта");                        
                    }
                    if (answerObject.highVoltageFlag === 0){
                        glVars.voltageStatusIndicatorColor = glVars.ORANGE_COLOR;
                        logger("Высокое напряжение отсутствует");
                    }
                    else{
                        glVars.voltageStatusIndicatorColor = glVars.GREEN_COLOR;
                        logger("Высокое напряжение присутствует");
                    }
                    logger("Температура: " + answerObject.termosensorINT);
                    benchStatusData.selfTestingResult += "<span style ='color:"+ glVars.DARK_GREEN_COLOR +";'>Связь с блоком управления установлена</span><br>";
                    glVars.controlBlockStatusIndicatorColor = glVars.GREEN_COLOR;
                }
                else{
                    logger("Связь с блоком управления отсутствует");
                    benchStatusData.selfTestingResult += "<span style ='color:"+ glVars.ORANGE_COLOR +";'>Связь с блоком управления отсутствует</span><br>";
                    glVars.controlBlockStatusIndicatorColor = glVars.ORANGE_COLOR;
                    succesfulTestFlag.value = false;
                }
                return succesfulTestFlag;
            })           
            .then((succesfulTestFlag) => {
                // проверка связи с узлами питания
                // создаем массив состояния ячеек
                logger("Проверка связи с узлами питания");
                generateCellSConditionArray(glVars); 
                benchStatusData.selfTestingResult += "Включение узлов питания ...<br>";
                logger("Включение узлов питания");
                glVars.relayStatus = 1;
                synchronizePC(glVars.curMainIndStatus, 0, glVars.buzzerTime, glVars)
                .then(()=>{
                    benchStatusData.selfTestingResult += "Проверка связи с узлами питания ...<br>";
                    
                    setTimeout(() => {
                        getBenchStatus(glVars)
                        .then((answerArray) => {
                            let numErrors = 0;
                            if (answerArray.length !== glVars.NUM_CELLS){
                                logger("Ошибка связи со службой драйвера стенда");
                                benchStatusData.selfTestingResult += "<span style ='color:"+ glVars.ORANGE_COLOR +";'>Ошибка связи со службой драйвера стенда</span><br>";
                                succesfulTestFlag.value = false;
                            }
                            else{
                                for(let i = 0; i < glVars.NUM_CELLS; i++){
                                    if (answerArray[i].errorCode !== 0){
                                    logger("Ошибка связи с узлом питания ячейки " + (i+1));
                                    benchStatusData.selfTestingResult += "<span style ='color:"+ glVars.ORANGE_COLOR +";'>Ошибка связи с узлом питания ячейки " + (i+1) + "</span><br>";
                                    numErrors++;
                                    succesfulTestFlag.value = false;
                                    }
                                    else{
                                        logger("Связь с узлом питания ячейки " + (i+1) + " установлена. Температура " + answerArray[i].termosensorINT);
                                    }
                                }
                                if (numErrors === 0){
                                    logger("Связь с узлами питания установлена");
                                    benchStatusData.selfTestingResult += "<span style ='color:"+ glVars.DARK_GREEN_COLOR +";'>Связь с узлами питания установлена</span><br>";
                                } 
                            }                
                            // инициализация состояния узлов питания
                            logger("Инициализация узлов питания");
                            benchStatusData.selfTestingResult += "Инициализация узлов питания...<br>";                
                            // отправляем широковещательные сообщения
                            // выключение линии 12В
                            synchronizeCell(255, "OFF", "OFF", 0, glVars)
                            .then((answerObject) => {
                                logger("Питание извещателей отключено");
                                logger("Тест индикации (красные светодиоды)");
                                benchStatusData.selfTestingResult += "Питание извещателей отключено<br>";
                                benchStatusData.selfTestingResult += "Тест индикации (красные светодиоды)...<br>";
                                // включение красных светодиодов
                                synchronizeCell(255,"RED","OFF",0, glVars)
                                .then(() => {
                                    setTimeout(() => {
                                        synchronizeCell(255,"OFF","OFF",0, glVars)
                                        .then(() => {
                                            logger("Тест индикации (зеленые светодиоды)");
                                            benchStatusData.selfTestingResult += "Тест индикации (зеленые светодиоды)...<br>";
                                            //glVars.badCellsInitArray.length = 0;
                                            glVars.faultyCellsNumArray.length = 0;
                                            // выполняем для каждой ячейки
                                            const cellInitFunc = (cellAddress) => {
                                                synchronizeCell(cellAddress,"GREEN","OFF",0 , glVars)
                                                .then(() => {
                                                    synchronizeCell(cellAddress,"GREEN","ON",0 , glVars)
                                                    .then(() => {
                                                        setTimeout(() => {
                                                        //запрашиваем статус ячейки
                                                        synchronizeCell(cellAddress,"GREEN","ON",0 , glVars)
                                                        .then((answ)=>{
                                                            if (answ.errorCode !== 0){
                                                                // ошибка при инициализации
                                                                logger("Ошибка при инициализации ячейки " + cellAddress + ": " +  errorCodeToString(answ.errorCode));
                                                            }
                                                            else{
                                                                logger("Инициализация ячейки " + cellAddress + " проведена. Ток покоя: " + convertCurrent(answ.cellCurrent, cellAddress, glVars));
                                                            }
                                                            if (i <= glVars.NUM_CELLS){
                                                                i++;
                                                                cellInitFunc(i);
                                                            }
                                                        });
                                                    }, 100);
                                                    });                                                    
                                                });
                                            } // end cellInitFun
                                            i = 1;
                                            cellInitFunc(i);
                                            // включение зеленых светодиодов
                                            synchronizeCell(255,"GREEN","OFF",0 , glVars)
                                            .then((answerObject) => {

                                                setTimeout(() => {
                                                    // выключаем светодиоды
                                                    synchronizeCell(255,"OFF","OFF",0, glVars)
                                                    .then((answerObject) => {
                                                        benchStatusData.selfTestingResult += "<span style ='color:"+ glVars.DARK_GREEN_COLOR +";'>Инициализация состояния узлов питания выполнена</span><br>";
                                                        benchStatusData.selfTestingResult += "Выключение узлов питания ...<br>";
                                                        glVars.relayStatus = 0;
                                                        logger("Выключение узлов питания");
                                                        // проверка работы трехцветного индикатора
                                                        logger("Тест индикатора стенда");
                                                        benchStatusData.selfTestingResult += "Тест индикатора стенда (красный цвет)...<br>";
                                                        synchronizePC("RED", 0, 0, glVars)
                                                        .then((answerObject) => {
                                                            setTimeout(() => {
                                                                benchStatusData.selfTestingResult += "Тест индикатора стенда (жёлтый цвет)...<br>";
                                                                synchronizePC("BOTH", 0, 0, glVars)
                                                                .then((answerObject)=>{
                                                                    setTimeout(() => {
                                                                        benchStatusData.selfTestingResult += "Тест индикатора стенда (зеленый цвет)...<br>";
                                                                        synchronizePC("GREEN", 0, 0, glVars)
                                                                        .then((answerObject)=>{
                                                                            setTimeout(() => {
                                                                                synchronizePC("OFF", 0, 0, glVars)
                                                                                .then((answerObject)=>{
                                                                                    // если инициализация успешна, разблокируем кнопку старта
                                                                                    if (succesfulTestFlag){
                                                                                        logger("Самотестирование успешно завершено");
                                                                                        benchStatusData.selfTestingResult += "Самотестирование успешно завершено<br>";
                                                                                        benchStatusData.startAppButtonDisabled = false;
                                                                                        benchStatusData.startAppButtonColor = glVars.GREEN_COLOR;
                                                                                        // разрешаем главный таймер
                                                                                        glVars.barcodeRequestEnabled = 0;
                                                                                        resolve(0);
                                                                                    }
                                                                                    else{
                                                                                        logger("Ошибки при проведении самотестирования");
                                                                                        benchStatusData.selfTestingResult += "Ошибки при проведении самотестирования";
                                                                                        resolve(0);
                                                                                    }
                                                                                });
                                                                            },glVars.LEDS_INIT_LIGHT_INTERVAL/2);
                                                                        });
                                                                    }, glVars.LEDS_INIT_LIGHT_INTERVAL/2);    
                                                                });                                                                            
                                                            },glVars.LEDS_INIT_LIGHT_INTERVAL/2);
                                                        });
                                                    });
                                                }, glVars.LEDS_INIT_LIGHT_INTERVAL);

                                            });


                                        });
                                    }, glVars.LEDS_INIT_LIGHT_INTERVAL);
                                })
                            });
                        });
                    }, 500);
                });
            });
        });
    });

    
}

//=======================================================================================================
/**
 * @brief Переключает светодиоды в режиме снятия извещателей
 * @param {*} mode  UNLOADING_BAD_DEVICES = 0 - снятие негодных, 
 *                  UNLOADING_UNKNOWN_DEVICES = 1 - снятие с неизвестным результатом, 
 *                  UNLOADING_GOOD_DEVICES = 2 - снятие годных
 * @param {*} glVars 
 */
const switchLEDS = (mode, glVars) => {
    return new Promise((resolve) => {
        let i = 0;
        const loopFunc = (runFlag) => {
            if (runFlag){
                if (glVars.resultData[i].getSerialNum() !== ""){
                    // для заполненной ячейки
                    switch (mode){
                        case UNLOADING_BAD_DEVICES:
                            if ((!glVars.resultData[i].isGoodDevice()) && (!glVars.resultData[i].isUnknownResult())){
                                // включаем красный светодиод, непрерывное свечение                                
                                synchronizeCell(i+1, "RED", "OFF", 0, glVars)
                                .then((answ) => {
                                    i++;
                                    loopFunc(i < glVars.NUM_CELLS);
                                });
                            }
                            else{
                                i++;
                                loopFunc(i < glVars.NUM_CELLS);
                            }
                            break;
                        case UNLOADING_UNKNOWN_DEVICES:
                            if (glVars.resultData[i].isUnknownResult()){
                                // включаем красный светодиод, мигающий режим
                                synchronizeCell(i+1, "RED", "OFF", glVars.ledFlashingPeriod, glVars)
                                .then((answ) => {
                                    i++;
                                    loopFunc(i < glVars.NUM_CELLS);
                                });
                            }
                            else{
                                i++;
                                loopFunc(i < glVars.NUM_CELLS);
                            }
                            break;
                        case UNLOADING_GOOD_DEVICES:
                            if (glVars.resultData[i].isGoodDevice()){
                                // включаем зеленый светодиод, непрерывный режим
                                synchronizeCell(i+1, "GREEN", "OFF", 0, glVars)
                                .then((answ) => {
                                    i++;
                                    loopFunc(i < glVars.NUM_CELLS);
                                });
                            }
                            else{
                                i++;
                                loopFunc(i < glVars.NUM_CELLS);
                            }
                            break;
                    }
                }
                else{
                    i++;
                    loopFunc(i < glVars.NUM_CELLS);
                }
            }
            else{
                resolve(0);
            }
        }
        loopFunc(i < glVars.NUM_CELLS);
    });
}

//=======================================================================================================
/**
 * @brief Функция переключения в режим проверки ИК канала
 */
const gotoCheckup_IR = (glVars, benchStatusData) => {
    //пополняем массив неисправных ячеек новыми
    for(let i = 0; i < glVars.NUM_CELLS; i++){
        if (!numberInArray(i+1, glVars.faultyCellsNumArray)){
            if ((glVars.resultData[i].getCurrentLowCounter() > 0) || 
                (glVars.resultData[i].getCurrentHighCounter() > 0) || 
                (glVars.resultData[i].getCellErrorConnectionCounter() > 0)){
                    glVars.faultyCellsNumArray.push(i+1);
            }
        }        
    }
    glVars.channel_IR = true;
    benchStatusData.faultyCellsNumArray = Array.from(glVars.faultyCellsNumArray);
    benchStatusData.numCells = glVars.NUM_CELLS;
    benchStatusData.checkupPanelIsGenerated = false;
    benchStatusData.checkUpFormHeaderValue = "Проверка работоспособности ИК-канала извещателей " + benchStatusData.selectedDevice.deviceName +" после наработки";
    benchStatusData.checkupPanelCellValues.length = 0;
    benchStatusData.checkupPanelCellColors.length = 0;
    for(let i = 0; i < glVars.NUM_CELLS; i++){
        // сбрасываем флаги срабатывания
        glVars.resultData[i].resetOperabilityIR();
        benchStatusData.checkupPanelCellValues.push("-"); 
        if (numberInArray(i+1, glVars.faultyCellsNumArray)){
            benchStatusData.checkupPanelCellColors.push(glVars.BACKGROUND_COLOR);
        }                        
        else{
            benchStatusData.checkupPanelCellColors.push(glVars.ORANGE_COLOR);
        }                        
    }   

    glVars.benchMode = CHECKUP_IR_AFTER_RUNNING_MODE;

}


//=======================================================================================================
/**
 * @brief Функция переключения в режим проверки акустического канала
 */
const gotoCheckup_AC = (glVars, benchStatusData) => {
    glVars.channel_IR = false;
    benchStatusData.checkUpFormHeaderValue = "Проверка на воздействие НЧ акустической помехи " + 
                        benchStatusData.selectedDevice.deviceName + " после наработки";
    benchStatusData.checkupPanelCellValues.length = 0;
    benchStatusData.checkupPanelCellColors.length = 0;
    for(let i = 0; i < glVars.NUM_CELLS; i++){        
        if (numberInArray(i+1, glVars.faultyCellsNumArray)){
            benchStatusData.checkupPanelCellColors.push(glVars.BACKGROUND_COLOR);
            benchStatusData.checkupPanelCellValues.push("-");
        }                        
        else{
            benchStatusData.checkupPanelCellColors.push(glVars.GREEN_COLOR);
            benchStatusData.checkupPanelCellValues.push("+");
        }  
    }
    glVars.benchMode = LOWFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE;
}


//=======================================================================================================

exports.captureSignal = (query, glVars) => {
    glVars.receivedSignal.option = query.option;
    glVars.receivedSignal.signal = query.signal;
    glVars.receivedSignal.receiveFlag = true;
}

//=======================================================================================================
/**
 * @brief Функция обработки сигнала
 * @param {*} query 
 * @param {*} glVars 
 * @returns 
 */
exports.processSignal = (glVars, benchStatusData) => { 
    let option = glVars.receivedSignal.option;
    let newCellNum = 0;
    return new Promise((resolve) => {
        switch(glVars.receivedSignal.signal){
            case "PAGE_UPDATE_SIGNAL":
                benchStatusData.DeviceSelectPanelIsGenerated = false;
                benchStatusData.runningPanelIsGenerated = false;
                benchStatusData.checkupIRPanelIsGenerated = false;
                benchStatusData.checkupACPanelIsGenerated = false;
                benchStatusData.reportPanelIsGenerated = false;
                benchStatusData.checkup_IR_BR_PanelIsGenerated = false;
                benchStatusData.checkup_LF_BR_PanelIsGenerated = false;
                benchStatusData.checkup_HF_BR_PanelIsGenerated = false;
                benchStatusData.checkup_AC_BR_PanelIsGenerated = false;
                benchStatusData.checkup_IR_AR_PanelIsGenerated = false;
                benchStatusData.checkup_LF_AR_PanelIsGenerated = false;
                benchStatusData.checkup_HF_AR_PanelIsGenerated = false;
                benchStatusData.checkup_AC_AR_PanelIsGenerated = false;
                benchStatusData.badDevicesPanelIsGenerated = false;
                resolve(0);
                break;
            case "START_SELFTEST":
                glVars.benchMode = SELFTEST_MODE;
                benchStatusData.selfTestingResult = "Идет самотестирование...";
                glVars.scannerStatusIndicatorColor = glVars.ORANGE_COLOR;
                glVars.controlBlockStatusIndicatorColor = glVars.ORANGE_COLOR,
                benchStatusData.startAppButtonColor = glVars.BACKGROUND_COLOR;
                benchStatusData.startAppButtonDisabled = true;
                //glVars.mainTimerEnabled = false;    
                glVars.cellsCondArray.length = 0;
                setTimeout(() => {
                    performSelfTest(benchStatusData, glVars)
                    .then(() => {
                    resolve(0);
                });
                }, 1000);
                                
                break;
            case "GO_TO_AUTHORIZATION":
                glVars.benchMode = AUTHORIZATION_MODE;
                resolve(0);
                break;
            case "CLEAR_BARCODE_DATA":
                glVars.barcodeClearFlag= true;                
                resolve(0);
                break;
            case "GO_TO_DEVICE_SELECTION":
                logger("Включение узлов питания");
                glVars.relayStatus = 1;
                benchStatusData.prevCellButtonIsVisible = false;
                benchStatusData.nextCellButtonIsVisible = true;
                benchStatusData.activeCellNumberInputValue = "1";
                benchStatusData.newData = false;
                benchStatusData.barcodeData = "";
                benchStatusData.cellStatusIndicatorValue = "";
                benchStatusData.startRunningButtonEnabled = false;
                benchStatusData.finishLoadingButtonEnabled = false;
                benchStatusData.startRunningButtonColor = glVars.BACKGROUND_COLOR;
                benchStatusData.wrongDeviceFlag = false;
                benchStatusData.shortcutFlag = false;
                benchStatusData.serialDuplicateFlag = false;
                generateCellSConditionArray(glVars);
                glVars.activeCellModel.activeCellNumber = 1;
                glVars.activeCellModel.activeCellStatus =  CELL_STATUS_SERIAL_WAITING; // статус активной ячейки
                glVars.activeCellModel.redLED = 0;
                glVars.activeCellModel.greenLED = 0;
                glVars.activeCellModel.LED_flash_period = 0;
                glVars.activeCellModel.line_12V = 0;
                glVars.activeCellModel.current_mA = 0;
                glVars.activeCellModel.serial = "";
                glVars.mainIndicatorStatus = "OFF";
                glVars.mainIndicatorFlashPeriod = 0;
                glVars.benchMode = DEVICE_SELECTION_MODE;
                resolve(0);               
                
                break;
            case "SET_DEV_SELECT_PANEL_FLAG":
                if (option === "true"){
                    benchStatusData.DeviceSelectPanelIsGenerated = true;
                }                    
                else{
                    benchStatusData.DeviceSelectPanelIsGenerated = false;
                }                    
                resolve(0);
                break;
            case "SET_SELECTED_DEVICE":
                let i = parseInt(option);
                if (i >= 0){                    
                    benchStatusData.selectedDevice.deviceName = benchStatusData.devicesList[i].deviceName;
                    benchStatusData.selectedDevice.deviceID = benchStatusData.devicesList[i].deviceID;
                    benchStatusData.selectedDevice.number_IR_Channels = benchStatusData.devicesList[i].number_IR_Channels;
                    benchStatusData.selectedDevice.number_AC_Channels = benchStatusData.devicesList[i].number_AC_Channels;                                               
                    benchStatusData.selectedDevice.maxCurrent_mA = benchStatusData.devicesList[i].maxCurrent_mA;
                    benchStatusData.selectedDevice.startUpTime = benchStatusData.devicesList[i].startUpTime;
                    benchStatusData.selectedDevice.runningTime = benchStatusData.devicesList[i].runningTime;
                }
                resolve(0);
                break;
            case "GO_TO_LOADING":
                logger("Выбран извещатель " + benchStatusData.selectedDevice.deviceName);
                glVars.benchMode = LOADING_MODE;
                glVars.activeCellModel.activeCellNumber = 1;
                benchStatusData.loadingFormHeaderValue = "Завеска извещателей " + benchStatusData.selectedDevice.deviceName;
                benchStatusData.activeCellNumberInputValue = parseInt(glVars.activeCellModel.activeCellNumber);
                benchStatusData.prevCellButtonIsVisible = false;
                benchStatusData.nextCellButtonIsVisible  = true;
                benchStatusData.activeCellNumberInputValue = "1";
                benchStatusData.newData = false;
                benchStatusData.barcodeData = "";
                benchStatusData.cellStatusIndicatorValue = "";
                benchStatusData.cellStatusIndicatorColor = glVars.BACKGROUND_COLOR;
                benchStatusData.startStandbyEnteringButtonEnabled = false;
                benchStatusData.finishLoadingButtonEnabled = false;
                benchStatusData.startStandbyEnteringButtonColor = glVars.BACKGROUND_COLOR;
                benchStatusData.wrongDeviceFlag = false;
                benchStatusData.shortcutFlag = false;
                benchStatusData.serialDuplicateFlag = false;
                glVars.activeCellModel.activeCellStatus = CELL_STATUS_SERIAL_WAITING;

                benchStatusData.standbyEnteringFormBackBtnEnabled = false;
                benchStatusData.standbyEnteringFormNextBtnEnabled = false;

                logger("Начат режим завески извещателей");
                glVars.mainIndicatorStatus = "GREEN";
                glVars.mainIndicatorFlashPeriod = 1000;
                resolve(0);                             
                break;
            case "GO_TO_REPLACEMENT":
                console.log("переход к замене извещателей");
                if (glVars.receivedSignal.option === "CHECKUP_BF"){
                    switch(glVars.benchMode){
                        case IR_CHECKUP_BEFORE_RUNNING_MODE:
                            benchStatusData.replaceDeviceQuerySender = "CHECKUP_IR_BF";
                            break;
                        case LOWFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE:
                            benchStatusData.replaceDeviceQuerySender = "CHECKUP_LF_BF";
                            break;
                        case HIGHFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE:
                            benchStatusData.replaceDeviceQuerySender = "CHECKUP_HF_BF";
                            break;
                        case SOUND_ALARM_CHECKUP_BEFORE_RUNNING_MODE:
                            benchStatusData.replaceDeviceQuerySender = "CHECKUP_SA_BF";
                            break;
                        default:
                            benchStatusData.replaceDeviceQuerySender = "none";
                            break;
                    }
                }
                else{
                    benchStatusData.replaceDeviceQuerySender = glVars.receivedSignal.option;
                }                
                glVars.benchMode = LOADING_MODE;
                resolve(0);
                break;
            case "RESET_REPLACE_QUERY_SENDER":
                benchStatusData.replaceDeviceQuerySender = "none";
                resolve(0);
                break;
            case "GO_TO_DOOR_CLOSING_MODE":
                glVars.mainIndicatorStatus = "BOTH";
                glVars.mainIndicatorFlashPeriod = 1000;
                benchStatusData.standbyEnteringFormStatusIndicatorValue = "Выход извещателей в дежурный режим";
                benchStatusData.standbyEnteringFormTimeIndicatorValue = convertSecondsToTimeString(benchStatusData.selectedDevice.startUpTime);
                benchStatusData.standbyEnteringFormPanelValue = "Ожидайте выхода извещателей в дежурный режим";
                benchStatusData.standbyEnteringFormBackBtnEnabled = false;
                benchStatusData.standbyEnteringFormNextBtnEnabled = false;
                benchStatusData.standbyEnteringFormNextBtnColor = glVars.BACKGROUND_COLOR;
                benchStatusData.standbyEnteringFormBackBtnColor = glVars.BACKGROUND_COLOR;
                glVars.barcodeClearFlag= true;
                glVars.startUpFlag = false;
                
                glVars.benchMode = DOOR_CLOSING_WAITING_MODE;
                logger("Старт ожидания закрытия двери стенда");
                resolve(0);
                break;
            case "GO_TO_IR_AC_CHECKUP_BEFORE_RUNNING_MODE":
                glVars.mainIndicatorStatus = "BOTH";
                glVars.mainIndicatorFlashPeriod = 0;
                benchStatusData.checkupPanelCellValues.length = 0;
                benchStatusData.checkupPanelCellColors.length = 0;
                // создание массива результатов проверки работоспособности перед наработкой
                glVars.checkUpResults.length = 0;
                for(let i = 0; i < glVars.NUM_CELLS; i++){
                    glVars.checkUpResults.push(new CheckUpResultObject(i+1,false, false, false, false, false, false));
                }
                if (benchStatusData.selectedDevice.number_IR_Channels === 1){
                    benchStatusData.checkUpBeforeRunningFormHeader = "Проверка работоспособности ИК-канала " + benchStatusData.selectedDevice.deviceName + " перед наработкой";
                    const loopFunc = () => {
                        if (i < glVars.NUM_CELLS){
                            if (!numberInArray(i+1, glVars.faultyCellsNumArray)){
                                benchStatusData.checkupPanelCellValues.push("-");
                                benchStatusData.checkupPanelCellColors.push(glVars.ORANGE_COLOR);
                                synchronizeCell(i+1,"BOTH","ON",0,glVars)
                                .then(() => {
                                    i++;
                                    loopFunc();
                                });
                            }
                            else{
                                benchStatusData.checkupPanelCellValues.push("-");
                                benchStatusData.checkupPanelCellColors.push(glVars.BACKGROUND_COLOR);
                                i++;
                                loopFunc();
                            }                        
                        }
                        else{
                            glVars.benchMode = IR_CHECKUP_BEFORE_RUNNING_MODE;
                            resolve(0);
                        }                        
                    }
                    let i = 0;
                    loopFunc();
                }
                else{
                    benchStatusData.checkUpBeforeRunningFormHeader = "Проверка на воздействие НЧ акустической помехи " + benchStatusData.selectedDevice.deviceName +" перед наработкой";
                    for(let i = 0; i < glVars.NUM_CELLS; i++){
                        benchStatusData.checkupPanelCellValues.push("+");
                        benchStatusData.checkupPanelCellColors.push(glVars.GREEN_COLOR);
                    }
                    glVars.benchMode = LOWFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE;
                    resolve(0);                    
                }
            break;       
            case "STOP_RUNNING":
                glVars.runningStartFlag = false;
                glVars.waitingForCheckUpFlag = false;
                glVars.startUpFlag = false;
                glVars.runningStartFlag = false;                
                benchStatusData.replaceDeviceQuerySender = "RUNNING";
                glVars.mainIndicatorStatus = "GREEN";
                glVars.mainIndicatorFlashPeriod = 1000;
                glVars.benchMode = LOADING_MODE;
                logger("Наработка принудительно остановлена");
                resolve(0);
                break;
            case "SET_CELL_SERIAL_WAITING":
                glVars.activeCellModel.activeCellStatus = CELL_STATUS_SERIAL_WAITING;
                resolve(0);
                break;
            case "PREV_CELL":
                glVars.loadingModeSignal = LOADING_MODE_PREV_CELL_SIGNAL;
                resolve(0);
                break;
            case "NEXT_CELL":
                glVars.loadingModeSignal = LOADING_MODE_NEXT_CELL_SIGNAL;
                resolve(0);
                break;
            case "SET_ACTIVE_CELL_NUMBER":
                glVars.newNumCell = parseInt(option);   
                glVars.loadingModeSignal = LOADING_MODE_GOTO_CELL_SIGNAL;                          
                resolve(0);
                break;
            case "SCREEN_KEYBOARD_BARCODE_SIGNAL":
                benchStatusData.barcodeData = option;
                glVars.activeCellModel.serial = option;
                benchStatusData.newData = true;                           
                resolve(0);
                break;    
            case "REPLACE_BAD_DEVICE":
                glVars.activeCellModel.activeCellStatus = CELL_STATUS_SERIAL_WAITING;
                // блокируем кнопку
                benchStatusData.startRunningButtonEnabled =false;
                benchStatusData.startRunningButtonColor = glVars.BACKGROUND_COLOR;
                benchStatusData.barcodeData = "";
                benchStatusData.newData = true;
                glVars.activeCellModel.serial = "";
                glVars.removingBadDeviceFlag = true;
            
                // разблокируем кнопку завершения завески
                benchStatusData.finishLoadingButtonEnabled = true;

                // обнуляем состояние ячейки в массиве состояний
                glVars.cellsCondArray[glVars.activeCellModel.activeCellNumber-1].serial = "";
                glVars.cellsCondArray[glVars.activeCellModel.activeCellNumber-1].line_12V = 0;
                glVars.cellsCondArray[glVars.activeCellModel.activeCellNumber-1].redLED = 0;
                glVars.cellsCondArray[glVars.activeCellModel.activeCellNumber-1].greenLED = 0;
                glVars.cellsCondArray[glVars.activeCellModel.activeCellNumber-1].current_mA = 0;
                resolve(0);
                break;
            case "FINISH_LOADING":
                glVars.mainIndicatorStatus = "BOTH";
                glVars.mainIndicatorFlashPeriod = 0;
                if ((glVars.activeCellModel.activeCellStatus === CELL_STATUS_READY)){
                        glVars.activeCellModel.activeCellStatus = CELL_STATUS_START_RUNNING_WAITING;            
                }
                else{
                    // если завершаем завеску при не до конца заполненной ячейке, выключаем светодидоды
                    // выключаем светодиоды на текущей ячейке
                    // снимаем напряжение с выхода 12В
                    synchronizeCell(glVars.activeCellModel.activeCellNumber,"OFF","OFF", 0, glVars)
                    .then(() => {
                        glVars.activeCellModel.redLED_mode = 0;
                        glVars.activeCellModel.greenLED_mode = 0;
                        glVars.activeCellModel.line_12V = 0;
                        glVars.cellsCondArray[glVars.activeCellModel.activeCellNumber-1].serial = "";
                        glVars.cellsCondArray[glVars.activeCellModel.activeCellNumber-1].line_12V = 0;
                        glVars.cellsCondArray[glVars.activeCellModel.activeCellNumber-1].current_mA = 0;
                        glVars.cellsCondArray[glVars.activeCellModel.activeCellNumber-1].redLED_mode = 0;
                        glVars.cellsCondArray[glVars.activeCellModel.activeCellNumber-1].greenLED_mode = 0;
                        glVars.activeCellModel.activeCellStatus = CELL_STATUS_START_RUNNING_WAITING;
                        logger("Завеска извещателей завершена")
                        resolve(0);
                    });
                }                
                break;
            case "UPDATE_RUNPANEL_GENERATED_FLAG":
                if (option === "true"){
                    benchStatusData.runningPanelIsGenerated = true;
                }
                    
                else{
                    benchStatusData.runningPanelIsGenerated = false;
                }                    
                resolve(0);
                break;
            case "UPDATE_CHECKUP_IR_PANEL_GENERATED_FLAG":                
                if (option === "true"){
                    benchStatusData.checkupIRPanelIsGenerated = true;
                }                    
                else{
                    benchStatusData.checkupIRPanelIsGenerated = false;
                }                    
                resolve(0);
                break;
            case "UPDATE_CHECKUP_IR_BR_PANEL_GENERATED_FLAG":                
                if (option === "true"){
                    benchStatusData.checkup_IR_BR_PanelIsGenerated = true;
                }                    
                else{
                    benchStatusData.checkup_IR_BR_PanelIsGenerated = false;
                }                    
                resolve(0);
                break;
            case "UPDATE_CHECKUP_IR_AR_PANEL_GENERATED_FLAG":                
                if (option === "true"){
                    benchStatusData.checkup_IR_AR_PanelIsGenerated = true;
                }                    
                else{
                    benchStatusData.checkup_IR_AR_PanelIsGenerated = false;
                }                    
                resolve(0);
                break;
            case "UPDATE_CHECKUP_LF_BR_PANEL_GENERATED_FLAG":                
                if (option === "true"){
                    benchStatusData.checkup_LF_BR_PanelIsGenerated = true;
                }                    
                else{
                    benchStatusData.checkup_LF_BR_PanelIsGenerated = false;
                }                    
                resolve(0);
                break;
            case "UPDATE_CHECKUP_LF_AR_PANEL_GENERATED_FLAG":                
                if (option === "true"){
                    benchStatusData.checkup_LF_AR_PanelIsGenerated = true;
                }                    
                else{
                    benchStatusData.checkup_LF_AR_PanelIsGenerated = false;
                }                    
                resolve(0);
                break;
            case "UPDATE_CHECKUP_HF_BR_PANEL_GENERATED_FLAG":                
                if (option === "true"){
                    benchStatusData.checkup_HF_BR_PanelIsGenerated = true;
                }                    
                else{
                    benchStatusData.checkup_HF_BR_PanelIsGenerated = false;
                }                    
                resolve(0);
                break;
            case "UPDATE_CHECKUP_HF_AR_PANEL_GENERATED_FLAG":                
                if (option === "true"){
                    benchStatusData.checkup_HF_AR_PanelIsGenerated = true;
                }                    
                else{
                    benchStatusData.checkup_HF_AR_PanelIsGenerated = false;
                }                    
                resolve(0);
                break;
            case "UPDATE_CHECKUP_AC_BR_PANEL_GENERATED_FLAG":                
                if (option === "true"){
                    benchStatusData.checkup_AC_BR_PanelIsGenerated = true;
                }                    
                else{
                    benchStatusData.checkup_AC_BR_PanelIsGenerated = false;
                }                    
                resolve(0);
                break;
            case "UPDATE_CHECKUP_AC_AR_PANEL_GENERATED_FLAG":                
                if (option === "true"){
                    benchStatusData.checkup_AC_AR_PanelIsGenerated = true;
                }                    
                else{
                    benchStatusData.checkup_AC_AR_PanelIsGenerated = false;
                }                    
                resolve(0);
                break;
            case "UPDATE_CHECKUP_AC_PANEL_GENERATED_FLAG":                
                if (option === "true"){
                    benchStatusData.checkupACPanelIsGenerated = true;
                }                    
                else{
                    benchStatusData.checkupACPanelIsGenerated = false;
                }                    
                resolve(0);
                break;
            case "CHECKUP_FORM_BR_NEXT_BUTTON_CLICK":
                logger("Нажатие кнопеи Далее");
                logger("mode: " + glVars.benchMode);
                switch(glVars.benchMode){
                    case IR_CHECKUP_BEFORE_RUNNING_MODE:
                        if (benchStatusData.selectedDevice.number_AC_Channels > 0){
                            benchStatusData.checkupPanelCellColors.length = 0;
                            benchStatusData.checkupPanelCellValues.length = 0;
                            for(let i = 0; i < glVars.NUM_CELLS; i++){
                                benchStatusData.checkupPanelCellValues.push("+");
                                benchStatusData.checkupPanelCellColors.push(glVars.GREEN_COLOR);
                            }
                            glVars.benchMode = LOWFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE;
                            benchStatusData.checkUpBeforeRunningFormHeader = "Проверка на воздействие НЧ акустической помехи " + benchStatusData.selectedDevice.deviceName + " перед наработкой";
                        }
                        else{
                            glVars.benchMode = RUNNING_MODE;
                        }                        
                        break;                    
                    case LOWFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE:
                        benchStatusData.checkupPanelCellColors.length = 0;
                        benchStatusData.checkupPanelCellValues.length = 0;
                        for(let i = 0; i < glVars.NUM_CELLS; i++){
                                benchStatusData.checkupPanelCellValues.push("+");
                                benchStatusData.checkupPanelCellColors.push(glVars.GREEN_COLOR);
                        }
                        glVars.benchMode = HIGHFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE;
                        benchStatusData.checkUpBeforeRunningFormHeader = "Проверка на воздействие ВЧ акустической помехи " + benchStatusData.selectedDevice.deviceName + " перед наработкой";
                        break;
                    case HIGHFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE:
                        benchStatusData.checkupPanelCellColors.length = 0;
                        benchStatusData.checkupPanelCellValues.length = 0;
                        for(let i = 0; i < glVars.NUM_CELLS; i++){
                                benchStatusData.checkupPanelCellValues.push("-");
                                benchStatusData.checkupPanelCellColors.push(glVars.ORANGE_COLOR);
                        }
                        glVars.benchMode = SOUND_ALARM_CHECKUP_BEFORE_RUNNING_MODE;
                        benchStatusData.checkUpBeforeRunningFormHeader = "Проверка акустического канала " + benchStatusData.selectedDevice.deviceName + " перед наработкой";
                        break;
                    case SOUND_ALARM_CHECKUP_BEFORE_RUNNING_MODE:
                        glVars.benchMode = RUNNING_MODE;
                        break;
                }
                if (glVars.benchMode === RUNNING_MODE){
                    // сохраняем в логи результаты проверки работоспособности извещателей перед наработкой 
                    logger("============= Результаты проверки работоспособности перед наработкой =================");
                    for(let i = 0; i < glVars.NUM_CELLS; i++){
                        if (!numberInArray(i+1,glVars.faultyCellsNumArray)){
                            let str = "Ячейка " + (i+1) + ": сер№: " + glVars.cellsCondArray[i].serial + " | ";
                            if (benchStatusData.selectedDevice.number_IR_Channels === 1){
                                str += "работоспособность ИК: ";
                                str += glVars.checkUpResults[i].IR_OperationFlag ? "Да" : "Нет";
                                str += " | ";
                            }
                            if (benchStatusData.selectedDevice.number_AC_Channels === 1){
                                str += "стойкость к НЧ помехе: ";
                                str += glVars.checkUpResults[i].AC_LFD_ResponseFlag ? "Нет" : "Да"; 
                                str += " | ";
                                str += "стойкость к ВЧ помехе: ";
                                str += glVars.checkUpResults[i].AC_HFD_ResponseFlag ? "Нет" : "Да";
                                str += " | ";
                                str += "работоспособность АК: ";
                                str += glVars.checkUpResults[i].AC_OperationFlag ? "Да" : "Нет";
                                str += " | ";
                            }
                            str += "ток потребления: ";
                            if (glVars.checkUpResults[i].HighCurrentFlag) str += "выше нормы";
                            if (glVars.checkUpResults[i].LowCurrentFlag) str += "ниже нормы";
                            if (!glVars.checkUpResults[i].HighCurrentFlag && !glVars.checkUpResults[i].LowCurrentFlag) str += "норма";                           
                            logger(str); 
                        }
                    }


                    glVars.alarmFallingWaitingStartFlag = false;
                    benchStatusData.toControlButtonEnabled = false;
                    benchStatusData.toControlButtonColor = glVars.BACKGROUND_COLOR;
                    benchStatusData.faultyCellsNumArray = Array.from(glVars.faultyCellsNumArray);
                    benchStatusData.numCells = glVars.NUM_CELLS;
                    benchStatusData.runningFormHeaderValue = "Наработка извещателей " + benchStatusData.selectedDevice.deviceName;
                    glVars.startUpFlag = false;
                    glVars.waitingForCheckUpFlag = false;
                    glVars.resultData.length = 0;
                    benchStatusData.runningPanelCellValues.length = 0;
                    benchStatusData.runningPanelCellColors.length = 0;
                    for(let i = 0; i < glVars.NUM_CELLS; i++){
                        if ((benchStatusData.selectedDevice.number_IR_Channels +
                            benchStatusData.selectedDevice.number_AC_Channels) === 1){
                            benchStatusData.runningPanelCellValues.push("0");
                        }
                        else{
                            benchStatusData.runningPanelCellValues.push("0-0");
                        }                 
                        if (numberInArray(i+1, glVars.faultyCellsNumArray)){
                            glVars.resultData.push(new ResultObject(
                                                        i+1,
                                                        "", 
                                                        benchStatusData.selectedDevice.deviceID, 
                                                        benchStatusData.selectedDevice.number_IR_Channels,
                                                        benchStatusData.selectedDevice.number_AC_Channels
                                                    ));
                            benchStatusData.runningPanelCellColors.push(glVars.BACKGROUND_COLOR);
                        }                        
                        else{
                            benchStatusData.runningPanelCellColors.push(glVars.GREEN_COLOR);
                            glVars.resultData.push(new ResultObject(
                                                        i+1,
                                                        glVars.cellsCondArray[i].serial,
                                                        benchStatusData.selectedDevice.deviceID,
                                                        benchStatusData.selectedDevice.number_IR_Channels,
                                                        benchStatusData.selectedDevice.number_AC_Channels
                                                    ));
                        }                        
                    }        
                }
                resolve(0);
                break;
            case "CHECKUP_FORM_BR_BACK_BUTTON_CLICK":
                switch(glVars.benchMode){
                    case IR_CHECKUP_BEFORE_RUNNING_MODE:
                        glVars.benchMode = STANDBY_CHECKUP_RESULTS_MODE;
                        break;                    
                    case LOWFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE:
                        if (benchStatusData.selectedDevice.number_IR_Channels > 0){
                            benchStatusData.checkupPanelCellColors.length = 0;
                            benchStatusData.checkupPanelCellValues.length = 0;
                            for(let i = 0; i < glVars.NUM_CELLS; i++){
                                benchStatusData.checkupPanelCellValues.push("-");
                                benchStatusData.checkupPanelCellColors.push(glVars.ORANGE_COLOR);
                            }
                            benchStatusData.checkUpBeforeRunningFormHeader = "Проверка работоспособности ИК-канала " + benchStatusData.selectedDevice.deviceName + " перед наработкой";
                            glVars.benchMode = IR_CHECKUP_BEFORE_RUNNING_MODE;
                        }
                        else{
                            glVars.benchMode = STANDBY_CHECKUP_RESULTS_MODE;
                        }                        
                        break;
                    case HIGHFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE:
                        benchStatusData.checkupPanelCellColors.length = 0;
                        benchStatusData.checkupPanelCellValues.length = 0;
                        for(let i = 0; i < glVars.NUM_CELLS; i++){
                            benchStatusData.checkupPanelCellValues.push("+");
                            benchStatusData.checkupPanelCellColors.push(glVars.GREEN_COLOR);
                        }
                        benchStatusData.checkUpBeforeRunningFormHeader = "Проверка на воздействие НЧ акустической помехи " + benchStatusData.selectedDevice.deviceName + " перед наработкой";
                        glVars.benchMode = LOWFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE;
                        break;
                    case SOUND_ALARM_CHECKUP_BEFORE_RUNNING_MODE:
                        benchStatusData.checkupPanelCellColors.length = 0;
                        benchStatusData.checkupPanelCellValues.length = 0;
                        for(let i = 0; i < glVars.NUM_CELLS; i++){
                            benchStatusData.checkupPanelCellValues.push("+");
                            benchStatusData.checkupPanelCellColors.push(glVars.GREEN_COLOR);
                        }
                        benchStatusData.checkUpBeforeRunningFormHeader = "Проверка на воздействие ВЧ акустической помехи " + benchStatusData.selectedDevice.deviceName + " перед наработкой";
                        glVars.benchMode = HIGHFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE;
                        break;
                }
                resolve(0);
                break;
            case "CHECKUP_FORM_AR_NEXT_BUTTON_CLICK":
                switch(glVars.benchMode){
                    case CHECKUP_IR_AFTER_RUNNING_MODE: 
                        if (benchStatusData.selectedDevice.number_AC_Channels > 0){
                            benchStatusData.checkupPanelCellColors.length = 0;
                            benchStatusData.checkupPanelCellValues.length = 0;
                            for(let i = 0; i < glVars.NUM_CELLS; i++){
                                    benchStatusData.checkupPanelCellValues.push("+");
                                    benchStatusData.checkupPanelCellColors.push(glVars.GREEN_COLOR);
                            }
                            glVars.benchMode = LOWFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE;
                            benchStatusData.checkUpFormHeaderValue = "Проверка на воздействие НЧ акустической помехи " + benchStatusData.selectedDevice.deviceName +" после наработки";
                        }
                        else{
                            console.log("переход в режим подготовки отчета");

                            glVars.benchMode = REPORT_PREPARING_MODE;
                            glVars.mainIndicatorStatus = "BOTH";
                            glVars.mainIndicatorFlashPeriod = 1000;
                        }                        
                        break;                    
                    case LOWFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE:
                        benchStatusData.checkupPanelCellColors.length = 0;
                        benchStatusData.checkupPanelCellValues.length = 0;
                        for(let i = 0; i < glVars.NUM_CELLS; i++){
                                benchStatusData.checkupPanelCellValues.push("+");
                                benchStatusData.checkupPanelCellColors.push(glVars.GREEN_COLOR);
                        }
                        glVars.benchMode = HIGHFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE;
                        benchStatusData.checkUpFormHeaderValue = "Проверка на воздействие ВЧ акустической помехи " + benchStatusData.selectedDevice.deviceName + " после наработки";
                        break;
                    case HIGHFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE:
                        benchStatusData.checkupPanelCellColors.length = 0;
                        benchStatusData.checkupPanelCellValues.length = 0;
                        for(let i = 0; i < glVars.NUM_CELLS; i++){
                                benchStatusData.checkupPanelCellValues.push("-");
                                benchStatusData.checkupPanelCellColors.push(glVars.ORANGE_COLOR);
                        }
                        glVars.benchMode = SOUND_ALARM_CHECKUP_AFTER_RUNNING_MODE;
                        benchStatusData.checkUpFormHeaderValue = "Проверка акустического канала " + benchStatusData.selectedDevice.deviceName + " после наработки";
                        break;
                    case SOUND_ALARM_CHECKUP_AFTER_RUNNING_MODE:
                        glVars.benchMode = REPORT_PREPARING_MODE;
                        glVars.mainIndicatorStatus = "BOTH";
                        glVars.mainIndicatorFlashPeriod = 1000;
                        break;
                }
                resolve(0);
                break;
            case "CHECKUP_FORM_AR_BACK_BUTTON_CLICK":
                switch(glVars.benchMode){                    
                    case LOWFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE:
                        if (benchStatusData.selectedDevice.number_IR_Channels > 0){
                            benchStatusData.checkupPanelCellColors.length = 0;
                            benchStatusData.checkupPanelCellValues.length = 0;
                            for(let i = 0; i < glVars.NUM_CELLS; i++){
                                benchStatusData.checkupPanelCellValues.push("-");
                                benchStatusData.checkupPanelCellColors.push(glVars.ORANGE_COLOR);
                            }
                            benchStatusData.checkUpFormHeaderValue = "Проверка работоспособности ИК-канала извещателей " + benchStatusData.selectedDevice.deviceName +" после наработки";
                            glVars.benchMode = CHECKUP_IR_AFTER_RUNNING_MODE;                        }
                        break;
                    case HIGHFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE:
                        benchStatusData.checkupPanelCellColors.length = 0;
                        benchStatusData.checkupPanelCellValues.length = 0;
                        for(let i = 0; i < glVars.NUM_CELLS; i++){
                            benchStatusData.checkupPanelCellValues.push("+");
                            benchStatusData.checkupPanelCellColors.push(glVars.GREEN_COLOR);
                        }
                        benchStatusData.checkUpFormHeaderValue = "Проверка на воздействие НЧ акустической помехи " + benchStatusData.selectedDevice.deviceName +" после наработки";
                        glVars.benchMode = LOWFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE;
                        break;
                    case SOUND_ALARM_CHECKUP_AFTER_RUNNING_MODE:
                        benchStatusData.checkupPanelCellColors.length = 0;
                        benchStatusData.checkupPanelCellValues.length = 0;
                        for(let i = 0; i < glVars.NUM_CELLS; i++){
                            benchStatusData.checkupPanelCellValues.push("+");
                            benchStatusData.checkupPanelCellColors.push(glVars.GREEN_COLOR);
                        }
                        benchStatusData.checkUpFormHeaderValue = "Проверка на воздействие ВЧ акустической помехи " + benchStatusData.selectedDevice.deviceName + " после наработки";
                        glVars.benchMode = HIGHFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE;
                        break;
                }
                resolve(0);
                break;
            case "GO_TO_CHECKUP_AFTER_RUNNING":
                glVars.mainIndicatorStatus = "BOTH";
                glVars.mainIndicatorFlashPeriod = 0;
                if (benchStatusData.selectedDevice.number_IR_Channels !== 0){
                    // переход в режим проверки ИК канала
                    logger("Проверка работоспособности ИК-канала извещателей после наработки");
                    gotoCheckup_IR(glVars, benchStatusData);
                }
                else{
                    // переход в режим проверки АК канала
                    logger("Проверка работоспособности акустического канала извещателей после наработки");
                    gotoCheckup_AC(glVars, benchStatusData);
                }              
                resolve(0);
                break;
            case "GO_TO_NEXT_STAGE_AFTER_CHECKUP":                
                let prevMode = glVars.benchMode;
                glVars.benchMode = IDLE_MODE;                
                //пополняем массив неисправных ячеек новыми
                for(let i = 0; i < glVars.NUM_CELLS; i++){
                    if (!numberInArray(i+1, glVars.faultyCellsNumArray)){
                        if ((glVars.resultData[i].getCurrentLowCounter() > 0) || 
                            (glVars.resultData[i].getCurrentHighCounter() > 0) || 
                            (glVars.resultData[i].getCellErrorConnectionCounter() > 0)){
                                glVars.faultyCellsNumArray.push(i+1);
                        }
                    }        
                }
                benchStatusData.faultyCellsNumArray.length = 0;
                benchStatusData.faultyCellsNumArray = Array.from(glVars.faultyCellsNumArray);               
                if ((benchStatusData.selectedDevice.number_IR_Channels +
                    benchStatusData.selectedDevice.number_AC_Channels) === 1){
                    glVars.benchMode = REPORT_PREPARING_MODE;
                }
                else{
                    if (prevMode === CHECKUP_IR_MODE){
                        logger("Проверка акустического канала извещателей");
                        gotoCheckup_AC(glVars, benchStatusData);                     
                    }
                    else{

                        glVars.benchMode = REPORT_PREPARING_MODE;                                   
                    }                    
                }
                resolve(0);
                break;
            case "UPDATE_REPORTPANEL_GENERATED_FLAG":
                if (option === "true"){
                    benchStatusData.reportPanelIsGenerated = true;
                }
                    
                else{
                    benchStatusData.reportPanelIsGenerated = false;
                }                    
                resolve(0);
                break;
            case "UPDATE_BAD_DEVICES_PANEL_GENERATED_FLAG":
                if (option === "true"){
                    benchStatusData.badDevicesPanelIsGenerated = true;
                }
                    
                else{
                    benchStatusData.badDevicesPanelIsGenerated = false;
                }                    
                resolve(0);
                break;
            case "RESET_SERIAL_DUPLICATE_FLAG":
                benchStatusData.serialDuplicateFlag = false;
                resolve(0);
                break;
            case "RESET_WRONG_DEVICE_FLAG":
                glVars.activeCellModel.serial = "";
                benchStatusData.wrongDeviceFlag = false;
                resolve(0);
                break;
            case "GO_TO_UNLOADING_MODE":
                let num_Bad_dev = benchStatusData.numBadDevices;
                let num_Unknown_dev = benchStatusData.numUnknownDevices;
                let num_Good_dev = glVars.NUM_CELLS - glVars.numEmptyCells - num_Bad_dev - num_Unknown_dev;
                benchStatusData.numBadDevices = benchStatusData.numBadDevices;
                benchStatusData.numUnknownDevices = benchStatusData.numUnknownDevices;
                benchStatusData.unloadingFormHeaderValue = "Снятие извещателей " + benchStatusData.selectedDevice.deviceName;
                glVars.badDevicesIsMarkedFlag = false;
                glVars.unknownDevicesIsMarkedFlag = false;
                glVars.goodDevicesIsMarkedFlag = false;
                glVars.LEDsOffFlag = false;
                
                const goToUnloadingBad = () => {
                    glVars.benchMode = UNLOADING_BAD_MODE;
                    benchStatusData.unloadingPanelValue = glVars.UNLOADING_BAD_STRING;
                    benchStatusData.unloadingPanelColor = glVars.STRONG_ORANGE_COLOR;
                    resolve(0);                 
                }

                const goToUnloadingUnknown = () => {
                    glVars.benchMode = UNLOADING_UNKNOWN_MODE;
                    benchStatusData.unloadingPanelValue = glVars.UNLOADING_UNKNOWN_STRING;
                    benchStatusData.unloadingPanelColor = glVars.BLUE_COLOR;
                    resolve(0);
                }

                const goToUnloadingGood = () => {
                    glVars.benchMode = UNLOADING_GOOD_MODE;
                    benchStatusData.unloadingPanelValue = glVars.UNLOADING_GOOD_STRING;
                    benchStatusData.unloadingPanelColor = glVars.DARK_GREEN_COLOR;
                    benchStatusData.nextUnloadingModeBtnText = "Завершить";
                    resolve(0);
                }

                const goToAutorization = () => {
                    glVars.mainIndicatorStatus = "OFF";
                    glVars.mainIndicatorFlashPeriod = 0;
                    // сохранение логов в БД
                    logger("Завершение снятия извещателей. Сохранение логов в БД");
                    saveLogsToDB()
                    .then((answ) => {
                        logger("Выключение узлов питания");
                        glVars.relayStatus = 0;
                        glVars.benchMode = AUTHORIZATION_MODE;
                        benchStatusData.nextUnloadingModeBtnText = "Далее";
                        clearLogsArray();
                        resolve(0); 
                    });                                      
                }

                switch (glVars.benchMode){
                        case REPORT_MODE:
                            if (num_Bad_dev !== 0)
                                goToUnloadingBad();
                            else // если непрошедших нет
                                if (num_Unknown_dev !== 0)
                                    goToUnloadingUnknown();
                                else// если годные
                                    if (num_Good_dev !== 0)
                                        goToUnloadingGood();                                
                                    else
                                        goToAutorization();                                                                                    
                            break;
                        case UNLOADING_BAD_MODE:
                            logger("Снятие неисправных извещателей");
                            if (num_Unknown_dev !== 0)
                                goToUnloadingUnknown();
                            else
                                if (num_Good_dev !== 0)
                                    goToUnloadingGood();                            
                                else
                                    goToAutorization();                                                   
                            break;
                        case UNLOADING_UNKNOWN_MODE:
                            logger("Снятие извещателей, требующих повторной проверки");
                            if (num_Good_dev !== 0)
                                goToUnloadingGood();
                            else
                                goToAutorization();
                            break;
                        case UNLOADING_GOOD_MODE:
                            logger("Снятие исправных извещателей");
                            goToAutorization();
                            break;
                        default:
                            glVars.benchMode =IDLE_MODE;
                            resolve(0);
                            break;
                    }                
            
        }

    });
}

//=================================================================================================================
exports.checkUser = (userCode) => {
    return new Promise((resolve) => {
        const userData = {
            userIsApproved: false,
            operatorCode: "",
            firstName: "",
            lastName: "",
            role: 100
        };
        getOperatorDataFromDB(userCode)
        .then((answ) => {
            if (answ !== null){
                userData.operatorCode = userCode;
                userData.userIsApproved = true;
                userData.firstName = answ.firstname;
                userData.lastName = answ.lastname;
                userData.role = answ.role_code;
            }
            else{
                userData.operatorCode = userCode;
                userData.userIsApproved = false;
            }
            resolve(userData);
        });
    });
}

exports.generateCellSConditionArray = generateCellSConditionArray;
exports.convertSecondsToTimeString = convertSecondsToTimeString;
exports.numberInArray = numberInArray;
exports.switchLEDS = switchLEDS;