

// импорт констант и функций

const{
    IR_CHECKUP_BEFORE_RUNNING_MODE,
    LOWFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE,
    HIGHFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE,
    SOUND_ALARM_CHECKUP_BEFORE_RUNNING_MODE,
    CHECKUP_IR_AFTER_RUNNING_MODE,
    LOWFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE,
    HIGHFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE,
    SOUND_ALARM_CHECKUP_AFTER_RUNNING_MODE,
} = require("./model_constants.js");

const {
    synchronizeCell,
    getBenchStatus,
    getData
    } = require("./REST.js");

const {
        numberInArray
    } =  require("./signal_processing.js");

const {
        logger,
        getTimeString
    } = require("./logger.js");

    
const {
    convertCurrent,
    } = require("./convertations.js");




/**
 * @brief Функция главного таймера в режиме проверки работоспособности каналов
 * 
 * @param {*} glVars - объект-контейнер глобальных переменных
 * @param {*} dataObjectsAddressPull 
 * @param {*} nextFunc 
 */

//=====================================================================================================================
exports.onCheckUpModeTimer = (glVars, benchStatusData, nextFunc) => {
    getBenchStatus(glVars)
    .then((answerArray) => {
        let currentOutOfRangeFlag = false;

        const loopFunc = () => {
            if (i < glVars.NUM_CELLS){
                if (!numberInArray(i+1, glVars.faultyCellsNumArray)){
                    if (answerArray[i].errorCode === 0){
                        // проверяем допустимость потребляемого тока
                        if (convertCurrent(answerArray[i].cellCurrent, i+1, glVars) > glVars.shortcutCurrentThreshold){
                            if (glVars.benchMode > 14){
                                glVars.resultData[i].increaseCurrentHighCounter();
                            }                            
                            glVars.checkUpResults[i].HighCurrentFlag = true;
                            benchStatusData.checkupPanelCellColors[i] = glVars.RED_COLOR;
                            currentOutOfRangeFlag = true;
                        }
                        else{
                            if (convertCurrent(answerArray[i].cellCurrent, i+1, glVars) < glVars.currentLoadingThreshold){
                                if (glVars.benchMode >14){
                                        glVars.resultData[i].increaseCurrentLowCounter();
                                    }                            
                                glVars.checkUpResults[i].LowCurrentFlag = true;
                                if (glVars.benchMode > 14){
                                    if (glVars.resultData[i].getCurrentHighCounter() === 0){
                                        benchStatusData.checkupPanelCellColors[i] = glVars.GREY_COLOR;
                                    }       
                                }                                                                            
                                currentOutOfRangeFlag = true;
                            }
                        }

                        let IR_Relay = 1;
                        let AC_Relay = 1;
                        if (benchStatusData.selectedDevice.number_IR_Channels === 1){
                            if (benchStatusData.selectedDevice.number_AC_Channels === 1){
                                // совмещенный извещатель
                                IR_Relay = answerArray[i].cellRelay1;
                                AC_Relay = answerArray[i].cellRelay2;
                            }
                            else{
                                // извещатель только с ИК каналом
                                IR_Relay = answerArray[i].cellRelay1;
                                AC_Relay = 1;
                            }
                        }
                        else{
                            // извещатель только с акустическим каналом
                            IR_Relay = 1;
                            AC_Relay = answerArray[i].cellRelay1;
                        }

                        switch(glVars.benchMode){
                            case IR_CHECKUP_BEFORE_RUNNING_MODE:
                                if (IR_Relay === 0){
                                    benchStatusData.checkupPanelCellColors[i] = glVars.GREEN_COLOR;
                                    benchStatusData.checkupPanelCellValues[i] = "+";
                                    glVars.checkUpResults[i].IR_OperationFlag = true;           
                                    synchronizeCell(i+1,"GREEN","ON",0,glVars)
                                    .then(() => {
                                        i++;
                                        loopFunc();
                                    });
                                }
                                else{
                                    i++;
                                    loopFunc();
                                }                            
                                break;
                            case LOWFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE:
                                if (AC_Relay === 0){
                                    benchStatusData.checkupPanelCellColors[i] = glVars.ORANGE_COLOR;
                                    benchStatusData.checkupPanelCellValues[i] = "-";
                                    glVars.checkUpResults[i].AC_LFD_ResponseFlag = true;  
                                    synchronizeCell(i+1,"BOTH","ON",0,glVars)
                                    .then(() => {
                                        i++;
                                        loopFunc();
                                    });
                                }
                                else{
                                    if (benchStatusData.checkupPanelCellValues[i] !== "-"){
                                        synchronizeCell(i+1,"GREEN","ON",0,glVars)
                                        .then(() => {
                                            i++;
                                            loopFunc();
                                        });
                                    }
                                    else{
                                         i++;
                                        loopFunc();
                                    }                                   
                                }   
                                break;
                            case HIGHFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE:
                                if (AC_Relay === 0){
                                    benchStatusData.checkupPanelCellColors[i] = glVars.ORANGE_COLOR;
                                    benchStatusData.checkupPanelCellValues[i] = "-";
                                    glVars.checkUpResults[i].AC_HFD_ResponseFlag = true;
                                    synchronizeCell(i+1,"BOTH","ON",0,glVars)
                                    .then(() => {
                                        i++;
                                        loopFunc();
                                    });
                                }
                                else{
                                    if (benchStatusData.checkupPanelCellValues[i] !== "-"){
                                        synchronizeCell(i+1,"GREEN","ON",0,glVars)
                                        .then(() => {
                                            i++;
                                            loopFunc();
                                        });
                                    }
                                    else{
                                         i++;
                                        loopFunc();
                                    }                                   
                                }    
                                break;
                            case SOUND_ALARM_CHECKUP_BEFORE_RUNNING_MODE:
                                if (AC_Relay === 0){
                                    benchStatusData.checkupPanelCellColors[i] = glVars.GREEN_COLOR;
                                    benchStatusData.checkupPanelCellValues[i] = "+";
                                    glVars.checkUpResults[i].AC_OperationFlag = true;
                                    synchronizeCell(i+1,"GREEN","ON",0,glVars)
                                    .then(() => {
                                        i++;
                                        loopFunc();
                                    });
                                } 
                                else{
                                    
                                    if (benchStatusData.checkupPanelCellValues[i] !== "+"){
                                        synchronizeCell(i+1, "BOTH", "ON", 0, glVars)
                                        .then(() => {
                                            i++;
                                            loopFunc();
                                        });
                                    }
                                    else{
                                        i++;
                                        loopFunc();
                                    }                                    
                                }  
                                break;
                            case CHECKUP_IR_AFTER_RUNNING_MODE:
                                if (IR_Relay === 0){
                                    benchStatusData.checkupPanelCellColors[i] = glVars.GREEN_COLOR;
                                    benchStatusData.checkupPanelCellValues[i] = "+";
                                    glVars.resultData[i].setOperabilityIR();
                                    synchronizeCell(i+1,"GREEN","ON",0,glVars)
                                    .then(() => {
                                        i++;
                                        loopFunc();
                                    });
                                }
                                else{
                                    if (benchStatusData.checkupPanelCellValues[i] !== "+"){
                                        synchronizeCell(i+1, "BOTH", "ON", 0, glVars)
                                        .then(() => {
                                            i++;
                                            loopFunc();
                                        });
                                    }
                                    else{
                                        i++;
                                        loopFunc();
                                    }                                    
                                }   
                                break;
                            case LOWFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE:
                                if (AC_Relay === 0){
                                    benchStatusData.checkupPanelCellColors[i] = glVars.ORANGE_COLOR;
                                    benchStatusData.checkupPanelCellValues[i] = "-";
                                    glVars.resultData[i].setLFD_response();
                                    synchronizeCell(i+1,"BOTH","ON",0,glVars)
                                    .then(() => {
                                        i++;
                                        loopFunc();
                                    });
                                }
                                else{
                                    if (benchStatusData.checkupPanelCellValues[i] !== "-"){
                                        synchronizeCell(i+1,"GREEN","ON",0,glVars)
                                        .then(() => {
                                            i++;
                                            loopFunc();
                                        });
                                    }
                                    else{
                                         i++;
                                        loopFunc();
                                    }                                   
                                }     
                                break;
                            case HIGHFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE:
                                if (AC_Relay === 0){
                                    benchStatusData.checkupPanelCellColors[i] = glVars.ORANGE_COLOR;
                                    benchStatusData.checkupPanelCellValues[i] = "-";
                                    glVars.resultData[i].setHFD_response();
                                    synchronizeCell(i+1,"BOTH","ON",0,glVars)
                                    .then(() => {
                                        i++;
                                        loopFunc();
                                    });
                                }
                                else{
                                    if (benchStatusData.checkupPanelCellValues[i] !== "-"){
                                        synchronizeCell(i+1,"GREEN","ON",0,glVars)
                                        .then(() => {
                                            i++;
                                            loopFunc();
                                        });
                                    }
                                    else{
                                         i++;
                                        loopFunc();
                                    }                                   
                                }    
                                break;
                            case SOUND_ALARM_CHECKUP_AFTER_RUNNING_MODE:
                                if (AC_Relay === 0){
                                    benchStatusData.checkupPanelCellColors[i] = glVars.GREEN_COLOR;
                                    benchStatusData.checkupPanelCellValues[i] = "+";
                                    glVars.resultData[i].setOperabilityAC();
                                    synchronizeCell(i+1,"GREEN","ON",0,glVars)
                                    .then(() => {
                                        i++;
                                        loopFunc();
                                    });
                                }
                                else{
                                    if (benchStatusData.checkupPanelCellValues[i] !== "+"){
                                        synchronizeCell(i+1, "BOTH", "ON", 0, glVars)
                                        .then(() => {
                                            i++;
                                            loopFunc();
                                        });
                                    }
                                    else{
                                        i++;
                                        loopFunc();
                                    }                                    
                                }   
                                break;
                        } 
                    }
                    else{
                        // если ячейка не ответила во время
                        if (glVars.benchMode > 14){                        
                            glVars.resultData[i].increaseCellErrorConnectionCounter();
                        }
                        benchStatusData.checkupPanelCellColors[i] = glVars.BLUE_COLOR;
                        logger(getTimeString() + "Ячейка " + (i+1) + ": ошибка связи");
                        i++;
                        loopFunc();
                    }
                }
                else{
                    i++;
                    loopFunc();
                }
            }
            else{
                // завершение работы цикла
                
                if (currentOutOfRangeFlag){
                    // отключаем питание и светодиоды
                    i = 0;
                    const turnOFF_lineLEDs = () => {
                        if (i < glVars.NUM_CELLS){
                            if (!numberInArray(i+1, glVars.faultyCellsNumArray)){
                                // если ячейка не в списке незаполненных/неисправных
                                let hiCur = false;
                                let lowCur = false;
                                if (glVars.benchMode > 14){
                                    if (glVars.resultData[i].getCurrentHighCounter() > 0) hiCur =true;
                                    if (glVars.resultData[i].getCurrentLowCounter() > 0) lowCur=true;
                                }
                                else{
                                    hiCur = glVars.checkUpResults[i].HighCurrentFlag;
                                    lowCur = glVars.checkUpResults[i].LowCurrentFlag;
                                }

                                if (hiCur){
                                    // снимаем питание ячейки, включаем красный светодиод
                                    synchronizeCell((i+1), "RED", "OFF", 0, glVars)
                                    .then(() => {
                                        i++;
                                        turnOFF_lineLEDs();
                                    });
                                }
                                else{
                                    if (lowCur){
                                        // отключаем светодиоды, не снимая питания
                                        synchronizeCell((i+1), "OFF", "ON", 0, glVars)
                                        .then(() => {
                                            i++;
                                            turnOFF_lineLEDs();
                                        });
                                    }
                                    else{
                                        i++;
                                        turnOFF_lineLEDs();
                                    }
                                }
                            }
                            else{
                                i++;
                                turnOFF_lineLEDs();
                            }
                        }
                        else{
                            nextFunc();
                        }
                    }
                    turnOFF_lineLEDs();
                    
                }
                else{
                    nextFunc();
                }
            }

        }//end loopFunc 

        let i = 0;
        loopFunc();
    });
    
    
}