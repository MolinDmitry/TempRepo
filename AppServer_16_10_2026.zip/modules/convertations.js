




const convertCurrent = (current, cellAdrress, glVars) => {
    let dI = current - glVars.calibrationData[cellAdrress-1].current_0;
    let realCurrent = dI*glVars.calibrationData[cellAdrress-1].current_ratio;
    realCurrent = Math.round(realCurrent*100)/100;
    return realCurrent;
}

exports.convertCurrent = convertCurrent;