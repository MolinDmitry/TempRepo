/**
 * @brief Сервер приложений стенда ТЭ-1570
 * @version 2.8.x-develop
 * Сервер предоставляет несколько Web-приложений, взаимодействующих с REST-службами драйвера стенда,
 * базы данных настроек и базы данных результатов электротренировок
 * 
 * - Выполняем инициализацию
 *      npm init -y
 * - Устанавливаем express, EJS локально
 *      npm install express --save
 *      npm install ejs --save
 *  - Шаблоны страниц расположены в папке views 
 *  - Задаем конфигурацию для запуска в VSCode Run->Add Configuration->Node.js
 */



// импорт констант
    const  {
        MACHINE_SERIAL,
        STANDBY_MODE,
        IDLE_MODE,
        SELFTEST_MODE,
        AUTHORIZATION_MODE,
        DEVICE_SELECTION_MODE,
        LOADING_MODE,
        ENTER_STANDBY_MODE,
        DOOR_CLOSING_WAITING_MODE,
        STANDBY_CHECKUP_MODE,
        STANDBY_CHECKUP_RESULTS_MODE,
        IR_CHECKUP_BEFORE_RUNNING_MODE,
        LOWFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE,
        HIGHFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE,
        SOUND_ALARM_CHECKUP_BEFORE_RUNNING_MODE,
        RUNNING_MODE,
        CHECKUP_IR_AFTER_RUNNING_MODE,
        LOWFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE,
        HIGHFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE,
        SOUND_ALARM_CHECKUP_AFTER_RUNNING_MODE,
        REPORT_PREPARING_MODE,
        REPORT_MODE,
        UNLOADING_GOOD_MODE,
        UNLOADING_BAD_MODE,
        UNLOADING_UNKNOWN_MODE,
        UNLOADING_BAD_DEVICES,
        UNLOADING_UNKNOWN_DEVICES,
        UNLOADING_GOOD_DEVICES,
        LOADING_MODE_NONE_SIGNAL
    } = require("./modules/model_constants.js");   

// импорт функций
    const {
        captureSignal,
        processSignal,
        checkUser,
        switchLEDS
    } = require("./modules/signal_processing.js");

    const {
        getData,
        synchronizeCell,
        synchronizePC,
        getParamValueFromDB,
        getDeviceListFromDB
    } = require("./modules/REST.js");

const {
    onLoadingModeTimer   
} = require("./modules/loading_mode.js");

const {
    onRunningModeTimer   
} = require("./modules/running_mode.js");

const {
    onCheckUpModeTimer,
    IRCheckupBeforeRunningModeTimer
} = require("./modules/checkup_mode.js");

const {
    onReportPreparingModeTimer,
    saveResultsToDB
} = require("./modules/report_prep_mode.js");

const {
    loadConfiguration
} = require("./modules/config_loader.js");

const {
    logger,
    saveLogsToDB,
    deleteOldLogs
} = require("./modules/logger.js");

const {
    ResultObject
} = require("./modules/ResultObject.js");

const {
    doorClosingWaitingModeTimer,
    onStandbyEnteringTimer
} = require("./modules/standbyentering_mode.js");




const benchStatusData = {
    machineSerial: MACHINE_SERIAL,
    selfTestingResult: "Идет самотестирование ...",
    startAppButtonDisabled: true,
    startAppButtonColor: "rgb(240, 240, 240)",
    newData: false,
    barcodeData: "",
    // выбор изделия
    DeviceSelectPanelIsGenerated: false,
    devicesList: [],
    selectedDevice:  {
                    deviceName: "none",
                    deviceID: 0,
                    number_IR_Channels: 0,
                    number_AC_Channels: 0,
                    maxCurrent_mA: 0,
                    startUpTime: 0,
                    runningTime: 0
                },
    // завеска 
    loadingFormHeaderValue: "",
    prevCellButtonIsVisible: false,
    nextCellButtonIsVisible: true,
    activeCellNumberInputValue: "",
    cellStatusIndicatorValue: "",
    cellStatusIndicatorColor: "",
    cellSerialWaitingStatusFlag: false,
    startStandbyEnteringButtonEnabled: false,
    finishLoadingButtonEnabled: false,
    startStandbyEnteringButtonColor: "",
    wrongDeviceFlag: false,
    shortcutFlag: false,
    serialDuplicateFlag: false,
    // выход в дежурный режим
    standbyEnteringFormStatusIndicatorValue: "",
    standbyEnteringFormTimeIndicatorValue: "",
    standbyEnteringFormPanelValue: "",
    standbyEnteringFormBackBtnEnabled: false,
    standbyEnteringFormNextBtnEnabled: false,
    standbyEnteringFormNextBtnColor: "",
    standbyEnteringFormBackBtnColor: "",
    // ожидание закрытия двери
    // проверка выхода в дежурный режим
    // проверка ИК перед наработкой
    // проверка НЧ помехи перед наработкой
    // проверка ВЧ помехи перед наработкой
    // проверка акустического канала перед наработкой
    //наработка          
    runningPanelIsGenerated: false,
    faultyCellsNumArray: [],
    runningFormHeaderValue: "",
    benchStatusIndicatorValue: "--",
    runningTimeIndicatorValue: "--",
    standbyCheckupFormBackBtnEnabled: false,
    standbyCheckupFormNextBtnEnabled: false,
    standbyCheckupFormBackBtnColor: "",
    standbyCheckupFormNextBtnColor: "",
    runningPanelCellValues: [],
    runningPanelCellColors: [],
    toControlButtonEnabled: false,
    toControlButtonColor: "",
    // проверка работоспособности
    checkupIRPanelIsGenerated: false,
    checkupACPanelIsGenerated: false,
    checkup_IR_BR_PanelIsGenerated: false,
    checkup_LF_BR_PanelIsGenerated: false,
    checkup_HF_BR_PanelIsGenerated: false,
    checkup_AC_BR_PanelIsGenerated: false,
    checkup_IR_AR_PanelIsGenerated: false,
    checkup_LF_AR_PanelIsGenerated: false,
    checkup_HF_AR_PanelIsGenerated: false,
    checkup_AC_AR_PanelIsGenerated: false,
    checkUpFormHeaderValue: "",
    checkupPanelCellValues: [],
    checkupPanelCellColors: [],
    replaceDeviceQuerySender: "none",
    // отчет о наработке
    reportFormHeaderValue: "",
    reportPanelIsGenerated: false,
    badDevicesPanelIsGenerated: false,
    numBadDevices: 0,
    numUnknownDevices: 0,
    numCellColumn: [],
    serialColumn: [],
    falseIR_Column: [],
    falseAC_Column: [],
    checkIR_Column: [],
    checkLFD_Column: [],
    checkHFD_Column: [],
    checkAC_Column: [],
    currentColumn: [],
    errorsColumn: [],
    resultColumn: [],
    falseIR_Color_Column: [],
    falseAC_Color_Column: [],
    checkIR_Color_Column: [],
    checkLFD_Color_Column: [],
    checkHFD_Color_Column: [],
    checkAC_Color_Column: [],
    current_Color_Column: [],
    errors_Color_Column: [],
    result_Color_Column: [],
    // снятие извещателей
    unloadingFormHeaderValue: "",
    unloadingPanelValue: "",
    unloadingPanelColor: "",
    nextUnloadingModeBtnText: "Далее"


    

}


const glVars = {
    errorFlag: true,
    mainTimerEnabled: false,
    benchMode: STANDBY_MODE,
    operatorCode: "",
    machineSerial: MACHINE_SERIAL,
    calibrationData: [], // объекты {current_0, current_ratio}
    barcodeClearFlag: false,
    mainIndicatorStatus: "OFF", // статус главного индикатора стенда (RED, GREEN, BOTH, OFF)
    mainIndicatorFlashPeriod: 0, // период мигания основного индикатора, 0 - включен постоянно, 1 ед. = 1 мс
    buzzerTime: 0, // 0 - зуммер выключен, 1 ед. = 1 мс
    relayStatus: 0, // статус реле ПК, 0 - все разомкнуты, 1 - реле 1 замкн
    curMainIndStatus: "OFF",
    mainIndTick: 0,
    scannerStatusIndicatorColor: "",
    controlBlockStatusIndicatorColor: "",
    doorStatusIndicatorColor: "",
    voltageStatusIndicatorColor: "",
    scanerPollEnabledFlag: 0,
    barcodeRequestEnabled: 0,
    NUM_CELLS: 140,
    cellsCondArray: [],
    faultyCellsNumArray: [],
    LEDS_INIT_LIGHT_INTERVAL: 2000,
    // информационная модель состояния активной ячейки (для хранения переменных состояния)
    activeCellModel:
        {
            activeCellNumber:  0, // номер активной ячейки при завеске
            activeCellStatus:  0, // статус активной ячейки
            redLED: 0, // 0 - выключен, 1 - включен
            greenLED: 0, //
            LED_flash_period: 0, 
            line_12V: 0, // выход 12 В
            current_mA: 0, // потребляемый ток, мА
            serial: "" // серийный номер устройства
        },
    currentLoadingThreshold: 0, // порог тока обнаружения установки извещателя в ячейку (5), мА
    shortcutCurrentThreshold: 0, // порог обнаружения короткого замыкания в цепи питания извещателя (25), мА
    falseAlarmIR_threshold: 0,
    falseAlarmAC_threshold: 0,
    highCurrentCounter_threshold: 0,
    errorConnectionCounter_threshold: 0,
    removingBadDeviceFlag: false,
    startUpStartTime: 0, // время начала выхода в дежурный режим
    runningStartTime: 0, // время начала наработки
    runningStartFlag: false,
    alarmFallingTime: 0, // время снятия сигнала тревоги
    standbyCheckupResultsFormedFlag: false,
    primaryControllerStatus:
        {
            doorTS: 0, 
            highVoltageFlag: 0
        },
    startUpFlag: false,
    resultData: [],
    checkUpResults: [],
    waitingForCheckUpFlag: false,
    numEmptyCells: 0,
    ledFlashingPeriod: 50,
    badDevicesIsMarkedFlag: false,
    unknownDevicesIsMarkedFlag: false,
    goodDevicesIsMarkedFlag: false,
    LEDsOffFlag: false,
    voltageOffFlag: false,
    loadingModeSignal: LOADING_MODE_NONE_SIGNAL,
    SPACE_TIME: 0,
    MAIN_TIMER_INTERVAL: 0, 
    GREEN_COLOR: "",
    DARK_GREEN_COLOR: "",
    BLACK_COLOR: "",
    GREY_COLOR: "",
    RED_COLOR: "",
    ORANGE_COLOR: "",
    BLUE_COLOR: "",
    CREAM_COLOR: "",
    BACKGROUND_COLOR: "",
    STRONG_RED_COLOR: "",
    STRONG_ORANGE_COLOR: "",
    CELL_STATUS_SERIAL_WAITING_STRING: "",
    CELL_STATUS_NOT_ALLOWED_STRING: "",
    CELL_STATUS_LOADING_WAITING_STRING: "",
    CELL_STATUS_SHORTCUT_STRING: "",
    CELL_STATUS_READY_STRING: "",
    CELL_STATUS_START_RUNNING_WAITING_STRING_1: "",
    CELL_STATUS_START_RUNNING_WAITING_STRING_2: "",
    CELL_STATUS_START_RUNNING_WAITING_STRING_3: "",
    BENCH_STATUS_DOOR_OPEN_STRING: "",
    BENCH_STATUS_DEVICES_STARTUP_STRING: "",
    BENCH_STATUS_RUNNING_IN_PROCESS_STRING: "",
    BENCH_STATUS_RUNNING_COMPLETE_STRING: "",
    REPEAT_STRING: "",
    UNLOADING_BAD_STRING: "",
    UNLOADING_UNKNOWN_STRING: "",
    UNLOADING_GOOD_STRING: "",
    MAIN_TIMER_COUNTER_MAX_VALUE: 0,
    UP_STATE_LOG_PERIOD: 0,
    scannerConnectionFlag: false,
    primaryControllerConnectionFlag: undefined, 
    doorOpenStateFlag: false,
    cellStatusLoggingFlag: true,
    highVoltageFallingFlag: false,
    newNumCell: 1,
    receivedSignal: 
        {
            receiveFlag: false,
            signal: "",
            option: ""
        },
    lastLoadedDeviceTime: 0, // время момента подачи питания на извещатель, завешеный последним
    allDevicesStandbyTime: 0, // время момента выхода последнего извещателя в дежурный режим
    allDeviceStandbyFlag: false,
    alarmFallingWaitingStartFlag: false
}


const main = () => {
    console.log("Starting TE-1570 application server ...");
    const express = require("express");
    const app = express();
    const port = 3000;
    const path = require("path");
    
    //удаленпе старых логов
    console.log("Deleting old logs ...");
    deleteOldLogs();
     
    //  настраиваем путь к директории с шаблонами страниц
    // необходимо для корректной работы при запуске не из под VSCode
    app.set('views', path.join(__dirname, "views"));
    app.set('public', path.join(__dirname, "public"));
    
    // установка директории статических файлов
    app.use(express.static(path.join(__dirname, 'public')));

    // обработчик запроса
    app.get("/", (req, res) => {
        // res.render("mainpage.ejs");
        res.sendFile(path.join(__dirname + "/public/pages/mainpage.html"));
    });

    // обработчик запроса
    app.get("/control", (req, res) => {
        // res.render("controlpage.ejs");
        glVars.mainTimerEnabled = false;
        res.sendFile(path.join(__dirname + "/public/pages/controlpage.html"));
    });

    // обработчик запроса
    app.get("/calibration", (req, res) => {
        // res.render("controlpage.ejs");
        glVars.mainTimerEnabled = false;
        res.sendFile(path.join(__dirname + "/public/pages/calibration.html"));
    });

    // обработчик запроса
    app.get("/getserial", (req, res) => {
        res.send({
            machineSerial: MACHINE_SERIAL
        });
    });

    // обработчик запроса
    app.get("/bench", (req, res) => {
        // res.render("bench1570.ejs");
        glVars.mainTimerEnabled = true;
        res.sendFile(path.join(__dirname + "/public/pages/bench1570.html"));
    });


    // обработчик запроса статуса стенда
    app.get("/get_bench_status", (req, res) => {
            switch(glVars.benchMode){
                case SELFTEST_MODE:
                    res.send({
                        machineSerial: MACHINE_SERIAL,
                        benchMode: glVars.benchMode,
                        scannerStatusIndicatorColor: glVars.scannerStatusIndicatorColor,
                        controlBlockStatusIndicatorColor: glVars.controlBlockStatusIndicatorColor,
                        doorStatusIndicatorColor: glVars.doorStatusIndicatorColor,
                        voltageStatusIndicatorColor: glVars.voltageStatusIndicatorColor,
                        selfTestingResult: benchStatusData.selfTestingResult,
                        startAppButtonDisabled: benchStatusData.startAppButtonDisabled,
                        startAppButtonColor: benchStatusData.startAppButtonColor
                    });
                    break;
                case AUTHORIZATION_MODE:
                    res.send({
                        machineSerial: MACHINE_SERIAL,
                        benchMode: glVars.benchMode,
                        scannerStatusIndicatorColor: glVars.scannerStatusIndicatorColor,
                        controlBlockStatusIndicatorColor: glVars.controlBlockStatusIndicatorColor,
                        doorStatusIndicatorColor: glVars.doorStatusIndicatorColor,
                        voltageStatusIndicatorColor: glVars.voltageStatusIndicatorColor,
                        newData:  benchStatusData.newData,
                        barcodeData:  benchStatusData.barcodeData,
                        DeviceSelectPanelIsGenerated:  benchStatusData.DeviceSelectPanelIsGenerated,
                        devicesList:  benchStatusData.devicesList,
                        badDevicesPanelIsGenerated: benchStatusData.badDevicesPanelIsGenerated,
                        numBadDevices: benchStatusData.numBadDevices
                    });              
                    break;
                case DEVICE_SELECTION_MODE:
                    res.send({
                        machineSerial: MACHINE_SERIAL,
                        benchMode: glVars.benchMode,
                        scannerStatusIndicatorColor: glVars.scannerStatusIndicatorColor,
                        controlBlockStatusIndicatorColor: glVars.controlBlockStatusIndicatorColor,
                        doorStatusIndicatorColor: glVars.doorStatusIndicatorColor,
                        voltageStatusIndicatorColor: glVars.voltageStatusIndicatorColor,
                        DeviceSelectPanelIsGenerated: benchStatusData.DeviceSelectPanelIsGenerated,
                        devicesList: benchStatusData.devicesList,
                        selectedDevice: benchStatusData.selectedDevice
                    });
                    break;
                case LOADING_MODE:
                    res.send({
                        machineSerial: MACHINE_SERIAL,
                        benchMode: glVars.benchMode,
                        scannerStatusIndicatorColor: glVars.scannerStatusIndicatorColor,
                        controlBlockStatusIndicatorColor: glVars.controlBlockStatusIndicatorColor,
                        doorStatusIndicatorColor: glVars.doorStatusIndicatorColor,
                        voltageStatusIndicatorColor: glVars.voltageStatusIndicatorColor,
                        DeviceSelectPanelIsGenerated: benchStatusData.DeviceSelectPanelIsGenerated,
                        devicesList: benchStatusData.devicesList,
                        loadingFormHeaderValue: benchStatusData.loadingFormHeaderValue,
                        prevCellButtonIsVisible: benchStatusData.prevCellButtonIsVisible,
                        nextCellButtonIsVisible: benchStatusData.nextCellButtonIsVisible,
                        activeCellNumberInputValue: benchStatusData.activeCellNumberInputValue,
                        newData: benchStatusData.newData,
                        barcodeData: benchStatusData.barcodeData,
                        cellStatusIndicatorValue: benchStatusData.cellStatusIndicatorValue,
                        cellStatusIndicatorColor: benchStatusData.cellStatusIndicatorColor,
                        cellSerialWaitingStatusFlag: benchStatusData.cellSerialWaitingStatusFlag,
                        startStandbyEnteringButtonEnabled: benchStatusData.startStandbyEnteringButtonEnabled,
                        finishLoadingButtonEnabled: benchStatusData.finishLoadingButtonEnabled,
                        startStandbyEnteringButtonColor: benchStatusData.startStandbyEnteringButtonColor,
                        wrongDeviceFlag: benchStatusData.wrongDeviceFlag,
                        shortcutFlag: benchStatusData.shortcutFlag,
                        serialDuplicateFlag: benchStatusData.serialDuplicateFlag,
                        checkup_IR_BR_PanelIsGenerated: benchStatusData.checkup_IR_BR_PanelIsGenerated,
                        checkup_LF_BR_PanelIsGenerated: benchStatusData.checkup_LF_BR_PanelIsGenerated,
                        checkup_HF_BR_PanelIsGenerated: benchStatusData.checkup_HF_BR_PanelIsGenerated,
                        checkup_AC_BR_PanelIsGenerated: benchStatusData.checkup_AC_BR_PanelIsGenerated,
                        replaceDeviceQuerySender: benchStatusData.replaceDeviceQuerySender
                    });
                    break;
                case ENTER_STANDBY_MODE:
                case DOOR_CLOSING_WAITING_MODE:
                case STANDBY_CHECKUP_MODE:
                    res.send({
                        machineSerial: MACHINE_SERIAL,
                        benchMode: glVars.benchMode,
                        scannerStatusIndicatorColor: glVars.scannerStatusIndicatorColor,
                        controlBlockStatusIndicatorColor: glVars.controlBlockStatusIndicatorColor,
                        doorStatusIndicatorColor: glVars.doorStatusIndicatorColor,
                        voltageStatusIndicatorColor: glVars.voltageStatusIndicatorColor,
                        standbyEnteringFormStatusIndicatorValue: benchStatusData.standbyEnteringFormStatusIndicatorValue,
                        standbyEnteringFormTimeIndicatorValue: benchStatusData.standbyEnteringFormTimeIndicatorValue,
                        standbyEnteringFormPanelValue: benchStatusData.standbyEnteringFormPanelValue,
                        standbyEnteringFormBackBtnEnabled: benchStatusData.standbyEnteringFormBackBtnEnabled,
                        standbyEnteringFormNextBtnEnabled: benchStatusData.standbyEnteringFormNextBtnEnabled,
                        standbyEnteringFormNextBtnColor: benchStatusData.standbyEnteringFormNextBtnColor,
                        standbyEnteringFormBackBtnColor: benchStatusData.standbyEnteringFormBackBtnColor
                    });
                break;
                case STANDBY_CHECKUP_RESULTS_MODE:
                case IR_CHECKUP_BEFORE_RUNNING_MODE:
                case LOWFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE:
                case HIGHFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE:
                case SOUND_ALARM_CHECKUP_BEFORE_RUNNING_MODE:
                    res.send({
                        machineSerial: MACHINE_SERIAL,
                        benchMode: glVars.benchMode,
                        scannerStatusIndicatorColor: glVars.scannerStatusIndicatorColor,
                        controlBlockStatusIndicatorColor: glVars.controlBlockStatusIndicatorColor,
                        doorStatusIndicatorColor: glVars.doorStatusIndicatorColor,
                        voltageStatusIndicatorColor: glVars.voltageStatusIndicatorColor,
                        standbyEnteringFormStatusIndicatorValue: benchStatusData.standbyEnteringFormStatusIndicatorValue,
                        standbyEnteringFormTimeIndicatorValue: benchStatusData.standbyEnteringFormTimeIndicatorValue,
                        standbyEnteringFormPanelValue: benchStatusData.standbyEnteringFormPanelValue,
                        numCells: glVars.NUM_CELLS,
                        selectedDevice: benchStatusData.selectedDevice,
                        runningPanelIsGenerated: benchStatusData.runningPanelIsGenerated,
                        faultyCellsNumArray: benchStatusData.faultyCellsNumArray,
                        checkUpBeforeRunningFormHeader: benchStatusData.checkUpBeforeRunningFormHeader,
                        runningPanelCellValues: benchStatusData.runningPanelCellValues,
                        runningPanelCellColors: benchStatusData.runningPanelCellColors,
                        checkupPanelCellValues: benchStatusData.checkupPanelCellValues,
                        checkupPanelCellColors: benchStatusData.checkupPanelCellColors,
                        checkup_IR_BR_PanelIsGenerated: benchStatusData.checkup_IR_BR_PanelIsGenerated,
                        checkup_LF_BR_PanelIsGenerated: benchStatusData.checkup_LF_BR_PanelIsGenerated,
                        checkup_HF_BR_PanelIsGenerated: benchStatusData.checkup_HF_BR_PanelIsGenerated,
                        checkup_AC_BR_PanelIsGenerated: benchStatusData.checkup_AC_BR_PanelIsGenerated,
                        standbyCheckupFormBackBtnColor: benchStatusData.standbyCheckupFormBackBtnColor,
                        standbyCheckupFormNextBtnColor: benchStatusData.standbyCheckupFormNextBtnColor,
                        standbyCheckupFormBackBtnEnabled: benchStatusData.standbyCheckupFormBackBtnEnabled,
                        standbyCheckupFormNextBtnEnabled: benchStatusData.standbyCheckupFormNextBtnEnabled                   
                    });
                break;
                case RUNNING_MODE:
                    res.send({
                        machineSerial: MACHINE_SERIAL,
                        benchMode: glVars.benchMode,
                        scannerStatusIndicatorColor: glVars.scannerStatusIndicatorColor,
                        controlBlockStatusIndicatorColor: glVars.controlBlockStatusIndicatorColor,
                        doorStatusIndicatorColor: glVars.doorStatusIndicatorColor,
                        voltageStatusIndicatorColor: glVars.voltageStatusIndicatorColor,
                        numCells: glVars.NUM_CELLS,
                        selectedDevice: benchStatusData.selectedDevice,
                        runningPanelIsGenerated: benchStatusData.runningPanelIsGenerated,
                        faultyCellsNumArray: benchStatusData.faultyCellsNumArray,
                        runningFormHeaderValue: benchStatusData.runningFormHeaderValue,
                        benchStatusIndicatorValue: benchStatusData.benchStatusIndicatorValue,
                        runningTimeIndicatorValue: benchStatusData.runningTimeIndicatorValue,
                        runningPanelCellValues: benchStatusData.runningPanelCellValues,
                        runningPanelCellColors: benchStatusData.runningPanelCellColors,
                        checkup_IR_BR_PanelIsGenerated: benchStatusData.checkup_IR_BR_PanelIsGenerated,
                        checkup_AC_BR_PanelIsGenerated: benchStatusData.checkup_AC_BR_PanelIsGenerated,
                        toControlButtonEnabled: benchStatusData.toControlButtonEnabled,
                        toControlButtonColor: benchStatusData.toControlButtonColor                   
                    });
                break;
                case CHECKUP_IR_AFTER_RUNNING_MODE:
                case LOWFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE:
                case HIGHFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE:
                case SOUND_ALARM_CHECKUP_AFTER_RUNNING_MODE:
                    res.send({
                        machineSerial: MACHINE_SERIAL,
                        benchMode: glVars.benchMode,
                        scannerStatusIndicatorColor: glVars.scannerStatusIndicatorColor,
                        controlBlockStatusIndicatorColor: glVars.controlBlockStatusIndicatorColor,
                        doorStatusIndicatorColor: glVars.doorStatusIndicatorColor,
                        voltageStatusIndicatorColor: glVars.voltageStatusIndicatorColor,
                        numCells: glVars.NUM_CELLS,
                        selectedDevice: benchStatusData.selectedDevice,
                        checkupIRPanelIsGenerated: benchStatusData.checkupIRPanelIsGenerated,
                        checkupACPanelIsGenerated: benchStatusData.checkupACPanelIsGenerated,
                        checkup_IR_AR_PanelIsGenerated: benchStatusData.checkup_IR_AR_PanelIsGenerated,
                        checkup_LF_AR_PanelIsGenerated: benchStatusData.checkup_LF_AR_PanelIsGenerated,
                        checkup_HF_AR_PanelIsGenerated: benchStatusData.checkup_HF_AR_PanelIsGenerated,
                        checkup_AC_AR_PanelIsGenerated: benchStatusData.checkup_AC_AR_PanelIsGenerated,
                        runningPanelIsGenerated: benchStatusData.runningPanelIsGenerated,
                        checkUpFormHeaderValue: benchStatusData.checkUpFormHeaderValue,
                        faultyCellsNumArray: benchStatusData.faultyCellsNumArray,
                        checkupPanelCellValues: benchStatusData.checkupPanelCellValues,
                        checkupPanelCellColors: benchStatusData.checkupPanelCellColors                   
                    });
                break;
                case REPORT_MODE:
                    res.send({
                        machineSerial: MACHINE_SERIAL,
                        benchMode: glVars.benchMode,
                        scannerStatusIndicatorColor: glVars.scannerStatusIndicatorColor,
                        controlBlockStatusIndicatorColor: glVars.controlBlockStatusIndicatorColor,
                        doorStatusIndicatorColor: glVars.doorStatusIndicatorColor,
                        voltageStatusIndicatorColor: glVars.voltageStatusIndicatorColor,
                        reportFormHeaderValue: benchStatusData.reportFormHeaderValue,
                        reportPanelIsGenerated: benchStatusData.reportPanelIsGenerated,
                        selectedDevice: benchStatusData.selectedDevice,
                        numBadDevices: benchStatusData.numBadDevices,
                        numUnknownDevices: benchStatusData.numUnknownDevices,
                        numCellColumn: benchStatusData.numCellColumn,
                        serialColumn: benchStatusData.serialColumn,
                        falseIR_Column: benchStatusData.falseIR_Column,
                        falseAC_Column: benchStatusData.falseAC_Column,
                        checkIR_Column: benchStatusData.checkIR_Column,
                        checkLFD_Column: benchStatusData.checkLFD_Column,
                        checkHFD_Column: benchStatusData.checkHFD_Column,
                        checkAC_Column: benchStatusData.checkAC_Column,
                        currentColumn: benchStatusData.currentColumn,
                        errorsColumn: benchStatusData.errorsColumn,
                        resultColumn: benchStatusData.resultColumn,
                        falseIR_Color_Column: benchStatusData.falseIR_Color_Column,
                        falseAC_Color_Column: benchStatusData.falseAC_Color_Column,
                        checkIR_Color_Column: benchStatusData.checkIR_Color_Column,
                        checkLFD_Color_Column: benchStatusData.checkLFD_Color_Column,
                        checkHFD_Color_Column: benchStatusData.checkHFD_Color_Column,
                        checkAC_Color_Column: benchStatusData.checkAC_Color_Column,
                        current_Color_Column: benchStatusData.current_Color_Column,
                        errors_Color_Column: benchStatusData.errors_Color_Column,
                        result_Color_Column: benchStatusData.result_Color_Column,
                        checkup_IR_AR_PanelIsGenerated: benchStatusData.checkup_IR_AR_PanelIsGenerated,
                        checkup_AC_AR_PanelIsGenerated: benchStatusData.checkup_AC_AR_PanelIsGenerated,
                    });
                break;
                case UNLOADING_BAD_MODE:
                case UNLOADING_UNKNOWN_MODE:
                case UNLOADING_GOOD_MODE:
                    res.send({
                        machineSerial: MACHINE_SERIAL,
                        benchMode: glVars.benchMode,
                        scannerStatusIndicatorColor: glVars.scannerStatusIndicatorColor,
                        controlBlockStatusIndicatorColor: glVars.controlBlockStatusIndicatorColor,
                        doorStatusIndicatorColor: glVars.doorStatusIndicatorColor,
                        voltageStatusIndicatorColor: glVars.voltageStatusIndicatorColor,
                        selectedDevice: benchStatusData.selectedDevice,
                        reportFormHeaderValue: benchStatusData.reportFormHeaderValue,
                        reportPanelIsGenerated: benchStatusData.reportPanelIsGenerated,
                        badDevicesPanelIsGenerated: benchStatusData.badDevicesPanelIsGenerated,
                        unloadingFormHeaderValue: benchStatusData.unloadingFormHeaderValue,
                        unloadingPanelValue: benchStatusData.unloadingPanelValue,
                        unloadingPanelColor: benchStatusData.unloadingPanelColor,
                        nextUnloadingModeBtnText: benchStatusData.nextUnloadingModeBtnText,
                        numBadDevices: benchStatusData.numBadDevices,
                        numUnknownDevices: benchStatusData.numUnknownDevices,
                        numCellColumn: benchStatusData.numCellColumn,
                        serialColumn: benchStatusData.serialColumn,
                        falseIR_Column: benchStatusData.falseIR_Column,
                        falseAC_Column: benchStatusData.falseAC_Column,
                        checkIR_Column: benchStatusData.checkIR_Column,
                        checkLFD_Column: benchStatusData.checkLFD_Column,
                        checkHFD_Column: benchStatusData.checkHFD_Column,
                        checkAC_Column: benchStatusData.checkAC_Column,
                        currentColumn: benchStatusData.currentColumn,
                        errorsColumn: benchStatusData.errorsColumn,
                        resultColumn: benchStatusData.resultColumn,
                        falseIR_Color_Column: benchStatusData.falseIR_Color_Column,
                        falseAC_Color_Column: benchStatusData.falseAC_Color_Column,
                        checkIR_Color_Column: benchStatusData.checkIR_Color_Column,
                        checkLFD_Color_Column: benchStatusData.checkLFD_Color_Column,
                        checkHFD_Color_Column: benchStatusData.checkHFD_Color_Column,
                        checkAC_Color_Column: benchStatusData.checkAC_Color_Column,
                        current_Color_Column: benchStatusData.current_Color_Column,
                        errors_Color_Column: benchStatusData.errors_Color_Column,
                        result_Color_Column: benchStatusData.result_Color_Column
                    });
                break;
                default:
                    res.send({
                        machineSerial: MACHINE_SERIAL,
                        benchMode: glVars.benchMode,
                        scannerStatusIndicatorColor: glVars.scannerStatusIndicatorColor,
                        controlBlockStatusIndicatorColor: glVars.controlBlockStatusIndicatorColor,
                        doorStatusIndicatorColor: glVars.doorStatusIndicatorColor,
                        voltageStatusIndicatorColor: glVars.voltageStatusIndicatorColor
                    });
                    break;
            }
            
    });

    

    // обработчик сигнала 
    app.get("/process_signal", (req, res) => {
        logger("Получен сигнал " + req.query.signal + " c опцией " + req.query.option);
        if (!glVars.receivedSignal.receiveFlag){
            captureSignal(req.query, glVars);
            res.send({
                signal: req.query.signal,
                performed: true
            });            
        }
        else{
            res.send(
                {
                    signal: req.query.signal,
                    performed: false
                }
            );        
        }
        
    });

    // обработчик запроса проверки пользователя
    app.get("/check_user", (req, res) => {
        checkUser(req.query.code)
        .then((answ) => {
            logger("Авторизация оператора: " + answ.operatorCode + " " + answ.firstName + " " + answ.lastName);
            glVars.operatorCode = answ.operatorCode;
            res.send(answ);
        });
    });



    // Функция главного таймера
    const mainTimerTick = () => {
        if (glVars.mainTimerEnabled){            
            glVars.mainTimerTickCounter++;      
            // проверка связи со сканером
            getData("localhost", "3032", "/barcodescanner/getdata")
            .then((answerObject) => {
                if (answerObject.scannerStatus === "None connection"){
                    if (glVars.scannerConnectionFlag) {
                        glVars.scannerConnectionFlag = false;
                        logger("Потеря связи со сканером штрихкодов");
                    }
                    glVars.scannerStatusIndicatorColor = glVars.ORANGE_COLOR;
                }
                else{
                    if (!glVars.scannerConnectionFlag){
                        glVars.scannerConnectionFlag = true;
                        logger("Связь со сканером штрихкодов установлена");
                    }
                    
                    if (glVars.barcodeClearFlag){
                        benchStatusData.newData = false;
                        benchStatusData.barcodeData = ""; 
                        glVars.barcodeClearFlag = false;     
                    }

                    glVars.scannerStatusIndicatorColor = glVars.GREEN_COLOR;
                    if (answerObject.scannerStatus !== "No data"){
                        if (glVars.benchMode === AUTHORIZATION_MODE){
                            benchStatusData.newData = true;
                            benchStatusData.barcodeData = answerObject.message;
                        }
                        if (glVars.benchMode === LOADING_MODE){
                            benchStatusData.newData = true;
                            benchStatusData.barcodeData = answerObject.message;
                            glVars.activeCellModel.serial = answerObject.message;
                        }
                    }
                }  
            })
            .then(() => {
                // проверка связи с блоком управления
                if ((glVars.mainIndicatorStatus !== "OFF")&&(glVars.mainIndicatorFlashPeriod !== 0)){
                    if (glVars.mainIndicatorFlashPeriod === 0){
                        glVars.curMainIndStatus = glVars.mainIndicatorStatus;
                    }
                    else{
                        glVars.mainIndTick += glVars.MAIN_TIMER_INTERVAL;
                        if(glVars.mainIndTick >= glVars.mainIndicatorFlashPeriod){
                            if(glVars.curMainIndStatus === "OFF"){
                                glVars.curMainIndStatus = glVars.mainIndicatorStatus;
                            }
                            else{
                                glVars.curMainIndStatus = "OFF";   
                            }
                            glVars.mainIndTick = 0;
                        }

                    }

                }
                else{
                    glVars.curMainIndStatus = glVars.mainIndicatorStatus;
                }
                synchronizePC(glVars.curMainIndStatus, 0, glVars.buzzerTime, glVars)
                .then((answerObject) => {
                    if (answerObject.errorCode === 0){
                        glVars.buzzerTime = 0;
                        glVars.controlBlockStatusIndicatorColor = glVars.GREEN_COLOR;                    
                        if (glVars.primaryControllerConnectionFlag === undefined){
                            glVars.primaryControllerConnectionFlag = true;
                            logger("Связь с первичным контроллером установлена");
                        }
                        else{
                            if (!glVars.primaryControllerConnectionFlag){
                                glVars.primaryControllerConnectionFlag = true;
                                logger("Связь с первичным контроллером установлена");
                            }
                        }
                        
                        glVars.primaryControllerStatus.doorTS = (answerObject.doorTS === 0)? 1: 0;
                        if (glVars.primaryControllerStatus.doorTS === 0){
                            if (glVars.doorOpenStateFlag){
                                logger("Дверь стенда закрыта");
                                glVars.doorOpenStateFlag = false;
                                glVars.doorStatusIndicatorColor = glVars.GREEN_COLOR;
                            }
                        }
                        else{
                            if (!glVars.doorOpenStateFlag){
                                logger("Дверь стенда открыта");
                                glVars.doorOpenStateFlag = true;
                                glVars.doorStatusIndicatorColor = glVars.ORANGE_COLOR;
                            }
                        }
                        if (glVars.mainTimerTickCounter > glVars.MAIN_TIMER_COUNTER_MAX_VALUE){
                            glVars.mainTimerTickCounter = 0;
                            logger("Первичный контроллер: температура " + answerObject.termosensorINT);
                        }
                        glVars.primaryControllerStatus.highVoltageFlag = answerObject.highVoltageFlag;
                        if (glVars.primaryControllerStatus.highVoltageFlag === 0){
                            if (!glVars.highVoltageFallingFlag){
                                glVars.highVoltageFallingFlag = true;
                                logger("Напряжение питания 220 В отсутствует");
                                glVars.voltageStatusIndicatorColor = glVars.ORANGE_COLOR;
                                logger("Сохранение логов в БД");
                                saveLogsToDB();
                            }
                        }
                        else{
                            if (glVars.highVoltageFallingFlag){
                                glVars.highVoltageFallingFlag = false;
                                glVars.voltageStatusIndicatorColor = glVars.GREEN_COLOR;
                                logger("Напряжение питания 220 В присутствует");
                            }
                        }
                    }
                    else{
                            glVars.controlBlockStatusIndicatorColor = glVars.ORANGE_COLOR;
                            if (glVars.primaryControllerConnectionFlag === undefined){
                                glVars.primaryControllerConnectionFlag = false;
                                logger("Связь с первичным контроллером отсутствует");
                            }
                            else{
                                if (glVars.primaryControllerConnectionFlag){
                                glVars.primaryControllerConnectionFlag = false;
                                logger("Связь с первичным контроллером отсутствует");
                                }
                            }                            
                    }

                    const modeAction = () => {
                        switch (glVars.benchMode){                        
                        case AUTHORIZATION_MODE:
                            setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL);                  
                            break;
                        case DEVICE_SELECTION_MODE:
                            setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL);
                            break;
                        case LOADING_MODE:
                            setTimeout(() => {
                                onLoadingModeTimer(glVars, benchStatusData, () => {setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL)});
                            }, glVars.SPACE_TIME);                            
                            break;
                        case DOOR_CLOSING_WAITING_MODE:
                            setTimeout(() => {
                            doorClosingWaitingModeTimer(glVars, benchStatusData, () => {setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL)});
                            }, glVars.SPACE_TIME);
                            break;
                        case ENTER_STANDBY_MODE:
                            setTimeout(() => {
                                onStandbyEnteringTimer(glVars, benchStatusData, () => {setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL)});
                            }, glVars.SPACE_TIME);
                            break;
                        
                        // case STANDBY_CHECKUP_MODE:
                        //     setTimeout(() => {
                        //     standbyCheckupModeTimer(glVars, benchStatusData, () => {setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL)});
                        //     }, glVars.SPACE_TIME);
                        //     break;
                        // case STANDBY_CHECKUP_RESULTS_MODE:
                        //     setTimeout(() => {
                        //     standbyCheckupResultsModeTimer(glVars, benchStatusData, () => {setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL)});
                        //     }, glVars.SPACE_TIME);
                        //     break;
                        case IR_CHECKUP_BEFORE_RUNNING_MODE:
                            setTimeout(() => {
                            onCheckUpModeTimer(glVars, benchStatusData, () => {setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL)});
                            }, glVars.SPACE_TIME);
                            
                            break;
                        case LOWFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE:
                            setTimeout(() => {
                            onCheckUpModeTimer(glVars, benchStatusData, () => {setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL)});
                            }, glVars.SPACE_TIME);                        
                            break;
                        case HIGHFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE:
                            setTimeout(() => {
                            onCheckUpModeTimer(glVars, benchStatusData, () => {setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL)});
                            }, glVars.SPACE_TIME);                        
                            break;
                        case SOUND_ALARM_CHECKUP_BEFORE_RUNNING_MODE:
                            setTimeout(() => {
                            onCheckUpModeTimer(glVars, benchStatusData, () => {setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL)});
                            }, glVars.SPACE_TIME);                        
                            break;
                        case RUNNING_MODE:
                            setTimeout(() => {
                                onRunningModeTimer(glVars, benchStatusData, () => {setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL)});
                            }, glVars.SPACE_TIME);
                            break;
                        case CHECKUP_IR_AFTER_RUNNING_MODE:
                            setTimeout(() => {
                            onCheckUpModeTimer(glVars, benchStatusData, () => {setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL)});
                            }, glVars.SPACE_TIME);
                            break;
                        case LOWFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE:
                            setTimeout(() => {
                            onCheckUpModeTimer(glVars, benchStatusData, () => {setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL)});
                            }, glVars.SPACE_TIME);
                            break;
                        case HIGHFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE:
                            setTimeout(() => {
                            onCheckUpModeTimer(glVars, benchStatusData, () => {setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL)});
                            }, glVars.SPACE_TIME);
                            break;
                        case SOUND_ALARM_CHECKUP_AFTER_RUNNING_MODE:
                            setTimeout(() => {
                            onCheckUpModeTimer(glVars, benchStatusData, () => {setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL)});
                            }, glVars.SPACE_TIME);
                            break;                    
                        case REPORT_PREPARING_MODE:
                            if (glVars.voltageOffFlag) glVars.voltageOffFlag = false;
                            onReportPreparingModeTimer(glVars, benchStatusData, () => {setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL)});
                            break;
                        case REPORT_MODE:
                            if (!glVars.voltageOffFlag){
                                glVars.voltageOffFlag = true;
                                // выключаем все светодиоды и питание
                                synchronizeCell(255, "OFF", "OFF", 0, glVars)
                                .then((answ) => {
                                    setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL);
                                });
                            }
                            else{
                                setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL);
                            }                            
                            break;                        
                        case UNLOADING_BAD_MODE:
                            if (!glVars.badDevicesIsMarkedFlag){
                                // включаем красные светодиоды для извещателей, не  прошедших наработку
                                glVars.badDevicesIsMarkedFlag = true;
                                synchronizeCell(255, "OFF", "OFF", 0, glVars)
                                .then(() => {
                                        switchLEDS(UNLOADING_BAD_DEVICES, glVars);
                                })
                                .then(()=>{
                                    setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL);
                                });                              
                            }
                            else{
                                setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL);
                            }                            
                            break;              
                        case UNLOADING_UNKNOWN_MODE:
                            if (!glVars.unknownDevicesIsMarkedFlag){
                                glVars.unknownDevicesIsMarkedFlag = true;
                                //  включаем красные светодиоды в режиме мигания, для устройств, требующих повторную наработку
                                synchronizeCell(255, "OFF", "OFF", 0, glVars)
                                .then(() => {
                                    switchLEDS(UNLOADING_UNKNOWN_DEVICES, glVars);
                                })
                                .then(() => {
                                    setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL);
                                });
                            }
                            else{
                                setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL);
                            }
                            break;
                        case UNLOADING_GOOD_MODE:
                            if (!glVars.goodDevicesIsMarkedFlag){
                                glVars.goodDevicesIsMarkedFlag = true;
                                // включаем зеленые светодиоды для устройств, прошедших наработку\
                                synchronizeCell(255, "OFF", "OFF", 0, glVars)
                                .then(() => {
                                    switchLEDS(UNLOADING_GOOD_DEVICES, glVars);
                                })
                                .then(() => {
                                    setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL);
                                });
                            }
                            else{
                                setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL);
                            }
                            break;
                        case IDLE_MODE:
                            setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL);
                            break;
                        default:
                            setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL); 
                            break;
                        }

                    } // end modeAction
                    
                    if (glVars.receivedSignal.receiveFlag){
                        processSignal(glVars, benchStatusData)
                        .then(() => {
                            console.log("Сигнал " + glVars.receivedSignal.signal + " обработан");
                            glVars.receivedSignal.receiveFlag = false;
                            glVars.receivedSignal.signal = "";
                            glVars.receivedSignal.option = "";
                            modeAction(); 
                        });                        
                    }
                    else{
                        modeAction();
                    }
                });          
            });
            //console.log("ошибка связи с REST-сервисами");
            //setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL);
        }
        else{
           setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL); 
        }
        
        
    }


    // запускаем сервер на прослушивание порта 3000
    app.listen(port, () => {        
        logger("TE-1570 application server is started at port " + port);
        
        let cellNum = 1;
        // рекурсивная функция загрузки калибровочных коэффициентов
        const loadCalibration = (cellnum) => {
            if (cellnum <= glVars.NUM_CELLS){
            const pathString = "/api/get_calibration?machineserial=" + MACHINE_SERIAL + "&cellnumber=" + cellNum;
            getData("localhost", "3034", pathString)
            .then((answerArray) => {
                    if (answerArray !== null){
                        if (answerArray.length === 1){
                            const calibrationObject = {
                                current_0: answerArray[0].current_0,
                                current_ratio: answerArray[0].current_ratio
                            }
                            glVars.calibrationData.push(calibrationObject);                    
                        }
                        else{
                            logger("Ошибка чтения значения параметров калибровки ячейки " + cellnum + " стенда  " + MACHINE_SERIAL + " из БД");                        
                        }
                    cellNum++;
                    loadCalibration(cellNum);
                    }
                    else{
                        logger("Ошибка соединения с REST-службой драйвера БД");
                    }
            });
            }
            else{
                logger("Загрузка калибровочных коэффициентов завершена");
                // запускаем главный таймер
                setTimeout(mainTimerTick, glVars.MAIN_TIMER_INTERVAL);
            }
        }
        
        // загрузка параметров конфигурации    
        glVars.errorFlag = true;
        //рекурсивная функция загрузки данных из БД
        const recLoadingFunc = () => {
            logger("Соединение с драйвером БД ...");
            loadConfiguration(0, glVars)
            .then((answ) => {
                glVars.errorFlag = false;
                glVars.controlBlockStatusIndicatorColor = glVars.ORANGE_COLOR;
                glVars.scannerStatusIndicatorColor = glVars.ORANGE_COLOR;
                benchStatusData.startAppButtonColor = glVars.BACKGROUND_COLOR;
                benchStatusData.startRunningButtonColor = glVars.BACKGROUND_COLOR;
                benchStatusData.toControlButtonColor = glVars.BACKGROUND_COLOR;
                benchStatusData.unloadingPanelColor = glVars.ORANGE_COLOR;
                logger("Загрузка конфигурации завершена");
                logger("Загрузка списка устройств...");
                // загружаем список устройств
                getDeviceListFromDB()
                .then((answerArray) => {
                    if (answerArray !== null){
                        benchStatusData.devicesList = [];
                        answerArray.forEach((dev) => {
                            benchStatusData.devicesList.push({
                                deviceName: dev.deviceName,
                                deviceID: dev.id,
                                number_IR_Channels: Number(dev.numberIRChannels),
                                number_AC_Channels: Number(dev.numberACChannels),
                                maxCurrent_mA: Number(dev.maxCurrentmA),
                                startUpTime: Number(dev.startupTime),
                                runningTime: Number(dev.runningTime)
                            });
                        });
                    }
                    //logger(deviceSelectionModeData.devicesList);
                    logger("Загрузка списка устройств завершена");
                    // загрузка калибровочных коэффициентов
                    cellNum = 1;
                    logger("Загрузка калибровочных коэффициентов ...");
                    glVars.calibrationData.length = 0;
                    loadCalibration(cellNum);   
                });            
            });

            setTimeout(() => {                                
                if (glVars.errorFlag){
                    recLoadingFunc();
                }
            },1000);
        }
        
        recLoadingFunc();
        
        

                     

            
    });

    

}// end main()




main();