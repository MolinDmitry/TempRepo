/**
 * @breif REST-служба драйвера стенда ТЭ-1570
 * @version 1.5.1
 * Обеспечивает связь с первичным контроллером и узлами питания ячеек стенда 
 * На запрос клиентского приложения возвращает ответ в формате JSON
 * Вид запроса от клиента http://localhost:3030/te1570/exec?command=commandtype&parameter1=param1value&parameter2=param2value 
 * 
 * Алгоритм работы версии 1.2.0
 * - сначала запускается сервер
 * - в REST API добавлена команда открытия и закрытия COM-порта
 * - при поступлении команды открытия COM-порта сканируем порты, при наличии нужного открываем порт, поднимаем флаг открытия порта
 * - далее работаем как обычно, обрабатывая команды
 * - контроль связи по интерфейу RS-485 возложена на внешние приложения, которые производят опрос первичного контроллера, либо первого узла питания
 * - если ответы от них не приходят, возвращается ошибка "Отсутствие связи по интерфейсу RS-485"
 * - внешняя программа подает команды на закрытие и открытие COM-порта 
 * 
 * 
 * - Выполняем инициализацию
 *      npm init -y
 * - Устанавливаем express, serialport, cors локально
 *      npm install express --save
 *      npm install serialport --save
 *      npm install cors --save
 */

//=======================================================================================================
const calculateCheckSum = (base_pack) => {
    let cs = 0xFF;
    for(let i = 0; i < base_pack.length; i++){
        cs ^=base_pack[i];
    }
    return cs;
}

//=======================================================================================================

const createPackage = (command, address, dataLength, data) => {
    let base_pack = [0x55, command, address, dataLength];
    if (dataLength > 0){
        for(let i = 0; i < dataLength; i++){
            base_pack.push(data[i]);
        }
    }
    const cs = calculateCheckSum(base_pack);
    base_pack.push(cs);
    return base_pack;
}

//=======================================================================================================
const getTimeString = () => {
    let t = new Date();
    let date = (t.getDate() < 10)?("0"+t.getDate()):t.getDate();
    let mounth = (t.getMonth() < 9)?("0"+(t.getMonth()+1)):(t.getMonth()+1);
    let hours = (t.getHours() < 10)?("0"+t.getHours()):t.getHours();
    let min = (t.getMinutes() < 10)?("0"+t.getMinutes()):t.getMinutes();
    let sec = (t.getSeconds() < 10)?("0"+t.getSeconds()):t.getSeconds();

    let timeStr = date + "." + mounth + "." +  t.getFullYear() + " " + hours + ":" + min + 
    ":" + sec + " GMT" + ((t.getTimezoneOffset() < 0)?"+":"-") + (-1*t.getTimezoneOffset()/60) + " ";
    return timeStr;
};

//=======================================================================================================

const {SerialPort} = require("serialport");
const { ReadlineParser } = require("serialport");

let serialPortHandler = undefined;
let serialPortAnswerIsRecieved = false; // флаг прихода ответа по COM-порту
let answerWaitingTimerInWorkFlag = false; // флаг работы таймера ожидания ответа


const answerObject = {
    deviceType: 0,
    deviceAddress: 0,
    errorCode: 0,
    message: "",
    cellCurrent: 0,
    cellRelay1: 1,
    cellRelay2: 0,
    doorTS: 0,
    termosensorINT: 0.0,
    termoSensor1: 0.0,
    termoSensor2: 0.0,
    termoSensor3: 0.0,
    termoSensor4: 0.0,
    batteryStatus: "charged",
    batteryVoltage: 0,
    highVoltageFlag: 0,
    LED1status: 0,
    LED2status: 0,
    LED3status: 0,
    LEDflashPeriod: 0,
    line12Vstatus: 0,
    buzzerTime: 0,
    pcRelay1: 0,
    pcRelay2: 0,
    pcRelay3: 0
};

//=======================================================================================================
// функция открытия COM-порта
const getSerialPortHandler = () => {
    // открываем СОМ-порт после запука сервера
    console.log("Сканирование портов");
    SerialPort.list() 
        .then((ports) => {// обработка результата промиса
            let portName = "$PortName$";
            console.log("Количество портов: " + ports.length);
            ports.forEach((port, index) => {
                console.log("Порт: " + (index + 1));
                for (let key in port){
                    console.log("\t" + key + ": "+ port[key]);
                    if ((port["vendorId"]=="1A86") || (port["vendorId"]=="1a86")) portName = port["path"]; 
                }            
            })
            return portName;
        })
        .then((portName)=>{
            // открытие порта
            const comport = new SerialPort({
                path: portName,
                baudRate: 115200,
                autoOpen: true // создаем порт в открытом состоянии
                },
                    (err) => {
                        if (err){
                            return console.log("Error on open: ", err.message);
                        }                  
                    }
                );
            
            return comport;
        }).then((comport) => {
            serialPortHandler = comport;
            console.log(getTimeString() + " Последовательный порт " + serialPortHandler.path + " открыт");
            // назначаем обработчик принятых данных через COM-порт
            serialPortHandler.on("data", (data) => {
                // let st = "";
                // for(let i = 0; i < data.length; i++){
                //     st += data[i] + " ";
                // }
                // console.log("Принятые данные: " + st);
                serialPortAnswerIsRecieved = true;
                const cs = calculateCheckSum(data.slice(0, data.length - 1));
                if (cs != data[data.length - 1]){
                    answerObject.message = "Несовпадение контрольной суммы принятого пакета";
                    answerObject.errorCode = 4;
                }
                else{
                    answerObject.doorTS = 0;
                    answerObject.termosensorINT = 0.0;
                    answerObject.termoSensor1 = 0.0;
                    answerObject.termoSensor2 = 0.0;
                    answerObject.termoSensor3 = 0.0;
                    answerObject.termoSensor4 = 0.0;
                    answerObject.batteryStatus = "unknown";
                    answerObject.batteryVoltage = 0;
                    answerObject.highVoltageFlag = 0;
                    answerObject.cellCurrent = 0;
                    answerObject.cellRelay1 = 0;
                    answerObject.cellRelay2 = 0;
                    answerObject.LED1status = 0;
                    answerObject.LED2status = 0;
                    answerObject.LED3status = 0;
                    answerObject.LEDflashPeriod = 0;
                    answerObject.line12Vstatus = 0;
                    answerObject.buzzerTime = 0;
                    answerObject.pcRelay1 = 0;
                    answerObject.pcRelay2 = 0;
                    answerObject.pcRelay3 = 0;
                    if (data[2] == 220){// ответ от первичного контроллера
                        answerObject.deviceType = 1;
                        answerObject.deviceAddress = data[2];
                        answerObject.errorCode = 0;
                        answerObject.message = "Ответ первичного контроллера на команду " + data[1];
                        switch(data[1]){
                            case 0x00:
                                answerObject.message = "Первичный контроллер на линии";
                                break;
                            case 0x01:
                                answerObject.message = "Статус первичного контроллера";
                                answerObject.doorTS = ((data[4] & 0x01) === 1)? 0: 1;
                                answerObject.highVoltageFlag = (((data[4] >> 1) & 0x01) === 1)? 1: 0;
                                switch (data[5]){
                                    case 0x01:
                                        answerObject.batteryStatus = "low";
                                        break;
                                    case 0x02:
                                        answerObject.batteryStatus = "medium";
                                        break;
                                    case 0x03:
                                        answerObject.batteryStatus = "charging";
                                        break;
                                    case 0x04:
                                        answerObject.batteryStatus = "finalcharging";
                                        break;
                                    case 0x05:
                                        answerObject.batteryStatus = "charged";
                                        break;                                    
                                }
                                answerObject.batteryVoltage = data[6] + (data[7] << 8);
                                answerObject.termosensorINT = ((data[8] + (data[9] << 8)) - 27300)/100.0;
                                answerObject.termoSensor1 = ((data[10] + (data[11] << 8)) - 27300)/100.0;
                                answerObject.termoSensor2 = ((data[12] + (data[13] << 8)) - 27300)/100.0;
                                answerObject.termoSensor3 = ((data[14] + (data[15] << 8)) - 27300)/100.0;
                                answerObject.termoSensor4 = ((data[16] + (data[17] << 8)) - 27300)/100.0;
                                break;
                            case 0x02:
                                answerObject.message = "Индикация установлена";
                                break;
                            case 0x03:
                                answerObject.message = "Версия ПО первичного контроллера: " + 
                                data[4] + "." + data[5] + "." + data[6];;
                                break;
                            case 0x04:
                                answerObject.message = "Зуммер включен";
                                break;
                            case 0x05:
                                answerObject.message = "Зуммер выключен";
                                break;
                            case 0x06:
                                answerObject.message = "Состояние реле установлено";
                                break;
                            case 0x07:
                                answerObject.message = "Синхронизация данных первичного контроллера";
                                answerObject.doorTS = ((data[4] & 0x01) === 1)? 0: 1;
                                answerObject.highVoltageFlag = (((data[4] >> 1) & 0x01) === 1)? 1: 0;
                                switch (data[5]){
                                    case 0x01:
                                        answerObject.batteryStatus = "low";
                                        break;
                                    case 0x02:
                                        answerObject.batteryStatus = "medium";
                                        break;
                                    case 0x03:
                                        answerObject.batteryStatus = "charging";
                                        break;
                                    case 0x04:
                                        answerObject.batteryStatus = "finalcharging";
                                        break;
                                    case 0x05:
                                        answerObject.batteryStatus = "charged";
                                        break;                                    
                                }
                                answerObject.batteryVoltage = data[6] + (data[7] << 8);
                                answerObject.termosensorINT = ((data[8] + (data[9] << 8)) - 27300)/100.0;
                                answerObject.termoSensor1 = ((data[10] + (data[11] << 8)) - 27300)/100.0;
                                answerObject.termoSensor2 = ((data[12] + (data[13] << 8)) - 27300)/100.0;
                                answerObject.termoSensor3 = ((data[14] + (data[15] << 8)) - 27300)/100.0;
                                answerObject.termoSensor4 = ((data[16] + (data[17] << 8)) - 27300)/100.0;
                                answerObject.LED1status = ((data[18] >> 6) > 0)? 1: 0;
                                answerObject.LED2status = (((data[18] >> 4) & 0x03) > 0)? 1: 0;
                                answerObject.LED3status = (((data[18] >> 2) & 0x03) > 0)? 1: 0;
                                answerObject.LEDflashPeriod = data[19];
                                answerObject.buzzerTime = data[20];
                                answerObject.pcRelay1 = ((data[21] & 0x01) > 0)? 1: 0;
                                answerObject.pcRelay2 = (((data[21] >> 1) & 0x01) > 0)? 1: 0;
                                answerObject.pcRelay3 = (((data[21] >> 2) & 0x01) > 0)? 1: 0;
                                break;           
                        }                    
                    }
                    else{ // ответ от узла питания ячейки
                        answerObject.deviceType = 0;
                        answerObject.deviceAddress = data[2];
                        answerObject.errorCode = 0;                                        
                        switch (data[1]){
                            case 0x00: 
                                answerObject.message = "Узел питания с адресом " + data[2] + " на линии";
                                break;
                            case 0x01:
                                if (data[2] != 0) 
                                    answerObject.message = "Узел питания успешно зарегистрирован с адресом " + data[2];
                                else
                                    {
                                    answerObject.message = "Регистрация узла питания не удалась";
                                    answerObject.errorCode = 6;
                                    }
                                break;
                            case 0x02:
                                if (data[2] == 0) 
                                    answerObject.message = "Узел питания успешно удалён";
                                else
                                    {
                                    answerObject.message = "Удаление узла питания с адресом " + data[2] +  " не удалось";
                                    answerObject.errorCode = 7;
                                    }
                                break;
                            case 0x03: 
                                answerObject.message = "Питание ячейки с адресом " + data[2] + " установлено";
                                break;
                            case 0x04: 
                                answerObject.message = "Статус ячейки с адресом " + data[2];
                                answerObject.cellCurrent = ((data[5] & 0x0F)*256 + data[4])/10.0;
                                answerObject.cellRelay1 = (((data[5] >> 4) & 0x01) == 1)? 0: 1;
                                answerObject.cellRelay2 = (((data[5] >> 5) & 0x01) == 1)? 0: 1;
                                answerObject.termosensorINT = ((data[6] + (data[7] << 8)) - 27300)/100.0;
                                answerObject.errorCode = data[8];
                                break;
                            case 0x05: 
                                answerObject.message = "Индикация ячейки с адресом " + data[2] + " установлена";
                                break;
                            case 0x06: 
                                answerObject.message = "Версия ПО узла питания с адресом " + data[2] + ": " + 
                                                        data[4] + "." + data[5] + "." + data[6];
                                break;
                            case 0x08:
                                answerObject.message = "Синхронизация данных ячейки с адресом " + data[2];
                                answerObject.cellCurrent = ((data[5] & 0x0F)*256 + data[4])/10.0;
                                answerObject.cellRelay1 = (((data[5] >> 4) & 0x01) == 1)? 0: 1;
                                answerObject.cellRelay2 = (((data[5] >> 5) & 0x01) == 1)? 0: 1;
                                answerObject.termosensorINT = ((data[6] + (data[7] << 8)) - 27300)/100.0;
                                answerObject.errorCode = data[8];
                                answerObject.LED1status = ((data[9] >> 6) > 0)? 1: 0;
                                answerObject.LED2status = (((data[9] >> 4) & 0x03) > 0)? 1: 0;
                                answerObject.LEDflashPeriod = data[11];
                                answerObject.line12Vstatus = (((data[12] >> 1) & 0x01)  > 0)? 1: 0;
                                console.log(answerObject);
                                break;
                            default:
                                answerObject.message = "Ответ узла питания на неизвестную команду " + data[2];                            
                                break;
                        }
                    }
                }
               
            });
        }).then(()=>{
            // console.log(serialPortHandler);
            }).
        catch((err) => console.log("Port listing error ", err.message));

};


const main = () => {
    // запуск сервера
    const express = require("express");
        const cors = require("cors");
        const app = express();
        // при запуске с аргументом назначается номер порта: node app.js 3005
        const port = process.argv[2] || 3030;
        // разрешаем доступ к REST-сервису запросам с "http://localhost:3000"
        app.use(cors({
            origin: "http://localhost:3000"
        }));

        // обработчик запроса к серверу по пути  /te1570/exec?command=commandtype&parameter1=param1value&parameter2=param2value      
        app.get("/te1570/exec", (req, res) => {
            // console.log(req.query);
            let pack = undefined;
            if ((req.query.command === "get_serial_status") || 
                    (req.query.command === "open_serial") || 
                    (req.query.command === "close_serial")){// команды работы с COM-портом
                        switch(req.query.command){
                            case "get_serial_status":
                                if (serialPortHandler.isOpen){
                                    answerObject.message = "COM-порт открыт";
                                    answerObject.errorCode = 0;
                                }
                                else{
                                    answerObject.message = "COM-порт закрыт";
                                    answerObject.errorCode = 10;
                                }                    
                                res.send(answerObject);
                                return;
                            case "open_serial":
                                if (!serialPortHandler.isOpen){
                                    serialPortHandler.open(() => {
                                    answerObject.message = "OK";
                                    answerObject.errorCode = 0;
                                    res.send(answerObject);
                                    console.log(getTimeString() + " Последовательный порт " + serialPortHandler.path + " открыт");
                                    }, (err) => {
                                        answerObject.message = "ERROR: " + err.message;
                                        answerObject.errorCode = 11;
                                        res.send(answerObject);
                                        console.log(getTimeString() + " Ошибка открытия последовательного порта " + serialPortHandler.path + ": " + err.message);
                                    });
                                }
                                else{
                                    answerObject.message = "OK";
                                    answerObject.errorCode = 0;
                                    res.send(answerObject);
                                }                                
                                return;
                            case "close_serial":
                                if (serialPortHandler.isOpen){
                                    serialPortHandler.close(() => {
                                        answerObject.message = "OK";
                                        answerObject.errorCode = 0;
                                        res.send(answerObject);
                                        console.log(getTimeString() + " Последовательный порт " + serialPortHandler.path + "  закрыт");
                                        
                                    }, (err)=>{
                                        answerObject.message = "ERROR: " + err.message;
                                        answerObject.errorCode = 12;
                                        res.send(answerObject);
                                        console.log(getTimeString() + " Ошибка закрытия последовательного порта " + serialPortHandler.path + ": " + err.message);
                                    });
                                }
                                else{
                                    answerObject.message = "OK";
                                    answerObject.errorCode = 0;
                                    res.send(answerObject);
                                }
                                return;
                        }
                }                    
                else{
                    // запросы к ячейке
                    if (!serialPortHandler.isOpen){
                        answerObject.message = "COM-порт закрыт";
                        answerObject.errorCode = 10;
                        res.send(answerObject);
                        return;
                    }
                    // формируем пакеты запросов к узлам питания или первичному контроллеру
                    let devAddress = req.query.address;
                    let intAddress = parseInt(devAddress);
                    if (isNaN(intAddress)){ // если в адресе нечисловое значение
                        answerObject.message = "Параметр адреса содержит нечисловое значение";
                        answerObject.errorCode = 1;
                        res.send(answerObject);
                        return;
                    }
                    if ((intAddress < 0) || (intAddress > 255)){// недопустимый диапазон адреса устройства 
                        answerObject.message = "Недопустимый диапазон адреса устройства";
                        answerObject.errorCode = 2;
                        res.send(answerObject);
                        return;
                    }
                    switch(req.query.command){
                    case "echo":
                        pack = createPackage(0x00, intAddress, 0x00, undefined);                                    
                        break;
                    case "registration":
                        pack = createPackage(0x01, 0x00, 0x01, [intAddress]);
                        break;
                    case "delete":
                        pack = createPackage(0x02, intAddress, 0x00, undefined);  
                        break;
                    case "status":
                        if (intAddress === 220){
                            pack = createPackage(0x01, intAddress, 0x00, undefined); 
                        }
                        else{
                            pack = createPackage(0x04, intAddress, 0x00, undefined); 
                        }                        
                        break;
                    case "sw_version":
                        if (intAddress === 220){
                            // для первичного контроллера
                            pack = createPackage(0x03, intAddress, 0x00, undefined); 
                        }
                        else{
                            // для узлов питания
                            pack = createPackage(0x06, intAddress, 0x00, undefined);
                        }                            
                        break;
                    case "set_led":
                        const LEDstatus = parseInt(req.query.led_status);
                        if (isNaN(LEDstatus)){
                            answerObject.message = "Параметр запроса содержит нечисловое значение";
                            answerObject.errorCode = 1;
                            res.send(answerObject);
                            return;
                        }
                        if (intAddress === 220){
                            // для первичного контроллера
                            pack = createPackage(0x02, intAddress, 0x01, [LEDstatus]);
                        }
                        else{
                            // для узла питания
                            pack = createPackage(0x05, intAddress, 0x01, [LEDstatus]);
                        }
                        break;
                    case "set_relay":
                        const RelayStatus = parseInt(req.query.relay_status);
                        if (isNaN(RelayStatus)){
                            answerObject.message = "Параметр запроса содержит нечисловое значение";
                            answerObject.errorCode = 1;
                            res.send(answerObject);
                            return;
                        }
                        pack = createPackage(0x06, intAddress, 0x01, [RelayStatus]);                        
                        break;
                    case "set_power":
                        const lineStatus = parseInt(req.query.line_status);
                        if (isNaN(lineStatus)){
                            answerObject.message = "Параметр запроса содержит нечисловое значение";
                            answerObject.errorCode = 1;
                            res.send(answerObject);
                            return;
                        }
                        pack = createPackage(0x03, intAddress, 0x01, [lineStatus]);
                        break;
                    case "buzzer_on":
                        pack = createPackage(0x04, intAddress, 0x00, undefined);
                        break;
                    case "buzzer_off":
                        pack = createPackage(0x05, intAddress, 0x00, undefined);
                        break;
                    case "get_serial_status":
                        if (serialPortHandler.isOpen){
                            answerObject.message = "COM-порт открыт";
                            answerObject.errorCode = 0;
                        }
                        else{
                            answerObject.message = "COM-порт закрыт";
                            answerObject.errorCode = 10;
                        }                    
                        res.send(answerObject, () => {
                            console.log("Статус COM-porta отправлен");
                        });
                        return;
                    case "sync":
                        const LEDstatus_sync = parseInt(req.query.led_status);
                        const lineStatus_sync = parseInt(req.query.line_status);
                        const LEDflashPeriod_sync = parseInt(req.query.led_flash_period);
                        if (isNaN(LEDstatus_sync) || isNaN(lineStatus_sync) || isNaN(LEDflashPeriod_sync)){
                            answerObject.message = "Параметр запроса содержит нечисловое значение";
                            answerObject.errorCode = 1;
                            res.send(answerObject);
                            return;
                        }
                        pack = createPackage(0x08, intAddress, 0x04, [LEDstatus_sync, lineStatus_sync, 1, LEDflashPeriod_sync]);
                        break;
                    case "sync_pc":
                        const LEDstatus_syncpc = parseInt(req.query.led_status);
                        const LEDflashPeriod_syncpc = parseInt(req.query.led_flash_period);
                        const buzzerTime_syncpc = parseInt(req.query.buzzer_time);
                        const relayStatus_syncpc = parseInt(req.query.relay_status); 
                        if (isNaN(LEDstatus_syncpc) || isNaN(buzzerTime_syncpc) || 
                            isNaN(LEDflashPeriod_syncpc) || isNaN(relayStatus_syncpc)){
                            answerObject.message = "Параметр запроса содержит нечисловое значение";
                            answerObject.errorCode = 1;
                            res.send(answerObject);
                            return;
                        }
                        pack = createPackage(0x07, 0xDC, 0x04, [LEDstatus_syncpc, LEDflashPeriod_syncpc, buzzerTime_syncpc, relayStatus_syncpc]);
                        break; 
                    default:
                        answerObject.message = "Получен неизвестный тип команды";
                        answerObject.errorCode = 3;
                        res.send(answerObject);
                        return;
                    }
                    
                    let waitingPeriodCounter = 0; // счетчик периодов ожидания
                    // проверяем, не работает ли таймер ожидания ответа от предыдущего запроса
                    const writingToSerialPort = () => {
                        if (!answerWaitingTimerInWorkFlag){ // если таймер завершил работу
                            serialPortAnswerIsRecieved = false;
                            waitingPeriodCounter = 0;
                            serialPortHandler.write(new Uint8Array(pack), (err) => {
                                if (err) {
                                    console.log("Writing error: ", err.message);
                                }
                            });
                        }
                        else{// если таймер еще работает
                            setTimeout(writingToSerialPort, 5); // ожидаем 5 мс и повторяем попытку
                        }                        
                    }

                    writingToSerialPort();
                    
                    const waitingAnswer = () => {
                        if (serialPortAnswerIsRecieved){// если от COM-порта пришел ответ
                            answerWaitingTimerInWorkFlag = false;
                            waitingPeriodCounter = 0;
                            // отправляем ответ
                            res.send(answerObject);
                            serialPortAnswerIsRecieved = false;
                        }
                        else{// если ответ не ещё пришел
                            waitingPeriodCounter++;
                            if (waitingPeriodCounter === 100){
                                 // нет ответа от устройства за требуемое время
                                 answerObject.message = "Нет ответа от устройства с адресом " + intAddress + " за требуемое время";
                                if (intAddress === 220) {
                                    answerObject.deviceType = 1;
                                }
                                else {
                                    answerObject.deviceType = 0;
                                }
                                answerObject.errorCode = 5;
                                answerObject.deviceAddress = intAddress;
                                // отправляем ответ
                                res.send(answerObject);
                                waitingPeriodCounter = 0;
                                answerWaitingTimerInWorkFlag = false;
                                serialPortAnswerIsRecieved = false;
                            }
                            else{
                                setTimeout(waitingAnswer, 1);
                            }
                        }
                    }; 
                    
                    // запускаем таймер ожидания ответа устройства
                    answerWaitingTimerInWorkFlag = true;
                    setTimeout(waitingAnswer, 1);
                }
        });

        // включаем прослушивание порта
        app.listen(port, () => {
            console.log("REST-служба драйвера стенда ТЭ-1570 запущена. Номер порта: ", port);
            getSerialPortHandler();

            
        });


        

}


main();