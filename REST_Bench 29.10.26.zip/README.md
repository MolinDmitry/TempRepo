# REST-служба драйвера стенда ТЭ-1570

Обеспечивает связь с первичным контроллером и узлами питания ячеек стенда 
 На запрос клиентского приложения возвращает ответ в формате JSON
 Вид запроса от клиента http://localhost:3030/te1570/exec?command=commandtype&parameter1=param1value&parameter2=param2value
 command - имя команды 