# Порядок создания базы данных стенда ТЭ-1570

## Запускаем СУБД
- mysql -h localhost -u root -p
W@nn@be007 / либо парольскл1! в английской раскладке

## Посмотреть пользователей
SELECT User, Host FROM mysql.user;

## Создать пользователя
CREATE USER 'username'@'host' IDENTIFIED BY 'password'

Создаем cуперпользователя b1570su с паролем парольскл1! в английской раскладке
CREATE USER 'b1570su'@'localhost' IDENTIFIED BY 'gfhjkmcrk1!'

Создаем пользователя b1570 с паролем парольскл1! в английской раскладке
CREATE USER 'b1570'@'localhost' IDENTIFIED BY 'gfhjkmcrk1!'

REST служба обращается к БД от имени b1570, пользователь b1570su нужен для создания и удаления таблиц и записей

## Наделяем суперпользователя b1570su полными правами
GRANT ALL PRIVILEGES ON *.* TO 'b1570su'@'localhost' WITH GRANT OPTION;

## Наделяем пользователя b1570 правами изменения данных в таблице calibration
GRANT INSERT, UPDATE ON b1570_db.calibration TO 'b1570'@'localhost';
 
## Удалить пользователя
DROP USER 'username'@'host'

## Список баз данных
SHOW DATABASES;

## Создать БД
CREATE DATABASE b1570_db

## Использование БД
USE b1570_db;

## Создание таблиц
Создаем таблицы от имени пользователя b1570su
### таблица machines
CREATE TABLE machines (
machineSerial  INT UNSIGNED PRIMARY KEY,
machine VARCHAR(30),
machineLocation VARCHAR(150) 
);
### таблица configuration
CREATE TABLE configuration (
id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
parameterName VARCHAR(100),
parameterValue VARCHAR(200),
machineSerial  INT UNSIGNED,
FOREIGN KEY (machineSerial) REFERENCES machines (machineSerial)
);

### Таблица devicelist
CREATE TABLE devicelist(
id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
deviceName VARCHAR(50),
productVersion VARCHAR(30),
firmwareVersion VARCHAR(30),
numberIRChannels TINYINT UNSIGNED,
numberACChannels TINYINT UNSIGNED,
maxCurrentmA TINYINT UNSIGNED,
startupTime INT UNSIGNED,
runningTime INT UNSIGNED,
actuality BOOL
);

### Таблица operators
CREATE TABLE operators(
operatorCode CHAR(9) PRIMARY KEY,
firstname VARCHAR(40),
lastname  VARCHAR(40),
role_code  TINYINT UNSIGNED,
operatorValidity BOOL
);

### Таблица tests
CREATE TABLE tests(
id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
barcode VARCHAR(30),
date_time DATETIME,
productId INT UNSIGNED,
testResult VARCHAR(30),
operatorCode CHAR(9),
machineSerial  INT UNSIGNED,
cellNumber INT,
FOREIGN KEY (productId) REFERENCES devicelist (id), 
FOREIGN KEY (operatorCode) REFERENCES operators (operatorCode),
FOREIGN KEY (machineSerial) REFERENCES machines (machineSerial)
);

### Таблица testoperations
CREATE TABLE testoperations(
testoperationID INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
testID INT UNSIGNED,
testType VARCHAR (50),
testResult VARCHAR (30),
parameterValue INT UNSIGNED, 
lowerLimit INT UNSIGNED,
upperLimit INT UNSIGNED,
FOREIGN KEY (testID) REFERENCES tests (id) 
);

### Таблица b1570logs
CREATE TABLE b1570logs(
id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
date_time DATETIME,
message TEXT 
);

### Таблица calibration
CREATE TABLE calibration(
id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
machineSerial  INT UNSIGNED,
cellNumber INT UNSIGNED,
current_0 FLOAT,
current_ratio FLOAT,
FOREIGN KEY (machineSerial) REFERENCES machines (machineSerial)
);


## добавляем записи в таблицы
### добавляем записи в таблицу machines
INSERT INTO machines (machineSerial, machine, machineLocation)
VALUES (0, 'ТЭ-1570', 'Неопределено'); - стенд с серийным номером 0 необходим для обосначения настрек, применяемых для всех стендов
INSERT INTO machines (machineSerial, machine, machineLocation)
VALUES (26157001, 'ТЭ-1570', 'Цех 1. Участок 1'); - стенд с серийным номером 26157001

### добавляем записи в таблицу configuration
INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('NUM_CELLS', '3', 0); - значение параметра NUM_CELLS равно 3, применяется ко всем стендам

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('LEDS_INIT_LIGHT_INTERVAL', '1000', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('currentLoadingThreshold', '5', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('shortcutCurrentThreshold', '25', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('falseAlarmIR_threshold', '0', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('falseAlarmAC_threshold', '0', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('highCurrentCounter_threshold', '0', 0);


INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('errorConnectionCounter_threshold', '0', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('ledFlashingPeriod', '50', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('SPACE_TIME', '10', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('MAIN_TIMER_INTERVAL', '1000', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('GREEN_COLOR', 'rgb(42, 109, 58)', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('BLACK_COLOR', 'rgb(37, 37, 37)', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('GREY_COLOR', 'rgb(128, 128, 128)', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('RED_COLOR', 'rgb(105, 21, 28)', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('ORANGE_COLOR', 'rgb(197, 148, 128)', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('BLUE_COLOR', 'rgb(20, 128, 190)', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('CREAM_COLOR', 'rgb(245, 226, 203)', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('CELL_STATUS_SERIAL_WAITING_STRING', 'Ожидание ввода серийного номера извещателя', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('CELL_STATUS_NOT_ALLOWED_STRING', 'Извещатель не допущен к наработке', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('CELL_STATUS_LOADING_WAITING_STRING', 'Ожидание установки извещателя в ячейку', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('CELL_STATUS_SHORTCUT_STRING', 'Обнаружено короткое замыкание в извещателе', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('CELL_STATUS_READY_STRING', 'Ячейка заполнена', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('CELL_STATUS_START_RUNNING_WAITING_STRING_1', '<p>Вся ячейки заполнены. </p> <p>Закройте дверь стенда и нажмите \"Приступить к наработке\"</p>', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('CELL_STATUS_START_RUNNING_WAITING_STRING_2', '<p>Обнаружены незаполненные/неисправные ячейки.  </p><p>Закройте дверь стенда и нажмите \"Приступить к наработке\"</p>', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('CELL_STATUS_START_RUNNING_WAITING_STRING_3', 'Ни одна из ячеек не заполнена', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('BENCH_STATUS_DOOR_OPEN_STRING', 'Дверь стенда открыта', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('BENCH_STATUS_DEVICES_STARTUP_STRING', 'Выход изделий на режим', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('BENCH_STATUS_RUNNING_IN_PROCESS_STRING', 'Идет наработка', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('BENCH_STATUS_RUNNING_COMPLETE_STRING', 'Наработка завершена', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('REPEAT_STRING', 'Требует повторной наработки', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('UNLOADING_BAD_STRING', 'Снимите извещатели, не прошедшие наработку', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('UNLOADING_UNKNOWN_STRING', 'Снимите извещатели, требующие повторную наработку', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('UNLOADING_GOOD_STRING', 'Снимите извещатели, прошедшие наработку', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('MAIN_TIMER_COUNTER_MAX_VALUE', '1000', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('UP_STATE_LOG_PERIOD', '300', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('alarmFallingTime', '5', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('BACKGROUND_COLOR', 'rgb(240,240,240)', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('DARK_GREEN_COLOR', 'rgb(22,110,42)', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('STRONG_RED_COLOR', 'rgb(255,0,25)', 0);

INSERT INTO configuration (parameterName, parameterValue, machineSerial)
VALUES ('STRONG_ORANGE_COLOR', 'rgb(190, 74, 20)', 0);

### добавляем записи в таблицу devicelist
INSERT INTO devicelist (deviceName, productVersion, firmwareVersion, numberIRChannels, numberACChannels, maxCurrentmA,
startupTime, runningTime, actuality)
VALUES ('Астра-5 исп.А', NULL, NULL, 1, 0, 12, 3, 10, TRUE);

INSERT INTO devicelist (deviceName, productVersion, firmwareVersion, numberIRChannels, numberACChannels, maxCurrentmA,
startupTime, runningTime, actuality)
VALUES ('Астра-5 исп.Б', NULL, NULL, 1, 0, 12, 60, 14400, TRUE);

INSERT INTO devicelist (deviceName, productVersion, firmwareVersion, numberIRChannels, numberACChannels, maxCurrentmA,
startupTime, runningTime, actuality)
VALUES ('Астра-5 исп.В', NULL, NULL, 1, 0, 12, 60, 14400, TRUE);

INSERT INTO devicelist (deviceName, productVersion, firmwareVersion, numberIRChannels, numberACChannels, maxCurrentmA,
startupTime, runningTime, actuality)
VALUES ('Астра-5 исп.АМ', NULL, NULL, 1, 0, 16, 60, 14400, TRUE);

INSERT INTO devicelist (deviceName, productVersion, firmwareVersion, numberIRChannels, numberACChannels, maxCurrentmA,
startupTime, runningTime, actuality)
VALUES ('Астра-7', NULL, NULL, 1, 0, 25, 60, 14400, TRUE);

INSERT INTO devicelist (deviceName, productVersion, firmwareVersion, numberIRChannels, numberACChannels, maxCurrentmA,
startupTime, runningTime, actuality)
VALUES ('Астра-8', NULL, NULL, 1, 1, 21, 3, 10, TRUE);

INSERT INTO devicelist (deviceName, productVersion, firmwareVersion, numberIRChannels, numberACChannels, maxCurrentmA,
startupTime, runningTime, actuality)
VALUES ('Астра-9', NULL, NULL, 1, 0, 15, 60, 14400, TRUE);

INSERT INTO devicelist (deviceName, productVersion, firmwareVersion, numberIRChannels, numberACChannels, maxCurrentmA,
startupTime, runningTime, actuality)
VALUES ('Астра-512', NULL, NULL, 1, 0, 15, 60, 14400, TRUE);

INSERT INTO devicelist (deviceName, productVersion, firmwareVersion, numberIRChannels, numberACChannels, maxCurrentmA,
startupTime, runningTime, actuality)
VALUES ('Астра-515', NULL, NULL, 1, 0, 15, 60, 14400, TRUE);

INSERT INTO devicelist (deviceName, productVersion, firmwareVersion, numberIRChannels, numberACChannels, maxCurrentmA,
startupTime, runningTime, actuality)
VALUES ('Астра-516', NULL, NULL, 1, 0, 15, 60, 14400, TRUE);

INSERT INTO devicelist (deviceName, productVersion, firmwareVersion, numberIRChannels, numberACChannels, maxCurrentmA,
startupTime, runningTime, actuality)
VALUES ('Астра-517', NULL, NULL, 1, 0, 12, 60, 14400, TRUE);

INSERT INTO devicelist (deviceName, productVersion, firmwareVersion, numberIRChannels, numberACChannels, maxCurrentmA,
startupTime, runningTime, actuality)
VALUES ('Астра-531 исп. ИК', NULL, NULL, 1, 0, 18, 60, 14400, TRUE);

INSERT INTO devicelist (deviceName, productVersion, firmwareVersion, numberIRChannels, numberACChannels, maxCurrentmA,
startupTime, runningTime, actuality)
VALUES ('Астра-531 исп. АК', NULL, NULL, 0, 1, 18, 60, 14400, TRUE);

INSERT INTO devicelist (deviceName, productVersion, firmwareVersion, numberIRChannels, numberACChannels, maxCurrentmA,
startupTime, runningTime, actuality)
VALUES ('Астра-531 исп. СМ', NULL, NULL, 1, 1, 18, 60, 14400, TRUE);

INSERT INTO devicelist (deviceName, productVersion, firmwareVersion, numberIRChannels, numberACChannels, maxCurrentmA,
startupTime, runningTime, actuality)
VALUES ('Астра-С', NULL, NULL, 0, 1, 12, 60, 14400, TRUE);

INSERT INTO devicelist (deviceName, productVersion, firmwareVersion, numberIRChannels, numberACChannels, maxCurrentmA,
startupTime, runningTime, actuality)
VALUES ('Астра-612', NULL, NULL, 1, 0, 18, 60, 14400, TRUE);

INSERT INTO devicelist (deviceName, productVersion, firmwareVersion, numberIRChannels, numberACChannels, maxCurrentmA,
startupTime, runningTime, actuality)
VALUES ('Астра-621', NULL, NULL, 1, 1, 15, 60, 14400, TRUE);

### добавляем записи в таблицу operators
INSERT INTO operators (operatorCode, firstname, lastname, role_code, operatorValidity)
VALUES ('950202001', 'Иванов', 'Иван', 1, TRUE);

INSERT INTO operators (operatorCode, firstname, lastname, role_code, operatorValidity)
VALUES ('950202002', 'Петров', 'Петр', 1, TRUE);

### добавляем записи в таблицу calibration
INSERT INTO calibration (machineSerial, cellNumber, current_0, current_ratio)
VALUES (26157001, 1, 0, 1);

INSERT INTO calibration (machineSerial, cellNumber, current_0, current_ratio)
VALUES (26157001, 2, 0, 1);

INSERT INTO calibration (machineSerial, cellNumber, current_0, current_ratio)
VALUES (26157001, 3, 0, 1);

### примеры добавления записи в таблицу tests
INSERT INTO tests (barcode, date_time, productId, testResult, operatorCode, machineSerial, 
cellNumber)
VALUES ('504381001', '2026-04-14 12:07:37', 1, 'Good', 950202001, 26157001, 1);
INSERT INTO tests (barcode, date_time, productId, testResult, operatorCode, machineSerial, 
cellNumber)
VALUES ('504381002', '2026-04-14 12:07:37', 1, 'Bad', 950202001, 26157001, 2);
INSERT INTO tests (barcode, date_time, productId, testResult, operatorCode, machineSerial, 
cellNumber)
VALUES ('504381003', '2026-04-14 12:07:37', 1, 'Unknown', 950202001, 26157001, 3);



### пример добавления записи в таблицу testOperations
INSERT INTO testOperations(testID, testType, testResult, parameterValue, lowerLimit, upperLimit)
VALUES (1, 'Количество ложных срабатываний ИК канала', 'Good', 0, 0, 0);
INSERT INTO testOperations(testID, testType, testResult, parameterValue, lowerLimit, upperLimit)
VALUES (1, 'Выход потребляемого тока за пределы диапазона', 'Bad', 10, 0, 0);

CREATE TABLE testOperations(
testOperationID INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
testID INT UNSIGNED,
testType VARCHAR (50),
testResult VARCHAR (30),
parameterValue INT UNSIGNED, 
lowerLimit INT UNSIGNED,
upperLimit INT UNSIGNED,
FOREIGN KEY (testID) REFERENCES tests (id) 
);


## Посмотреть список таблиц
SHOW TABLES;


## Наделяем пользователя b1570 правами на SELECT, INSERT для всех таблиц БД b1570_db
GRANT SELECT, INSERT ON b1570_db.* TO 'b1570'@'localhost';
