/**
 * @brief
 * Константы 
 */

export const GREEN_COLOR = "rgb(164, 214, 176)";
export const DARK_GREEN_COLOR = "rgb(22, 110, 42)";
export const BLACK_COLOR = "rgb(37, 37, 37)";
export const GREY_COLOR = "rgb(128, 128, 128)";
export const RED_COLOR = "rgb(197, 147, 152)";
export const STRONG_RED_COLOR = "rgb(255, 0, 25)";
export const ORANGE_COLOR = "rgb(197, 148, 128)";
export const BLUE_COLOR = "rgb(20, 128, 190)";
export const CREAM_COLOR = "rgb(245, 226, 203)";
export const BACKGROUND_COLOR = "rgb(240, 240, 240)";


export const IDLE_MODE = 0;
export const STANDBY_MODE = 1;
export const SELFTEST_MODE = 2;
export const AUTHORIZATION_MODE = 3;
export const DEVICE_SELECTION_MODE = 4;
export const LOADING_MODE = 5;
export const ENTER_STANDBY_MODE = 6;
export const DOOR_CLOSING_WAITING_MODE = 7;
export const STANDBY_CHECKUP_MODE = 8;
export const STANDBY_CHECKUP_RESULTS_MODE = 9;
export const IR_CHECKUP_BEFORE_RUNNING_MODE = 10;
export const LOWFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE = 11;
export const HIGHFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE = 12;
export const SOUND_ALARM_CHECKUP_BEFORE_RUNNING_MODE = 13;
export const RUNNING_MODE = 14;
export const CHECKUP_IR_AFTER_RUNNING_MODE = 15;
export const LOWFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE = 16;
export const HIGHFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE = 17;
export const SOUND_ALARM_CHECKUP_AFTER_RUNNING_MODE = 18;
export const REPORT_PREPARING_MODE = 19;
export const REPORT_MODE = 20;
export const UNLOADING_MODE = 21;
export const UNLOADING_GOOD_MODE = 22;
export const UNLOADING_BAD_MODE = 23;
export const UNLOADING_UNKNOWN_MODE = 24;


export const CELL_STATUS_SERIAL_WAITING_STRING = "Ожидание ввода серийного номера извещателя";
export const CELL_STATUS_NOT_ALLOWED_STRING = "Извещатель не допущен к наработке";
export const CELL_STATUS_LOADING_WAITING_STRING = "Ожидание установки извещателя в ячейку";
export const CELL_STATUS_SHORTCUT_STRING = "Обнаружено короткое замыкание в извещателе";
export const CELL_STATUS_READY_STRING = "Ячейка заполнена";
export const CELL_STATUS_START_RUNNING_WAITING_STRING_1 = "<p>Вся ячейки заполнены. </p> <p>Закройте дверь стенда и нажмите \"Далее\"</p>";
export const CELL_STATUS_START_RUNNING_WAITING_STRING_2 = "<p>Обнаружены незаполненные/неисправные ячейки.  </p><p>Закройте дверь стенда и нажмите \"Далее\"</p>";
export const CELL_STATUS_START_RUNNING_WAITING_STRING_3 = "Ни одна из ячеек не заполнена";


export const CELL_STATUS_IDLE = 0;
export const CELL_STATUS_SERIAL_WAITING = 1;
export const CELL_STATUS_NOT_ALLOWED = 2;
export const CELL_STATUS_LOADING_WAITING = 3;
export const CELL_STATUS_SHORTCUT = 4;
export const CELL_STATUS_READY = 5;
export const CELL_STATUS_START_RUNNING_WAITING = 6;
export const CELL_STATUS_12V_TURNING_ON = 7;

export const BENCH_STATUS_DOOR_OPEN_STRING = "Дверь стенда открыта";
export const BENCH_STATUS_DEVICES_STARTUP_STRING = "Выход изделий на режим";
export const BENCH_STATUS_RUNNING_IN_PROCESS_STRING = "Идет наработка"; 
export const BENCH_STATUS_RUNNING_COMPLETE_STRING = "Наработка завершена";

export const SUCCES_STRING = "<br><br><br><br><br><b>Все извещатели успешно прошли наработку</b><br><br><br><br><br>";
export const REPEAT_STRING ="Требует повторной наработки";


export const NUM_CELLS = 3; // количество ячеек в стенде
export const currentLoadingThreshold = 5; // порог тока обнаружения установки извещателя в ячейку
export const shortcutCurrentThreshold = 25; // порог обнаружения короткого замыкания в цепи питания извещателя
export const MAIN_TIMER_INTERVAL = 250; // интервал главного таймера, мс (250)
export const SCANNER_TIMER_INTERVAL = 300; // интервал таймера опроса сканера штрихкодов, мс
export const LEDS_INIT_LIGHT_INTERVAL = 1000; // время свечения светодиодов ячеек при инициализации       

export const PRIMARY_CONTROLLER_ADDRESS = 220;//220; // адрес первичного контроллера
