/**
 * @brief
 * Библиотека функций обработки событий от элементов GUI
 * 
 *  */

import {
    GREEN_COLOR,
    DARK_GREEN_COLOR,
    BLACK_COLOR,
    ORANGE_COLOR,
    SUCCES_STRING,
    BACKGROUND_COLOR,
    GREY_COLOR
    } from "..//scripts/constants.js";

import {
    getData,
    waitForFlagUpdate2
} from "../scripts/REST.js";

const screenKeyboardActivity = {
        activityFlag: false,
        cellNumInputFlag: true
    }

const cellStatusFlags = {
    cellSerialWaitingStatusFlag: false
}






//===========================================================================================================
/**
 * @brief Отправка сигнала REST-службе драйвера стенда
 * 
 */
export const sendSignal = (event, signalType, option) => {
    let queryString  = "http://localhost:3000/process_signal?signal=";
    queryString += signalType;
    queryString +="&option=";
    queryString += option; 

    return new Promise((resolve) =>{
        // рекурсивная функция отправки сигнала
        const tryingToSend = () => {
            const req = new XMLHttpRequest();        
            req.onload = () => {
                if (req.response.performed){
                    resolve(1); 
                }
                else{
                    setTimeout(() => {
                        tryingToSend();
                    }, 500);
                }                 
            };    
            req.open("GET", queryString);
            req.responseType = "json";
            req.send();
        }
    tryingToSend();
        
    });   
};

//===========================================================================================================
/**
 * @brief Обновление формы самотестирования
 * 
 */
export const updateSelfTestForm = (benchModel) => {
    document.getElementById("selfTestingForm").style.display = "";
    document.getElementById("selfTestingResult").innerHTML = benchModel.selfTestingResult;
    document.getElementById("startAppButton").style.backgroundColor = benchModel.startAppButtonColor;
    cellStatusFlags.cellSerialWaitingStatusFlag = false;
    if (benchModel.startAppButtonDisabled){
        document.getElementById("startAppButton").disabled = true;
    }        
    else{
        document.getElementById("startAppButton").disabled = false;
    }
        
}

//===========================================================================================================
/**
 * @brief Обновление формы авторизации
 * 
 */
export const updateAuthorizationForm = (benchModel) => { 
    return new Promise((resolve) => {
        document.getElementById("selfTestingForm").style.display = "none";
        document.getElementById("unloadingForm").style.display = "none";  
        document.getElementById("deviceForm").style.display = "none";  
        document.getElementById("autorizationForm").style.display = "";
        document.getElementById("screenKeyboard").style.display = "";
        document.getElementById("forwardBtn").disabled = true;
        document.getElementById("forwardBtn").style.backgroundColor = BACKGROUND_COLOR;
        if (benchModel.newData === true)
        {
            document.getElementById("operatorCode").value = benchModel.barcodeData;
            sendSignal(undefined, "CLEAR_BARCODE_DATA", undefined)
            .then(() => {
                const waitForBarcodeDataClear = () => {
                    setTimeout(() => {
                        getData("get_bench_status")
                        .then((answ) => {
                            if (answ.newData === true){
                                waitForBarcodeDataClear();
                            }
                            else{
                                resolve(0);
                            }
                        });
                    }, 500);                    
                }
                waitForBarcodeDataClear();
            });
        } 
        if (benchModel.DeviceSelectPanelIsGenerated){
            removeDeviceSelectPanel(benchModel.devicesList);
            sendSignal(undefined, "SET_DEV_SELECT_PANEL_FLAG", "false")
            .then(() => {
                sendSignal(undefined, "GO_TO_AUTHORIZATION", undefined)
                .then(() => {
                    resolve(0);
                });
            });
        }
        else{
            resolve(0);
        }
    }); 
    

}

//===========================================================================================================
/**
 * @brief Обработчик нажатия на кнопку на форме авторизации 
 * 
 */
export const processLogInButtonClick = (event) => {
    const barcode = document.getElementById("operatorCode").value;
    getData("check_user?code="+barcode)
    .then((answerObject) => {
        if (answerObject.userIsApproved){
            sendSignal(undefined, "GO_TO_DEVICE_SELECTION", undefined)
            .then((answ) => {
                document.getElementById("operatorCode").value = "";
            });
        }
        else{
            alert("Незарегистрированный пользователь!");
        }
    });
}





//===========================================================================================================
//==============================     ФОРМА ВЫБОРА УСТРОЙСТВА  ===============================================
//===========================================================================================================



//===========================================================================================================
/**
 * @brief Выбор устройства
 * 
 */
const selectDevice = (event, btn, benchModel) => { 
    let selectButtons = document.getElementsByClassName("selectDeviceBtn");
    for (const el of selectButtons){
        el.style.backgroundColor =  BACKGROUND_COLOR;
    }
    btn.style.backgroundColor = GREEN_COLOR;
    document.getElementById("forwardBtn").disabled = false;
    document.getElementById("forwardBtn").style.backgroundColor = GREEN_COLOR;
    let deviceID = -1;
    for(let i = 0; i< benchModel.devicesList.length;i++){
        if (btn.innerText === benchModel.devicesList[i].deviceName){
            deviceID = i;
            break;            
        }        
    }
    sendSignal(undefined, "SET_SELECTED_DEVICE", deviceID);
}


//===========================================================================================================
/**
 * @brief Создание панели выбора устройств
 * 
 */
export const generateDeviceSelectPanel = (benchModel) => {
        return new Promise((resolve) => {
            // генерируем панель выбора устройства
            const selectDevicePanel = document.getElementById("selectDevicePanel");
            let numRows = Math.trunc(benchModel.devicesList.length/2);
            numRows = ((benchModel.devicesList.length%2) === 0)?numRows:(numRows+1);
            for (let i = 0; i < numRows; i++){
                let newRow = document.createElement("tr");
                let newCell1 = document.createElement("td");
                let newCell2 = document.createElement("td");
                newCell1.setAttribute("style","width: 50%; padding: 10px");
                newCell2.setAttribute("style","width: 50%; padding: 10px");
                let newBtn1 = document.createElement("button");
                let newBtn2 = document.createElement("button");
                newBtn1.setAttribute("class", "selectDeviceBtn");
                newBtn2.setAttribute("class", "selectDeviceBtn");
                newBtn1.addEventListener("click", (event) => selectDevice(event, newBtn1, benchModel));
                newBtn2.addEventListener("click", (event) => selectDevice(event, newBtn2, benchModel));
                newBtn1.innerText = benchModel.devicesList[i*2].deviceName;
                if ((i*2+1) < benchModel.devicesList.length) 
                    newBtn2.innerText = benchModel.devicesList[i*2+1].deviceName;
                newCell1.appendChild(newBtn1);
                if ((i*2+1) < benchModel.devicesList.length)
                    newCell2.appendChild(newBtn2);
                newRow.appendChild(newCell1);
                newRow.appendChild(newCell2);
                selectDevicePanel.appendChild(newRow);
            }  
            sendSignal(undefined, "SET_DEV_SELECT_PANEL_FLAG", "true")
            .then( () => {
                document.getElementById("forwardBtn").disabled = true;
                document.getElementById("forwardBtn").style.backgroundColor = BACKGROUND_COLOR;
                // отображаем форму
                document.getElementById("autorizationForm").style.display = "none";
                document.getElementById("deviceForm").style.display = "";
                resolve(0);
            });
        });           
          
}

//===========================================================================================================
/**
 * @brief Удаление панели выбора устройств
 * 
 */
const removeDeviceSelectPanel = (devicesList) => {
        // удаление строк в таблице selectDevicePanel
    const selectDevicePanel = document.getElementById("selectDevicePanel");            
    let numRows = Math.trunc(devicesList.length/2);
    numRows = ((devicesList.length%2) === 0)?numRows:(numRows+1);
    for(let i = 0; i< numRows; i++){
        selectDevicePanel.removeChild(selectDevicePanel.lastChild);
    }
}






//===========================================================================================================
/**
 * @brief Переход на экран авторизации с экрана выбора изделия
 * 
 */
export const onDeviceFormBackwardButtonClick = (event) => {
    sendSignal(undefined, "GO_TO_AUTHORIZATION", undefined);
}
    
//===========================================================================================================
/**
 * @brief Переход на экран загрузки извещателей 
 * 
 */
export const onDeviceFormForwardButtonClick = (event) => {
    document.getElementById("deviceSerialInput").value = "";
    sendSignal(undefined, "GO_TO_LOADING", undefined)
            .then(() => {
                document.getElementById("startStandbyEnteringButton").style.backgroundColor = BACKGROUND_COLOR;
                document.getElementById("startStandbyEnteringButton").disabled = true;
            });
}




//===========================================================================================================
//==============================     ФОРМА ЗАГРУЗКИ ИЗВЕЩАТЕЛЕЙ  ============================================
//===========================================================================================================


//===========================================================================================================
/**
 * @brief Обновление формы загрузки извещателей
 * 
 */
export const updateLoadingForm = (benchModel, nextFunc) => {
        const actionFunc = () => {
            cellStatusFlags.cellSerialWaitingStatusFlag = benchModel.cellSerialWaitingStatusFlag;
            if (benchModel.shortcutFlag){
                // отправляем сигнал перехода ячейки в режим ожидания ввода штрихкода
                sendSignal(undefined, "SET_CELL_SERIAL_WAITING", undefined)
                .then(() => {
                    alert("Обнаружено короткое замыкание в цепи питания извещателя!");
                    nextFunc();
                });
            }
            else{
                if (benchModel.wrongDeviceFlag) {                   
                    document.getElementById("deviceSerialInput").value = "";
                    sendSignal(undefined, "RESET_WRONG_DEVICE_FLAG", undefined)
                    .then(() => {
                        alert("Изделие не допущено к наработке");
                        nextFunc();
                    });
                }
                else{
                    if (benchModel.serialDuplicateFlag){
                        sendSignal(undefined, "RESET_SERIAL_DUPLICATE_FLAG", undefined)
                        .then(() => {
                                alert("Дублирование штрихкода извещателя!");
                                nextFunc();
                            });        
                    }
                    else{
                        if (!screenKeyboardActivity.activityFlag){                            
                            document.getElementById("activeCellNumberInput").value = benchModel.activeCellNumberInputValue;
                            if (benchModel.prevCellButtonIsVisible)
                                document.getElementById("prevCellButton").style.display = "";
                            else 
                                document.getElementById("prevCellButton").style.display = "none";
                            if (benchModel.nextCellButtonIsVisible)
                                document.getElementById("nextCellButton").style.display = "";
                            else 
                                document.getElementById("nextCellButton").style.display = "none";                            
                        }
                        else{
                            document.getElementById("prevCellButton").style.display = "none";
                            document.getElementById("nextCellButton").style.display = "none";
                        }
                        if (benchModel.newData){
                                document.getElementById("deviceSerialInput").value = benchModel.barcodeData;
                                sendSignal(undefined, "CLEAR_BARCODE_DATA", undefined)
                                .then(() => {
                                    const waitForBarcodeDataClear = () => {
                                        setTimeout(() => {
                                            getData("get_bench_status")
                                            .then((answ) => {
                                                if (answ.newData === true){
                                                    waitForBarcodeDataClear();
                                                }
                                            });
                                        }, 250);                    
                                    }
                                    waitForBarcodeDataClear();
                                });
                        }
                        if (benchModel.cellSerialWaitingStatusFlag){
                            if (screenKeyboardActivity.activityFlag){
                                document.getElementById("cellStatusIndicator").innerHTML = "Ручной ввод серийного номера.<br> Введите серийный номер и нажмите \"ВВОД\"";
                            }
                            else{
                                document.getElementById("cellStatusIndicator").innerHTML = benchModel.cellStatusIndicatorValue;
                            }
                        }
                        else{
                            document.getElementById("cellStatusIndicator").innerHTML = benchModel.cellStatusIndicatorValue;
                        }
                        if (benchModel.startStandbyEnteringButtonEnabled)
                            document.getElementById("startStandbyEnteringButton").disabled = false;
                        else
                            document.getElementById("startStandbyEnteringButton").disabled = true;
                        if (benchModel.finishLoadingButtonEnabled)
                            document.getElementById("finishLoadingBtn").disabled = false;
                        else
                            document.getElementById("finishLoadingBtn").disabled = true;
                        document.getElementById("startStandbyEnteringButton").style.backgroundColor = benchModel.startStandbyEnteringButtonColor;
                        document.getElementById("cellStatusIndicator").style.backgroundColor = benchModel.cellStatusIndicatorColor;

                        nextFunc();
                    }
                }                
            } 
        } // end actionFunc
        
        document.getElementById("loadingFormHeader").innerText = benchModel.loadingFormHeaderValue;
        document.getElementById("deviceForm").style.display = "none";
        document.getElementById("standbyEnteringForm").style.display = "none";    
        document.getElementById("checkUpBeforeRunningForm").style.display = "none";
        document.getElementById("runningForm").style.display = "none";
        document.getElementById("loadingForm").style.display = "";
        document.getElementById("screenKeyboard").style.display = "";

        const wrappedActionFunc = () => {
            const removeCurrentPanel = (panel, signal, flagName) => {
                removeRunningCheckUpPanel(panel, signal, flagName)
                .then(() => {
                    sendSignal(undefined, "RESET_REPLACE_QUERY_SENDER", undefined)
                    .then(() => {
                        // ожидаем очистки поля отправителя
                        const waitForQuerySenderReset = () => {
                            return new Promise((resolve) => {
                                const queryStatus = () => {
                                    setTimeout(() => {
                                        getData("get_bench_status")
                                        .then((answ) => {
                                            if (answ.replaceDeviceQuerySender !== "none"){
                                                queryStatus();
                                            }
                                            else{
                                                resolve(1);
                                            }
                                        });
                                    }, 250);
                                }
                                queryStatus();                    
                            });
                        }
                        waitForQuerySenderReset()
                        .then(() => {
                            actionFunc();
                        });
                    });
                });
            }
            let curPanel = undefined;
            let signal = "";
            let removingPanelFlagName = "";
            switch(benchModel.replaceDeviceQuerySender){
                // case "STANDBY_CHECK":
                //     curPanel = document.getElementById("standbyCheckupPanel");
                //     signal = "UPDATE_RUNPANEL_GENERATED_FLAG";
                //     removingPanelFlagName = "runningPanelIsGenerated";
                // break;
                case "RUNNING":
                    curPanel = document.getElementById("runningPanel");
                    signal = "UPDATE_RUNPANEL_GENERATED_FLAG";
                    removingPanelFlagName = "runningPanelIsGenerated";                                   
                    break;
                case "CHECKUP_IR_BF":
                    curPanel = document.getElementById("checkUpBeforeRunningPanel");
                    signal = "UPDATE_CHECKUP_IR_BR_PANEL_GENERATED_FLAG";
                    removingPanelFlagName = "checkup_IR_BR_PanelIsGenerated";
                    break;
                case "CHECKUP_LF_BF":
                    curPanel = document.getElementById("checkUpBeforeRunningPanel");
                    signal = "UPDATE_CHECKUP_LF_BR_PANEL_GENERATED_FLAG";
                    removingPanelFlagName = "checkup_LF_BR_PanelIsGenerated";
                    break;
                case "CHECKUP_HF_BF":
                    curPanel = document.getElementById("checkUpBeforeRunningPanel");
                    signal = "UPDATE_CHECKUP_HF_BR_PANEL_GENERATED_FLAG";
                    removingPanelFlagName = "checkup_HF_BR_PanelIsGenerated";
                    break;
                case "CHECKUP_SA_BF":
                    curPanel = document.getElementById("checkUpBeforeRunningPanel");
                    signal = "UPDATE_CHECKUP_AC_BR_PANEL_GENERATED_FLAG";
                    removingPanelFlagName = "checkup_AC_BR_PanelIsGenerated";
                    break;
                default:
                    curPanel = undefined;
                    signal = "";
                    removingPanelFlagName = "";
                    break;
            }
            if  (signal === ""){
                    actionFunc();
            }
            else{
                removeCurrentPanel(curPanel, signal, removingPanelFlagName);
            }

        }

        
        if (benchModel.DeviceSelectPanelIsGenerated){
            removeDeviceSelectPanel(benchModel.devicesList);
            sendSignal(undefined, "SET_DEV_SELECT_PANEL_FLAG", "false")
            .then(() => {
                waitForFlagUpdate2("DeviceSelectPanelIsGenerated", false)
                .then(() => {
                    wrappedActionFunc();
                });                             
            });            
        }
        else{
            wrappedActionFunc();
        }       
          
}

//===========================================================================================================
/**
 * @brief выключение кнопки на время
 */

const buttonDisableOnDelay = (buttonId, delay) => {
    document.getElementById(buttonId).disabled = true;
    document.getElementById(buttonId).style.background = ORANGE_COLOR;
    setTimeout(()=>{
        document.getElementById(buttonId).disabled = false;
        document.getElementById(buttonId).style.background = BACKGROUND_COLOR;
    }, delay);

}


//===========================================================================================================
/**
 * @brief Обработчик нажатия кнопки выбора предыдущей ячейки
 * 
 */
export const onPrevCellButtonClick = (event) => {
    sendSignal(undefined, "PREV_CELL", undefined)
    .then(()=>{
        buttonDisableOnDelay("prevCellButton", 1500);
    }); 
}

//===========================================================================================================
/**
 * @brief Обработчик нажатия кнопки выбора следующей ячейки
 * 
 */
export const onNextCellButtonClick = (event) => {
    sendSignal(undefined, "NEXT_CELL", undefined)
    .then(()=>{
        buttonDisableOnDelay("nextCellButton", 1500);
    });
    //nextCellButton  
}


//===========================================================================================================
/**
 * @brief Обработчик нажатия кнопки возврата к форме выбора изделия
 * 
 */
export const onGoToDevSelectionBtnClick = (event) => {
    document.getElementById("deviceSerialInput").value = "";
    sendSignal(undefined, "GO_TO_DEVICE_SELECTION", undefined);
}

//===========================================================================================================
/**
 * @brief Обработчик нажатия кнопки замены извещателя
 * 
 */
export const onReplaceBadDevBtnClick = (event) => {
    sendSignal(undefined, "REPLACE_BAD_DEVICE", undefined)
    .then(()=>{
        buttonDisableOnDelay("replaceBadDevBtn", 1500);
    });   
    //replaceBadDevBtn 
}

//===========================================================================================================
/**
 * @brief Обработчик нажатия кнопки завершения завески
 */
export const onFinishLoadingBtnClick = (event) => {
    let answ = confirm("Завершить завеску извещателей?");
    if (answ){
        sendSignal(undefined, "FINISH_LOADING", undefined);
    }    
}

//===========================================================================================================
/**
 * @brief Переход к выходу извещателей в дежурный режим
 * 
*/

export const onStartStandbyEnteringButtonClick = (event, benchModel) => {
    let answ = confirm("Приступить к проверке работоспособности извещателей перед наработкой?");
    if (answ === true){
        sendSignal(undefined, "GO_TO_DOOR_CLOSING_MODE", undefined);
    }
    
}

//===========================================================================================================
//===============     ФОРМА ВЫХОДА ИЗВЕЩАТЕЛЕЙ В ДЕЖУРНЫЙ РЕЖИМ (и ожидание закрытия двери)  ================
//===========================================================================================================
export const updateStandbyEnteringForm = (benchModel) => {
    document.getElementById("loadingForm").style.display = "none";
    document.getElementById("screenKeyboard").style.display = "none";
    document.getElementById("standbyEnteringForm").style.display = "";
    document.getElementById("activeCellNumberInput").value = "";
    document.getElementById("standbyEnteringFormStatusIndicator").innerText = benchModel.standbyEnteringFormStatusIndicatorValue;
    document.getElementById("standbyEnteringFormTimeIndicator").innerText = benchModel.standbyEnteringFormTimeIndicatorValue;
    document.getElementById("standbyEnteringFormPanel").innerText = benchModel.standbyEnteringFormPanelValue;
    document.getElementById("standbyEnteringFormNextBtn").style.backgroundColor = benchModel.standbyEnteringFormNextBtnColor;
    if (benchModel.standbyEnteringFormNextBtnEnabled){
        document.getElementById("standbyEnteringFormNextBtn").disabled = false;
    }
    else{
        document.getElementById("standbyEnteringFormNextBtn").disabled = true;
    }
}

export const onStandbyEnteringFormNextBtnClick = (event) => {
    let answ = confirm("Перейти к проверке работоспособности извещателей?");
    if (answ){
        sendSignal(undefined, "GO_TO_IR_AC_CHECKUP_BEFORE_RUNNING_MODE", undefined);
    }   
    
}


//===========================================================================================================
//==============================     ФОРМА ПРОВЕРКИ ИК ПЕРЕД НАРАБОТКОЙ  ====================================
//===========================================================================================================


//===========================================================================================================
//==========================     ФОРМА ПРОВЕРКИ на НЧ ПОМЕХУ ПЕРЕД НАРАБОТКОЙ  ==============================
//===========================================================================================================


//===========================================================================================================
//==========================     ФОРМА ПРОВЕРКИ на ВЧ ПОМЕХУ ПЕРЕД НАРАБОТКОЙ  ==============================
//===========================================================================================================

//===========================================================================================================
//==========================     ФОРМА ПРОВЕРКИ ТРЕВОГИ АК ПЕРЕД НАРАБОТКОЙ  ================================
//===========================================================================================================


export const onCheckUpFormBeforeRunningBackButtonClick = (event) => {
    sendSignal(undefined, "GO_TO_REPLACEMENT", "CHECKUP_BF");
}

export const onCheckUpFormBeforeRunningNextButtonClick = (event) => {
    let answ = confirm("Перейти к следующему этапу?");
    if (answ === true){
        sendSignal(undefined, "CHECKUP_FORM_BR_NEXT_BUTTON_CLICK", undefined);
    }
}

/**
 * 
 * @param {*} benchModel 
 * @param {*} BACK_COLOR - цвет фона при генерации панели
 * @param {*} panelGeneratedFlag - флаг созданной панели в текущем режиме
 * @param {*} panelGeneratedSignal - сигнал обновления флага панели текущего режима
 * @param {*} removedPanel - удаляемая панель
 * @param {*} removedPanelGenereatedSignal - сигнал обновления флага удаляемой панели
 * @returns 
 */

export const updateCheckUpFormBeforeRunning = (
                                                benchModel,
                                                BACK_COLOR, 
                                                panelGeneratedFlagName, 
                                                panelGeneratedSignal,
                                                removedPanel,
                                                removedPanelGenereatedSignal,
                                                removedPanelGeneratedFlagName
                                            ) => {

    return new Promise((resolve) => {
        const actionFunc = () => {
            document.getElementById("checkUpBeforeRunningFormHeader").innerText = benchModel.checkUpBeforeRunningFormHeader;
            document.getElementById("standbyEnteringForm").style.display = "none";
            document.getElementById("checkUpBeforeRunningForm").style.display = "";
            
            for (let i = 0; i < benchModel.numCells; i++){
                let idString = "checkUpPanelCell_" + (i+1);
                    document.getElementById(idString).innerText = benchModel.checkupPanelCellValues[i];
                    document.getElementById(idString).style.backgroundColor =  benchModel.checkupPanelCellColors[i];        
            }
            
        }// end actionFunc
        if (!benchModel[panelGeneratedFlagName]){
            document.getElementById("standbyEnteringForm").style.display = "none";
            document.getElementById("checkUpBeforeRunningFormHeader").innerText = benchModel.checkUpBeforeRunningFormHeader;
            removeRunningCheckUpPanel(removedPanel, removedPanelGenereatedSignal, removedPanelGeneratedFlagName)
            .then(() => {
                generateCheckUP_Panel(benchModel, document.getElementById("checkUpBeforeRunningPanel"), BACK_COLOR)
                .then(() => {
                    sendSignal(undefined, panelGeneratedSignal, "true")
                    .then(() => {
                        // ожидаем установку флага
                        waitForFlagUpdate2(panelGeneratedFlagName, true)
                        .then(()=>{
                            // обновление формы
                            actionFunc();
                            resolve(0);
                        });
                        
                    });
                });    
            });
        }
        else{
            actionFunc();
            resolve(0);
        }
    });

}


//===========================================================================================================
//==============================     ФОРМА НАРАБОТКИ ИЗВЕЩАТЕЛЕЙ  ===========================================
//===========================================================================================================


//===========================================================================================================
/**
 * @brief Проверка наличия номера в массиве
 * @param faultyCellsNumArray - массив номеров неисправных ячеек
 * @return true - если номер есть в массиве, false - если нет
 */
const numberInArray = (numCell, faultyCellsNumArray) => {
    for (let i = 0; i < faultyCellsNumArray.length;i++){
        if (faultyCellsNumArray[i] === numCell) return true;
    }
    return false;
}


//===========================================================================================================
/**
 * @brief Генерация панели наработки
 */
export const generateRunningPanel = (benchModel, runningPanel) => {
    // генерируем панель статуса наработки
    for (let i = 0; i < 10; i++){// строки
        let newRow = document.createElement("tr");
        for(let j = 0; j < 14; j++){
            let newCell = document.createElement("td");
            if ((benchModel.selectedDevice.number_IR_Channels +  benchModel.selectedDevice.number_AC_Channels) === 1)
                newCell.innerText = "0";
            else
                newCell.innerText = "0-0";
            let numCell = (14*i+(j+1));
            newCell.setAttribute("id", "runningPanelCell_" + numCell);
            newCell.style.textAlign = "center";
            newCell.style.paddingTop = "30px";
            newCell.style.paddingBottom = "30px";
            newCell.style.width = "7%";
            if (numCell <= benchModel.numCells){
                newCell.style.backgroundColor = GREEN_COLOR;
                if (numberInArray(numCell, benchModel.faultyCellsNumArray)){
                    newCell.style.backgroundColor = BACKGROUND_COLOR;
                    newCell.innerText = "-";
                }
            }                
            else{
                newCell.style.backgroundColor = BACKGROUND_COLOR;
                newCell.innerText = "-";
            }

            newRow.appendChild(newCell);
        }
        runningPanel.appendChild(newRow);
    }
    
    return new Promise((resolve) => {
        sendSignal(undefined, "UPDATE_RUNPANEL_GENERATED_FLAG", "true")
        .then((answ) => {
            waitForFlagUpdate2("runningPanelIsGenerated",true)
            .then(()=>{
                resolve(0);
            });            
        });
    });
        
}




//===========================================================================================================
/**
 * @brief Остановить наработку
 * 
*/
export const onStopRunningButtonClick = (event) => {
    let answ = confirm("Остановить наработку?");
    if (answ === true){
        document.getElementById("runningForm").style.display = "none";
        sendSignal(undefined, "STOP_RUNNING", undefined);
    }
}


//===========================================================================================================
/**
 * @brief Обновление формы наработки
 * 
*/
export const updateRunningForm = (benchModel) => {
    document.getElementById("runningFormHeader").innerText = benchModel.runningFormHeaderValue;
    document.getElementById("benchStatusIndicator").innerText = benchModel.benchStatusIndicatorValue;
    document.getElementById("runningTimeIndicator").innerText = benchModel.runningTimeIndicatorValue;    
    document.getElementById("runningForm").style.display = "";
    document.getElementById("checkUpBeforeRunningForm").style.display = "none";
    if (benchModel.toControlButtonEnabled)
        document.getElementById("toControlButton").disabled = false;
    else
        document.getElementById("toControlButton").disabled = true;
    document.getElementById("toControlButton").style.backgroundColor  = benchModel.toControlButtonColor;
    for (let i = 0; i < benchModel.numCells; i++){
        if (!numberInArray(i+1, benchModel.faultyCellsNumArray)){
            let idString = "runningPanelCell_" + (i+1);
            document.getElementById(idString).innerText = benchModel.runningPanelCellValues[i];
            document.getElementById(idString).style.backgroundColor =  benchModel.runningPanelCellColors[i];
        }        
    }
    
}

//===========================================================================================================
/**
 * @brief Обработчик нажатия на кнопку перехода в режим проверки каналов
 * 
*/
export const onControlButtonClick = (event) => {
    sendSignal(undefined, "GO_TO_CHECKUP_AFTER_RUNNING", undefined);   
}   




//===========================================================================================================
//============================     ФОРМА ПРОВЕРКИ СРАБАТЫВАНИЯ ИЗВЕЩАТЕЛЕЙ  =================================
//===========================================================================================================

export const onCheckUpFormBackButtonClick = (event) => {
    let answ = confirm("Вернуться к предыдущему этапу?");
    if (answ === true){
        sendSignal(undefined, "CHECKUP_FORM_AR_BACK_BUTTON_CLICK", undefined);
    }  
}

export const onCheckUpFormNextButtonClick = (event) => {
    let answ = confirm("Перейти к следующему этапу?");
    if (answ === true){
        sendSignal(undefined, "CHECKUP_FORM_AR_NEXT_BUTTON_CLICK", undefined);
    }
}



//===========================================================================================================
/**
 * @brief
 * Генерация панели проверки срабатывания инфракрасного и акустического каналов извещателей
 * 
 */
export const generateCheckUP_Panel = (benchModel, checkUpPanel, BACK_COLOR) => {
    // генерируем панель проверки срабатывания
    for (let i = 0; i < 10; i++){// строки
        let newRow = document.createElement("tr");
        for(let j = 0; j < 14; j++){
            let newCell = document.createElement("td");
            let numCell = j + i*14 + 1;
            
            newCell.setAttribute("id", "checkUpPanelCell_"+(14*i+(j+1)));
            newCell.style.textAlign = "center";
            newCell.style.paddingTop = "30px";
            newCell.style.paddingBottom = "30px";
            newCell.style.width = "7%";
            if (numCell <= benchModel.numCells){
                newCell.innerText = "-";
                newCell.style.backgroundColor = BACK_COLOR;
                // if (!numberInArray(numCell, benchModel.faultyCellsNumArray)){
                //     newCell.style.backgroundColor = BACK_COLOR;
                // }
                // else{
                //     newCell.style.backgroundColor = BACKGROUND_COLOR;
                // }                
            }
            else{
                newCell.style.backgroundColor = BACKGROUND_COLOR;
                newCell.innerText = "-";
            }                     
            newRow.appendChild(newCell);
        }
        checkUpPanel.appendChild(newRow);
    }
    return new Promise((resolve) => {
        resolve(0);
    });
}


//===========================================================================================================
/**
 * 
 * @param {*} benchModel 
 * @param {*} BACK_COLOR - цвет фона при генерации панели
 * @param {*} panelGeneratedFlag - флаг созданной панели в текущем режиме
 * @param {*} panelGeneratedSignal - сигнал обновления флага панели текущего режима
 * @param {*} removedPanel - удаляемая панель
 * @param {*} removedPanelGenereatedSignal - сигнал обновления флага удаляемой панели
 * @returns 
 */

export const updateCheckUpFormAfterRunning = (
                                                benchModel,
                                                BACK_COLOR, 
                                                panelGeneratedFlagName, 
                                                panelGeneratedSignal,
                                                removedPanel,
                                                removedPanelGeneratedSignal,
                                                removedPanelGeneratedFlagName
                                            ) => {

    return new Promise((resolve) => {
        const actionFunc = () => {
            document.getElementById("checkUpFormHeader").innerText = benchModel.checkUpFormHeaderValue;
            document.getElementById("runningForm").style.display = "none";
            document.getElementById("checkUpForm").style.display = "";
            
            for (let i = 0; i < benchModel.numCells; i++){
                let idString = "checkUpPanelCell_" + (i+1);
                    document.getElementById(idString).innerText = benchModel.checkupPanelCellValues[i];
                    document.getElementById(idString).style.backgroundColor =  benchModel.checkupPanelCellColors[i];
        
            }
        }// end actionFunc   

        if (!benchModel[panelGeneratedFlagName]){
            document.getElementById("runningForm").style.display = "none";
            document.getElementById("checkUpFormHeader").innerText = benchModel.checkUpFormHeaderValue;
            removeRunningCheckUpPanel(removedPanel, removedPanelGeneratedSignal, removedPanelGeneratedFlagName)
            .then(() => {
                generateCheckUP_Panel(benchModel, document.getElementById("checkUpPanel"), BACK_COLOR)
                .then(() => {
                    sendSignal(undefined, panelGeneratedSignal, "true")
                    .then(() => {
                        waitForFlagUpdate2(panelGeneratedFlagName, true)
                        .then(()=>{
                            actionFunc();
                            resolve(0);
                        });
                    });
                });    
            });
        }
        else{
            actionFunc();
            resolve(0);
        }
    });
}

// ===========================================================================================================
/**
 * @brief Удаление панели проверки каналов
 * 
 */
export const removeRunningCheckUpPanel = (Panel, panelGeneratedFlagSignal, panelGeneratedFlagName) => {
    // удаление строк в таблице Panel
    if (Panel !== undefined){
        for(let i = 0; i< 10; i++){
            if (Panel.lastChild !== null){
                Panel.removeChild(Panel.lastChild); 
            }
            else{
                //console.log("lastChild is null");
            }
                        
        }
        return new Promise((resolve) => {
            sendSignal(undefined, panelGeneratedFlagSignal, "false")
            .then((answ) => {
                // ожидаем сброс флага
                waitForFlagUpdate2(panelGeneratedFlagName, false)
                .then(() => {
                    resolve(0);
                });
            });
        });
    }
    else{
        return new Promise((resolve) => {
            resolve(0);
        });
    }
    
}



//===========================================================================================================
//==============================     ФОРМА ОТЧЕТА НАРАБОТКИ  ================================================
//===========================================================================================================



//===========================================================================================================
/**
 * @brief Генерация панели отображения отчета наработки
 * 
*/
export const generateReportPanel = (benchModel, reportPanel) => {
    document.getElementById("checkUpForm").style.display = "none";
    document.getElementById("reportFormHeader").innerText = benchModel.reportFormHeaderValue;
    //const reportPanel = document.getElementById("reportPanel");
    for (let i = 0; i < (benchModel.numBadDevices + 1); i++){
        
        let newRow = document.createElement("tr");
        let newCell1 = document.createElement("td");
        let newCell2 = document.createElement("td");
        let newCell3 = document.createElement("td");
        let newCell4 = document.createElement("td");
        let newCell5 = document.createElement("td");
        let newCell6 = document.createElement("td");
        let newCell7 = document.createElement("td");
        let newCell8 = document.createElement("td");
        let newCell9 = document.createElement("td");
        let newCell10 = document.createElement("td");
        let newCell11 = document.createElement("td");

        
        newCell1.style.textAlign = newCell2.style.textAlign = newCell3.style.textAlign = "center";
        newCell4.style.textAlign = newCell5.style.textAlign = newCell6.style.textAlign = "center";
        newCell7.style.textAlign = newCell8.style.textAlign = newCell9.style.textAlign = "center";
        newCell10.style.textAlign = newCell11.style.textAlign ="center";

        newCell1.style.fontSize = newCell2.style.fontSize = newCell3.style.fontSize = "24px";
        newCell4.style.fontSize = newCell5.style.fontSize = newCell6.style.fontSize = "24px";
        newCell7.style.fontSize = newCell8.style.fontSize = newCell9.style.fontSize = "24px";
        newCell10.style.fontSize = newCell11.style.fontSize ="24px";
        
        if ((benchModel.selectedDevice.number_IR_Channels > 0) && (benchModel.selectedDevice.number_AC_Channels === 0)){
            newCell1.style.width = newCell4.style.width = "5%"; // яч, ложн ИК
            newCell3.style.width = "35%"; // результат
            newCell6.style.width = "5%"; // проверка ИК, помеха НЧ, помеха ВЧ, проверка АК
            newCell10.style.width = "10%"; // ток
            newCell2.style.width = "20%"; // сер№
            newCell11.style.width = "20%"; // ошибки связи
            newCell3.style.width = "35%"; // результат          
        }

        if ((benchModel.selectedDevice.number_IR_Channels === 0) && (benchModel.selectedDevice.number_AC_Channels > 0)){
            newCell1.style.width =  newCell5.style.width ="5%"; // яч, ложн АК
            newCell7.style.width = newCell8.style.width = newCell9.style.width ="5%"; // помеха НЧ, помеха ВЧ, проверка АК
            newCell10.style.width = "10%"; // ток
            newCell2.style.width = "20%"; // сер№
            newCell11.style.width = "20%"; // ошибки связи
            newCell3.style.width = "25%"; // результат  
        }

        if ((benchModel.selectedDevice.number_IR_Channels > 0) && (benchModel.selectedDevice.number_AC_Channels > 0)){
            newCell1.style.width = newCell4.style.width = newCell5.style.width ="5%"; // яч, ложн ИК, ложн АК
            newCell6.style.width = newCell7.style.width = newCell8.style.width = newCell9.style.width ="5%"; // проверка ИК, помеха НЧ, помеха ВЧ, проверка АК
            newCell10.style.width = "10%"; // ток
            newCell2.style.width = "20%"; // сер№
            newCell11.style.width = "5%"; // ошибки связи
            newCell3.style.width = "30%"; // результат  
        }

        if (i === 0){ // заголовок таблицы                
            newCell1.innerText = "№ яч.";
            newCell2.innerText = "Сер.№";
            newCell3.innerText = "Рез.";
            newCell4.innerText = "ЛT ИК";
            newCell5.innerText = "ЛT АК";
            newCell6.innerText = "Проверка ИК";
            newCell7.innerText = "Помеха НЧ";
            newCell8.innerText = "Помеха ВЧ";
            newCell9.innerText = "Проверка AК";
            newCell10.innerText = "Ток";
            newCell11.innerText = "Ошибки связи";
            

        }
        else{ // строки результата
            newCell1.innerText = benchModel.numCellColumn[i-1];
            newCell2.innerText = benchModel.serialColumn[i-1];
            newCell3.innerText = benchModel.resultColumn[i-1];
            newCell4.innerText = benchModel.falseIR_Column[i-1];
            newCell5.innerText = benchModel.falseAC_Column[i-1];
            newCell6.innerText = benchModel.checkIR_Column[i-1];
            newCell7.innerText = benchModel.checkLFD_Column[i-1];
            newCell8.innerText = benchModel.checkHFD_Column[i-1];
            newCell9.innerText = benchModel.checkAC_Column[i-1];
            newCell10.innerText = benchModel.currentColumn[i-1];
            newCell11.innerText = benchModel.errorsColumn[i-1];

            // маркировка цветом
            newCell3.style.color = benchModel.result_Color_Column[i-1]; 
            newCell4.style.color = benchModel.falseIR_Color_Column[i-1];
            newCell5.style.color = benchModel.falseAC_Color_Column[i-1];
            newCell6.style.color = benchModel.checkIR_Color_Column[i-1];
            newCell7.style.color = benchModel.checkLFD_Color_Column[i-1];
            newCell8.style.color = benchModel.checkHFD_Color_Column[i-1];
            newCell9.style.color = benchModel.checkAC_Color_Column[i-1];
            newCell10.style.color = benchModel.current_Color_Column[i-1];
            newCell11.style.color = benchModel.errors_Color_Column[i-1];
                                                       
        }
        
        // формируем строку
        newRow.appendChild(newCell1);
        newRow.appendChild(newCell2);
        newRow.appendChild(newCell3);

        if (benchModel.selectedDevice.number_IR_Channels > 0){
            newRow.appendChild(newCell4);
        }
        if (benchModel.selectedDevice.number_AC_Channels > 0){
            newRow.appendChild(newCell5);
        }
        if (benchModel.selectedDevice.number_IR_Channels > 0){
            newRow.appendChild(newCell6);
        }
        if (benchModel.selectedDevice.number_AC_Channels > 0){
            newRow.appendChild(newCell7);
            newRow.appendChild(newCell8);
            newRow.appendChild(newCell9);
        }        
        newRow.appendChild(newCell10);
        newRow.appendChild(newCell11);
        
        reportPanel.appendChild(newRow); 
                           
    }

    if (benchModel.numBadDevices === 0){
        reportPanel.removeChild(reportPanel.lastChild); // удаляем строку заголовка
        let newCell0= document.createElement("td");
        newCell0.style.textAlign = "center";
        newCell0.style.fontSize = "24px";
        newCell0.style.color = DARK_GREEN_COLOR;
        newCell0.innerHTML = SUCCES_STRING; 
        let newRow0 = document.createElement("tr");
        newRow0.appendChild(newCell0);
        reportPanel.appendChild(newRow0);
    }

    document.getElementById("reportForm").style.display = "";

}
//===========================================================================================================
/**
 * @brief Удаление строк панели отчета наработки
*/
export const removeReportPanel = (numBadDevices, reportPanel) => {
    for(let i = 0; i < (numBadDevices+1); i++){
            reportPanel.removeChild(reportPanel.lastChild);
        }
    
}


//======================================================================================================
/**
 * @brief Обработчик нажатия на кнопку перехода в режим снятия извещателей
*/
export const onUnloadingBtnClick = (event) => {
    let answ = confirm("Перейти к снятию извещателей?");
    if (answ === true){
        sendSignal(undefined, "GO_TO_UNLOADING_MODE", undefined);
    }
}




//===========================================================================================================
//==============================     ФОРМА СНЯТИЯ ИЗВЕЩАТЕЛЕЙ  ===========================================
//===========================================================================================================




//======================================================================================================
/**
 * @brief Обновление формы снятия извещателей
*/
export const updateUnloadingForm = (benchModel) => {
    document.getElementById("reportForm").style.display = "none";    
    document.getElementById("unloadingFormHeader").innerText  = benchModel.unloadingFormHeaderValue;
    document.getElementById("unloadingPanel").innerText =  benchModel.unloadingPanelValue;
    document.getElementById("unloadingPanel").style.color =  benchModel.unloadingPanelColor;
    document.getElementById("nextUnloadingModeBtn").textContent = benchModel.nextUnloadingModeBtnText;
    document.getElementById("unloadingForm").style.display = "";    
}

//======================================================================================================
/**
 * @brief Обработчик нажатия на кнопку следующего этапа снятия извещателей
*/
export const onNextUnloadingModeBtnClick = (event) => {
    let answ = confirm("Перейти к следующему этапу?");
    if (answ === true){
        document.getElementById("operatorCode").value = "";
        sendSignal(undefined, "GO_TO_UNLOADING_MODE", undefined);
    }
}





//======================================================================================================
//                      ЭКРАННАЯ КЛАВИАТУРА
//======================================================================================================


/**
 * @brief Обработчик нажатия на кнопку экранной клавиатуры
*/
export const onKeyboardButtonClick = (event) => {

                    // вложенная функция включения активности экранной клавиатуры
                    const screenKeyboardActivityTurnOn = (inputField) => {
                        if ((document.getElementById("kBtn_Enter").disabled)){
                            document.getElementById("kBtn_Enter").disabled = false;
                            document.getElementById("kBtn_Clear").disabled = false;
                            inputField.value = "";          
                            document.getElementById("kBtn_Enter").style.background = GREEN_COLOR;
                            screenKeyboardActivity.activityFlag = true; 
                        }
                    }

    event.srcElement.style.background = GREY_COLOR;                
    if (document.getElementById("loadingForm").style.display === ""){
        // ввод на форме загрузки извещателей
        if (screenKeyboardActivity.cellNumInputFlag){
            screenKeyboardActivityTurnOn(document.getElementById("activeCellNumberInput"));
        document.getElementById("activeCellNumberInput").value+=event.srcElement.innerText;
        }
        else{
            if (cellStatusFlags.cellSerialWaitingStatusFlag){
                screenKeyboardActivityTurnOn(document.getElementById("deviceSerialInput"));
            document.getElementById("deviceSerialInput").value+=event.srcElement.innerText;
            }
        }   
    }
    else{
        // ввод на форме авторизации
        screenKeyboardActivityTurnOn(document.getElementById("operatorCode"));
        document.getElementById("operatorCode").value+=event.srcElement.innerText;
    }
    setTimeout(()=>{
        event.srcElement.style.background = BACKGROUND_COLOR;
    },100);   
}

//======================================================================================================
/**
 * @brief Обработчик нажатия на кнопку очистки введенного номера ячейки
*/
export const onKeyboardClearButtonClick = (event) => {
    if (document.getElementById("loadingForm").style.display === ""){// ввод на форме загрузки извещателей
        if (screenKeyboardActivity.cellNumInputFlag){
            document.getElementById("activeCellNumberInput").value="";
        }
        else{
            document.getElementById("deviceSerialInput").value="";
        }
    }
    else{ // ввод в поле кода оператора на форме авторизации
        document.getElementById("operatorCode").value = "";
    }
    
}

//======================================================================================================
/**
 * @brief Обработчик нажатия на кнопку ввода 
*/
export const onKeyboardEnterButtonClick = (event) => {
    let activityTurnOffDelay = 1500;

    document.getElementById("kBtn_Enter").disabled = true;
    document.getElementById("kBtn_Clear").disabled = true;
                const keyBoardChangeEnable = (keyBoardEnabled) => {
                    if (keyBoardEnabled){
                        document.getElementById("kBtn_0").disabled = false;
                        document.getElementById("kBtn_1").disabled = false;
                        document.getElementById("kBtn_2").disabled = false;
                        document.getElementById("kBtn_3").disabled = false;
                        document.getElementById("kBtn_4").disabled = false;
                        document.getElementById("kBtn_5").disabled = false;
                        document.getElementById("kBtn_6").disabled = false;
                        document.getElementById("kBtn_7").disabled = false;
                        document.getElementById("kBtn_8").disabled = false;
                        document.getElementById("kBtn_9").disabled = false;

                        document.getElementById("kBtn_0").style.background = BACKGROUND_COLOR;
                        document.getElementById("kBtn_1").style.background = BACKGROUND_COLOR;
                        document.getElementById("kBtn_2").style.background = BACKGROUND_COLOR;
                        document.getElementById("kBtn_3").style.background = BACKGROUND_COLOR;
                        document.getElementById("kBtn_4").style.background = BACKGROUND_COLOR;
                        document.getElementById("kBtn_5").style.background = BACKGROUND_COLOR;
                        document.getElementById("kBtn_6").style.background = BACKGROUND_COLOR;
                        document.getElementById("kBtn_7").style.background = BACKGROUND_COLOR;
                        document.getElementById("kBtn_8").style.background = BACKGROUND_COLOR;
                        document.getElementById("kBtn_9").style.background = BACKGROUND_COLOR;
                        document.getElementById("kBtn_Clear").style.background = BACKGROUND_COLOR;
                    }
                    else{
                        document.getElementById("kBtn_0").disabled = true;
                        document.getElementById("kBtn_1").disabled = true;
                        document.getElementById("kBtn_2").disabled = true;
                        document.getElementById("kBtn_3").disabled = true;
                        document.getElementById("kBtn_4").disabled = true;
                        document.getElementById("kBtn_5").disabled = true;
                        document.getElementById("kBtn_6").disabled = true;
                        document.getElementById("kBtn_7").disabled = true;
                        document.getElementById("kBtn_8").disabled = true;
                        document.getElementById("kBtn_9").disabled = true;
                        document.getElementById("kBtn_0").style.background = ORANGE_COLOR;
                        document.getElementById("kBtn_1").style.background = ORANGE_COLOR;
                        document.getElementById("kBtn_2").style.background = ORANGE_COLOR;
                        document.getElementById("kBtn_3").style.background = ORANGE_COLOR;
                        document.getElementById("kBtn_4").style.background = ORANGE_COLOR;
                        document.getElementById("kBtn_5").style.background = ORANGE_COLOR;
                        document.getElementById("kBtn_6").style.background = ORANGE_COLOR;
                        document.getElementById("kBtn_7").style.background = ORANGE_COLOR;
                        document.getElementById("kBtn_8").style.background = ORANGE_COLOR;
                        document.getElementById("kBtn_9").style.background = ORANGE_COLOR;
                        document.getElementById("kBtn_Clear").style.background = ORANGE_COLOR;
                    }                    
                }

    if (document.getElementById("loadingForm").style.display === ""){// ввод на форме загрузки извещателей
        if (screenKeyboardActivity.cellNumInputFlag){
            let activeCellNum = Number(document.getElementById("activeCellNumberInput").value);
            if (isNaN(activeCellNum)){
                alert("Ошибка ввода номера ячейки");
            }
            else{
                document.getElementById("kBtn_Enter").style.background = ORANGE_COLOR;
                keyBoardChangeEnable(false);
                sendSignal(undefined, "SET_ACTIVE_CELL_NUMBER", activeCellNum)
                .then(() => {
                    setTimeout(()=>{
                        screenKeyboardActivity.activityFlag = false;
                        document.getElementById("kBtn_Enter").style.background = BACKGROUND_COLOR;
                        keyBoardChangeEnable(true);
                    }, activityTurnOffDelay);                     
                });
            }
        }
        else{
            document.getElementById("kBtn_Enter").style.background = ORANGE_COLOR;
            keyBoardChangeEnable(false);
            sendSignal(undefined, "SCREEN_KEYBOARD_BARCODE_SIGNAL", document.getElementById("deviceSerialInput").value)
                .then(() => {
                    setTimeout(()=>{
                        screenKeyboardActivity.activityFlag = false;
                        document.getElementById("kBtn_Enter").style.background = BACKGROUND_COLOR;
                        keyBoardChangeEnable(true);
                    }, activityTurnOffDelay);
                });
        }
    }
    else{
        document.getElementById("kBtn_Enter").style.background = ORANGE_COLOR;
        keyBoardChangeEnable(false);
        setTimeout(()=>{
            screenKeyboardActivity.activityFlag = false;
            document.getElementById("kBtn_Enter").style.background = BACKGROUND_COLOR;
            keyBoardChangeEnable(true);
        }, activityTurnOffDelay);
    }    
}

//======================================================================================================
/**
 * @brief Обработчик переключения поля ввода с ручной клавиатуры
*/
export const toggleManualInput = (event, buttonID) => {
    if (buttonID === "cellNum"){
        screenKeyboardActivity.cellNumInputFlag = true;
        document.getElementById("manualInputCellNumBtn").style.backgroundColor = GREEN_COLOR;
        document.getElementById("manualInputBarcodeBtn").style.backgroundColor = BACKGROUND_COLOR;
    }
    else{
        screenKeyboardActivity.cellNumInputFlag = false;
        document.getElementById("manualInputCellNumBtn").style.backgroundColor = BACKGROUND_COLOR;
        document.getElementById("manualInputBarcodeBtn").style.backgroundColor = GREEN_COLOR;
    }
}

//======================================================================================================
/**
 * @brief Обработчик ручного ввода номера с резервной клавиатуры по нажатию клавиши Enter
*/
export const onActiveCellNumberInputKeypress = (event) => {
    if (event.code === "NumpadEnter"){
        let activeCellNum = Number(document.getElementById("activeCellNumberInput").value);
        if (isNaN(activeCellNum)){
         alert("Ошибка ввода номера ячейки");
        }
        else{
            sendSignal(undefined, "SET_ACTIVE_CELL_NUMBER", activeCellNum);
        }
    }   
}


