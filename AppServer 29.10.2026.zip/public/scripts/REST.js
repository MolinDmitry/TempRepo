/**
 * @breif
 * Библиотека функций взаимодействия с REST-службами блока управления и сканера штрихкодов
 * 
 *  */

import {GREEN_COLOR, ORANGE_COLOR} from "../scripts/constants.js";
import {AUTHORIZATION_MODE, LOADING_MODE} from "../scripts/constants.js";


//===========================================================================================================
/**
 * @brief
 * Декоратор тела callback-функции
 * Определяет если ответ был без ошибок то вызывает функцию callback-а
 * Если ответ содержит ошибку, логирует её
 * @param
 * errorMessage - сообщение, логируемое при ошибке (к сообщению добавляется ". Error code: " и код ошибки)
 * answerArray - массив объектов ответа сервера, который будет передан в callbackFunc
 * calbackFunc - ссылка на функцию, выполняемую, если в ответе нет ошибок
 * 
 */
export const callback_decorator = (errorMessage, answerArray, callbackFunc) => {
    if (answerArray[0].errorCode === 0){
        callbackFunc(answerArray);
    }
    else{
        console.log(errorMessage + " . Error code: " + answerArray[0].errorCode);
    }
}


//===========================================================================================================    
export const sendCommand = (numCell, command, nextFunc) => {
    let queryString  = "http://localhost:3030/te1570/exec?command=" + command + 
                        "&address=" + numCell;       
    getData(queryString, nextFunc);    
}



//===========================================================================================================  
/**
 * @brief 
 * Переключает индикацию ячейки
 * @param
 *  cellNum - номер ячейки, начиная с 1
 *  led - "RED", "GREEN", "OFF"
 *  nextFunc - ссылка на функцию, вызываемую после прихода ответа от сервера
 * */     
export const setLED = (cellNum, led, nextFunc) => {
    let ledStatus = "0";
    switch(led){
        case "RED":
            ledStatus = "192";
            break;
        case "GREEN":
            ledStatus = "48";
            break;
    }
    let queryString  = "http://localhost:3030/te1570/exec?command=set_led&address=" + cellNum +
    "&led_status=" + ledStatus;          
    getData(queryString, nextFunc);
}

//===========================================================================================================
    /**
     * @brief
     * Переключает питание выходной линии
     * @param
     * numCell - номер ячейки
     * lineStatus - "ON", "OFF"
    */
export const control_12V_line = (numCell, lineStatus, nextFunc) => {
    let stat = "0";
    if (lineStatus === "ON") {
        stat = "6";
    }
    let queryString  = "http://localhost:3030/te1570/exec?command=set_power&address=" + numCell +
    "&line_status=" + stat;          
    getData(queryString, nextFunc);    
}


//===========================================================================================================
export const getBarcodeData = (globalVars, activeCellModel) => {
        const req = new XMLHttpRequest();
        req.onload = () => {
            if (req.status == 200) {
                const answerObject = req.response;
                const codeInput = document.getElementById("operatorCode");
                const deviceSerialInput = document.getElementById("deviceSerialInput");
                const controlBlockStatusIndicator = document.getElementById("controlBlockStatusIndicator");
                const scannerStatusIndicator = document.getElementById("scannerStatusIndicator");
                // barcodeScanerStatus.value = answerObject.scannerStatus;
                if (answerObject.scannerStatus === "Data"){
                    if (globalVars.modeID === AUTHORIZATION_MODE)
                        codeInput.value = answerObject.message;
                    if (globalVars.modeID === LOADING_MODE){
                        deviceSerialInput.value = answerObject.message;
                        activeCellModel.serial = answerObject.message;
                    }
                        
                }
                if (answerObject.scannerStatus === "None connection") {
                    scannerStatusIndicator.style.backgroundColor = ORANGE_COLOR;
                }
                else{
                    scannerStatusIndicator.style.backgroundColor = GREEN_COLOR;
                } 
                // controlBlockStatusIndicator.style.backgroundColor = ORANGE_COLOR;                  
                globalVars.barcodeRequestEnabled = 1;                  
            }
        };
        req.open("GET", "http://localhost:3032/barcodescanner/getdata");
        req.responseType = "json";
        req.send();
        globalVars.barcodeRequestEnabled = 0; 
    }



//===========================================================================================================
//===========================================================================================================
//===========================================================================================================
//===========================================================================================================

export const getBenchModel = () => {
    return new Promise((resolve) => {
        let queryString  = "http://localhost:3000/get_bench_model/";
        const req = new XMLHttpRequest();
        req.onload = () => {
            if (req.status == 200){
                const answerObj = req.response;
                resolve(answerObj);       
            }
        };    
        req.open("GET", queryString);
        req.responseType = "json";
        req.send();
    });
}

//===========================================================================================================
export const getData = (path) => {
    return new Promise((resolve) => {
        let queryString  = "http://localhost:3000/" + path;
        const req = new XMLHttpRequest();
        req.onload = () => {
            if (req.status == 200){
                const answerObj = req.response;
                resolve(answerObj);       
            }
        };    
        req.open("GET", queryString);
        req.responseType = "json";
        req.send();
    });
}

//===========================================================================================================
/**
 * @brief Ожидает обновление исостояния флага
 * @param {*} flagName 
 * @param {*} flagState 
 * @returns 
 */
export const waitForFlagUpdate2 = (flagName, flagState) => {
                return new Promise((resolve) => {
                    const queryStatus = () => {
                        setTimeout(() => {
                            getData("get_bench_status")
                            .then((answ) => {
                                if (answ[flagName] !== flagState){
                                    queryStatus();
                                }
                                else{
                                    resolve(1);
                                }
                            });
                        }, 250);
                    }
                    queryStatus();                    
                });
            }


//=================================================
// получение серийного номера стенда
export const getBenchSerial = () => {
    return new Promise((resolve) => {
        let machineSerial = 0;
        // запрашиваем серийный номер стенда
        const req = new XMLHttpRequest();
        req.onload = () => {
            if (req.status == 200) {
                machineSerial = req.response.machineSerial;
                resolve(machineSerial);                                    
            }
            else{
                resolve(0);
            }
        };
        req.open("GET","http://localhost:3000/getserial");
        req.responseType = "json";
        req.send();

    });
}
    


