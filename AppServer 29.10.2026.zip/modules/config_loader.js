

const {
        getParamValueFromDB,
        getConfigurationFromDB
    } = require("./REST.js");

    const {
        logger
    } = require("./logger.js");




const loadConfiguration = (machineSerial, glVars) => {
    return new Promise((resolve) => {
        getConfigurationFromDB()
        .then((answ) => {            
            if (answ !== null){
                logger("Соединение с драйвером  БД установлено");
                logger("Загрузка конфигурации");
                for(let i = 0; i < answ.length; i++){
                    if (Number.isNaN(Number(answ[i].parameterValue))){
                        glVars[answ[i].parameterName] = answ[i].parameterValue;
                    }
                    else{
                        glVars[answ[i].parameterName] = Number(answ[i].parameterValue);
                    }
                }
                resolve(1);
            }
            else{
                resolve(0);
            }
        });
    });

}

exports.loadConfiguration = loadConfiguration;