


const {
    IDLE_MODE,
    ENTER_STANDBY_MODE,
    DOOR_CLOSING_WAITING_MODE
} = require("./model_constants.js");


    const {
        convertSecondsToTimeString
    } =  require("./signal_processing.js");

const {
    logger
    } = require("./logger.js");


/**
 * @brief Функция таймера в режиме ожидания закрытия двери
 */


exports.doorClosingWaitingModeTimer = (glVars, benchStatusData, nextFunc) => {
    if (glVars.primaryControllerStatus.doorTS === 0){ // если дверь закрыта
        glVars.startUpFlag = false;
        glVars.allDevicesStandbyTime = 0;
        glVars.allDeviceStandbyFlag = false;
        glVars.benchMode = ENTER_STANDBY_MODE;        
    }
    else{
        benchStatusData.standbyEnteringFormStatusIndicatorValue = "Ожидание закрытия двери стенда";
        benchStatusData.standbyEnteringFormPanelValue = "Закройте дверь стенда";
        benchStatusData.standbyEnteringFormTimeIndicatorValue = "--";
    }
    nextFunc();
}




/**
 * @brief Функция таймера в режиме выхода извещателей в дежурный режим и ожидания снятия сигнала тревоги
 * 
 */
exports.onStandbyEnteringTimer = (glVars, benchStatusData, nextFunc) => {
    if (glVars.primaryControllerStatus.doorTS === 1){ // если дверь открыта
        benchStatusData.standbyEnteringFormPanelValue = "Закройте дверь стенда";
        benchStatusData.standbyEnteringFormTimeIndicatorValue = "--";
        benchStatusData.standbyEnteringFormStatusIndicatorValue = "Ожидание закрытия двери";
        glVars.benchMode = DOOR_CLOSING_WAITING_MODE; 
        nextFunc();

    }
    else{
        // дверь закрыта
        benchStatusData.standbyEnteringFormPanelValue = "Не открывайте дверь стенда, дождитесь выхода извещателей в дежурный режим и снятия сигнала тревоги";
        // проверяем время, прошедшее с момента завески последнего извещателя
        let currentStartUpTime = (Date.now() - glVars.lastLoadedDeviceTime)/1000;
        if (currentStartUpTime < benchStatusData.selectedDevice.startUpTime){
            // последний извещатель не вышел в дежурный режим
            benchStatusData.standbyEnteringFormStatusIndicatorValue = "Выход извещателей в дежурный режим";
            benchStatusData.standbyEnteringFormTimeIndicatorValue = convertSecondsToTimeString(Math.trunc(benchStatusData.selectedDevice.startUpTime - currentStartUpTime));
            nextFunc();
        }
        else{
            // последний извещатель вышел на режим
            if (!glVars.allDeviceStandbyFlag){
                benchStatusData.standbyEnteringFormStatusIndicatorValue = "Ожидание снятия сигнала тревоги";
                benchStatusData.standbyEnteringFormTimeIndicatorValue = convertSecondsToTimeString(glVars.alarmFallingTime);
                glVars.allDeviceStandbyFlag = true;
                glVars.allDevicesStandbyTime = Date.now();
                nextFunc();
            }
            else{
                let currentAlarmFallingTime = (Date.now() - glVars.allDevicesStandbyTime)/1000;
                if (currentAlarmFallingTime < glVars.alarmFallingTime){
                    benchStatusData.standbyEnteringFormTimeIndicatorValue = convertSecondsToTimeString(Math.trunc(glVars.alarmFallingTime - currentAlarmFallingTime));
                    nextFunc();
                }
                else{
                    benchStatusData.standbyEnteringFormTimeIndicatorValue = "--";
                    benchStatusData.standbyEnteringFormStatusIndicatorValue = "Готовность к проверке";
                    benchStatusData.standbyEnteringFormPanelValue = "Нажмите кнопку \"Далее\"";
                    benchStatusData.standbyEnteringFormNextBtnEnabled = true;
                    benchStatusData.standbyCheckupFormBackBtnEnabled = false;
                    benchStatusData.standbyEnteringFormNextBtnColor = glVars.GREEN_COLOR;
                    nextFunc();
                }
            }
        }        
    }      

}