

// импорт констант и функций

const{
    IR_CHECKUP_BEFORE_RUNNING_MODE,
    LOWFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE,
    HIGHFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE,
    SOUND_ALARM_CHECKUP_BEFORE_RUNNING_MODE,
    CHECKUP_IR_AFTER_RUNNING_MODE,
    LOWFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE,
    HIGHFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE,
    SOUND_ALARM_CHECKUP_AFTER_RUNNING_MODE,
} = require("./model_constants.js");

const {
    synchronizeCell,
    getBenchStatus,
    getData
    } = require("./REST.js");

const {
        numberInArray
    } =  require("./signal_processing.js");

const {
        logger,
        getTimeString
    } = require("./logger.js");

    
const {
    convertCurrent,
    } = require("./convertations.js");




/**
 * @brief Функция главного таймера в режиме проверки работоспособности каналов
 * 
 * @param {*} glVars - объект-контейнер глобальных переменных
 * @param {*} dataObjectsAddressPull 
 * @param {*} nextFunc 
 */

//=====================================================================================================================
exports.onCheckUpModeTimer = (glVars, benchStatusData, nextFunc) => {
    getBenchStatus(glVars)
    .then((answerArray) => {
        let currentOutOfRangeFlag = false;

        const loopFunc = () => {
            if (i < glVars.NUM_CELLS){
                if (!numberInArray(i+1, glVars.faultyCellsNumArray)){
                    if (answerArray[i].errorCode === 0){
                        glVars.checkUpResults[i].LowCurrentFlag = false;
                        currentOutOfRangeFlag = false;
                        // проверяем допустимость потребляемого тока
                        if (convertCurrent(answerArray[i].cellCurrent, i+1, glVars) > glVars.shortcutCurrentThreshold){
                            if (glVars.benchMode > 14){
                                glVars.resultData[i].increaseCurrentHighCounter();
                            }                            
                            glVars.checkUpResults[i].HighCurrentFlag = true;
                            currentOutOfRangeFlag = true;
                        }
                        else{
                            if (convertCurrent(answerArray[i].cellCurrent, i+1, glVars) < glVars.currentLoadingThreshold){
                                if (glVars.benchMode >14){
                                        glVars.resultData[i].increaseCurrentLowCounter();
                                    }                            
                                glVars.checkUpResults[i].LowCurrentFlag = true;                                                                            
                                currentOutOfRangeFlag = true;
                            }
                        }

                        let IR_Relay = 1;
                        let AC_Relay = 1;
                        if (benchStatusData.selectedDevice.number_IR_Channels === 1){
                            if (benchStatusData.selectedDevice.number_AC_Channels === 1){
                                // совмещенный извещатель
                                if (benchStatusData.selectedDevice.reverseOutOrder === 0){
                                            // прямой порядок выходов
                                            IR_Relay = answerArray[i].cellRelay1;
                                            AC_Relay = answerArray[i].cellRelay2;
                                        }
                                        else{
                                            // обратный порядок выходов
                                            IR_Relay = answerArray[i].cellRelay2;
                                            AC_Relay = answerArray[i].cellRelay1;
                                        }
                            }
                            else{
                                // извещатель только с ИК каналом
                                IR_Relay = answerArray[i].cellRelay1;
                                AC_Relay = 1;
                            }
                        }
                        else{
                            // извещатель только с акустическим каналом
                            IR_Relay = 1;
                            AC_Relay = answerArray[i].cellRelay1;
                        }

                        const innerFunc = (relay, toggleColor, toggleSign, toggleLedStatus, initLedStatus, operationFlagChangingFunc) => {
                            if (glVars.checkUpResults[i].LowCurrentFlag === false){
                                if (glVars.checkUpResults[i].HighCurrentFlag === false){
                                    if (relay === 0){
                                        benchStatusData.checkupPanelCellColors[i] = toggleColor;
                                        benchStatusData.checkupPanelCellValues[i] = toggleSign;
                                        operationFlagChangingFunc();                                                   
                                        synchronizeCell(i+1,toggleLedStatus,"ON",0,glVars)
                                        .then(() => {
                                            i++;
                                            loopFunc();
                                        });
                                    }
                                    else{
                                        if (benchStatusData.checkupPanelCellValues[i] !== toggleSign){
                                        synchronizeCell(i+1,initLedStatus,"ON",0,glVars)
                                            .then(() => {
                                                i++;
                                                loopFunc();
                                            });
                                        }
                                        else{
                                            i++;
                                            loopFunc();
                                        }
                                    }
                                }
                                else{
                                    // КЗ
                                    // снимаем питание включаем красный светодиод
                                    benchStatusData.checkupPanelCellColors[i] = glVars.RED_COLOR;
                                    benchStatusData.checkupPanelCellValues[i] = "!";
                                    synchronizeCell(i+1,"RED","OFF",0,glVars)
                                    .then(() => {
                                        i++;
                                        loopFunc();
                                    });
                                }
                            }
                            else{
                                benchStatusData.checkupPanelCellColors[i] = glVars.GREY_COLOR;
                                benchStatusData.checkupPanelCellValues[i] = "L";
                                if (glVars.checkUpResults[i].HighCurrentFlag) {
                                    benchStatusData.checkupPanelCellValues[i] = "H";
                                    benchStatusData.checkupPanelCellColors[i] = glVars.RED_COLOR;
                                }           
                                synchronizeCell(i+1,"OFF","ON",0,glVars)
                                .then(() => {
                                    i++;
                                    loopFunc();
                                });
                            }  
                        }

                        switch(glVars.benchMode){
                            case IR_CHECKUP_BEFORE_RUNNING_MODE:                                
                                innerFunc(IR_Relay, glVars.GREEN_COLOR, "+", "GREEN","RED",()=>{
                                    glVars.checkUpResults[i].IR_OperationFlag = true;  
                                });                            
                                break;
                            case LOWFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE:
                                innerFunc(AC_Relay, glVars.ORANGE_COLOR, "-", "RED","GREEN",()=>{
                                    glVars.checkUpResults[i].AC_LFD_ResponseFlag = true;  
                                });
   
                                break;
                            case HIGHFREQ_DISTURB_CHECKUP_BEFORE_RUNNING_MODE:
                                innerFunc(AC_Relay, glVars.ORANGE_COLOR, "-", "RED","GREEN",()=>{
                                    glVars.checkUpResults[i].AC_HFD_ResponseFlag = true;  
                                });
    
                                break;
                            case SOUND_ALARM_CHECKUP_BEFORE_RUNNING_MODE:
                                innerFunc(AC_Relay, glVars.GREEN_COLOR, "+", "GREEN","RED",()=>{
                                    glVars.checkUpResults[i].AC_OperationFlag = true;  
                                });  
                                break;
                            case CHECKUP_IR_AFTER_RUNNING_MODE:
                                innerFunc(IR_Relay, glVars.GREEN_COLOR, "+", "GREEN","RED",()=>{
                                    glVars.resultData[i].setOperabilityIR();  
                                });   
                                break;
                            case LOWFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE:
                                innerFunc(AC_Relay, glVars.ORANGE_COLOR, "-", "RED","GREEN",()=>{
                                    glVars.resultData[i].setLFD_response();  
                                });     
                                break;
                            case HIGHFREQ_DISTURB_CHECKUP_AFTER_RUNNING_MODE:
                                innerFunc(AC_Relay, glVars.ORANGE_COLOR, "-", "RED","GREEN",()=>{
                                    glVars.resultData[i].setHFD_response();  
                                });    
                                break;
                            case SOUND_ALARM_CHECKUP_AFTER_RUNNING_MODE:
                                innerFunc(AC_Relay, glVars.GREEN_COLOR, "+", "GREEN","RED",()=>{
                                    glVars.resultData[i].setOperabilityAC();  
                                });    
                                break;
                        } 
                    }
                    else{
                        // если ячейка не ответила во время
                        if (glVars.benchMode > 14){                        
                            glVars.resultData[i].increaseCellErrorConnectionCounter();
                        }
                        benchStatusData.checkupPanelCellColors[i] = glVars.BLUE_COLOR;
                        logger(getTimeString() + "Ячейка " + (i+1) + ": ошибка связи");
                        i++;
                        loopFunc();
                    }
                }
                else{
                    i++;
                    loopFunc();
                }
            }
            else{
                // завершение работы цикла                
                if (currentOutOfRangeFlag){
                    // отключаем питание и светодиоды
                    i = 0;
                    const turnOFF_lineLEDs = () => {
                        if (i < glVars.NUM_CELLS){
                            if (!numberInArray(i+1, glVars.faultyCellsNumArray)){
                                // если ячейка не в списке незаполненных/неисправных
                                let hiCur = false;
                                let lowCur = false;
                                if (glVars.benchMode > 14){
                                    if (glVars.resultData[i].getCurrentHighCounter() > 0) hiCur =true;
                                    if (glVars.resultData[i].getCurrentLowCounter() > 0) lowCur=true;
                                }
                                else{
                                    hiCur = glVars.checkUpResults[i].HighCurrentFlag;
                                    lowCur = glVars.checkUpResults[i].LowCurrentFlag;
                                }

                                if (hiCur){
                                    // снимаем питание ячейки, включаем красный светодиод
                                    synchronizeCell((i+1), "RED", "OFF", 0, glVars)
                                    .then(() => {
                                        i++;
                                        turnOFF_lineLEDs();
                                    });
                                }
                                else{
                                    // оставляем все как есть
                                    i++;
                                    turnOFF_lineLEDs();
                                }
                            }
                            else{
                                i++;
                                turnOFF_lineLEDs();
                            }
                        }
                        else{
                            nextFunc();
                        }
                    }
                    turnOFF_lineLEDs();
                    
                }
                else{
                    nextFunc();
                }
            }

        }//end loopFunc 

        let i = 0;
        loopFunc();
    });
    
    
}