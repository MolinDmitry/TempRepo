
// импорт констант и функций

    const {
    synchronizeCell,
    synchronizePC,
    getBenchStatus,
    getData
    } = require("./REST.js");


    const {
        numberInArray,
        convertSecondsToTimeString
    } =  require("./signal_processing.js");

const {
        logger
    } = require("./logger.js");


const {
    convertCurrent,
    } = require("./convertations.js");
//=======================================================================================================
/**
 * @brief Функция таймера в режиме наработки
 * 
 */

exports.onRunningModeTimer = (glVars, benchStatusData, nextFunc) => {
    if (glVars.primaryControllerStatus.doorTS === 0){ // если дверь закрыта
        // если закрыта дверь стенда
        if (!glVars.runningStartFlag){
            if (glVars.waitingForCheckUpFlag){
                // ожидание перехода в режим контроля срабатывания после завершения наработки
                glVars.mainIndicatorStatus = "BOTH";
                glVars.mainIndicatorFlashPeriod = 1000;
                nextFunc();
            }
            else{
                // отключаем красные светодиоды (если остались)
                const loopFunc = () => {
                    if (i < glVars.NUM_CELLS){
                        if (!numberInArray(i+1, glVars.faultyCellsNumArray)){
                            synchronizeCell(i+1,"GREEN","ON",0,glVars)
                            .then((answ) => {
                                if (answ.errorCode !== 0){
                                    logger("Ошибка синхронизации ячейки " + (i+1));
                                }
                                i++;
                                loopFunc();
                            });
                        }
                        else{
                            i++;
                            loopFunc();
                        }                        
                    }
                    else{
                        // ожидаем снятия сигнала тревоги после закрытия двери 
                        if (!glVars.alarmFallingWaitingStartFlag){
                            benchStatusData.benchStatusIndicatorValue = "Ожидание снятия сигнала тревоги";
                            benchStatusData.runningTimeIndicatorValue = convertSecondsToTimeString(glVars.alarmFallingTime);
                            glVars.allDevicesStandbyTime = Date.now();
                            glVars.alarmFallingWaitingStartFlag = true;
                            glVars.mainIndicatorStatus = "BOTH";
                            glVars.mainIndicatorFlashPeriod = 1000;
                            nextFunc();
                        }
                        else{
                            let currentAlarmFallingTime = (Date.now() - glVars.allDevicesStandbyTime)/1000;
                            if (currentAlarmFallingTime < glVars.alarmFallingTime){
                                benchStatusData.runningTimeIndicatorValue = convertSecondsToTimeString(Math.trunc(glVars.alarmFallingTime - currentAlarmFallingTime));
                                nextFunc();
                            }
                            else{
                                benchStatusData.runningTimeIndicatorValue = "--";
                                benchStatusData.benchStatusIndicatorValue = "Идет наработка извещателей";  
                                // начало наработки после закрытия двери стенда
                                glVars.mainIndicatorStatus = "GREEN";
                                glVars.mainIndicatorFlashPeriod = 0;
                                glVars.runningStartFlag = true;
                                // включаем режим наработки изделий
                                glVars.runningStartTime = Date.now();
                                logger("Старт наработки извещателей");
                                benchStatusData.benchStatusIndicatorValue = glVars.BENCH_STATUS_RUNNING_IN_PROCESS_STRING;
                                benchStatusData.runningTimeIndicatorValue = 
                                        convertSecondsToTimeString(benchStatusData.selectedDevice.runningTime);
                                nextFunc();
                            }
                        }
                    }
                }
                let i = 0;
                loopFunc();                
            }
        }
        else{
           
            // если наработка была начата            
            // режим наработки
            let currentRunningTime = (Date.now() - glVars.runningStartTime)/1000;
            let upStateLoggingFlag = Math.trunc(currentRunningTime % glVars.UP_STATE_LOG_PERIOD);
            if (currentRunningTime < benchStatusData.selectedDevice.runningTime){
                // режим наработки
                // запрашиваем статус всех ячеек
                let currentOutOfRangeFlag = false;
                getBenchStatus(glVars)
                .then((answerArray) => {
                    for(let i = 0; i < glVars.NUM_CELLS; i++){
                        if (!numberInArray(i+1, glVars.faultyCellsNumArray)){
                            if (answerArray[i].errorCode === 0){
                                if (upStateLoggingFlag === 0){
                                    if (glVars.cellStatusLoggingFlag){
                                        let st = "Статус яч.№" + (i+1) + ": t " + answerArray[i].termosensorINT + " | ложн. ИК " +
                                        glVars.resultData[i].getFalseAlarmIR();
                                        if ((benchStatusData.selectedDevice.number_IR_Channels + 
                                            benchStatusData.selectedDevice.number_AC_Channels) === 2){
                                            st += " | ложн. АК " + glVars.resultData[i].getFalseAlarmAC();
                                        }
                                        st+= " | curLowCounter " + glVars.resultData[i].getCurrentLowCounter() + " | curHighCounter " +
                                        glVars.resultData[i].getCurrentHighCounter() + " | connError " + glVars.resultData[i].getCellErrorConnectionCounter();
                                        logger(st);
                                        if (i === (glVars.NUM_CELLS-1)){
                                            glVars.cellStatusLoggingFlag = false;
                                        }                                            
                                    }                                        
                                }
                                else{
                                    glVars.cellStatusLoggingFlag = true;
                                }

                                let IR_Relay = answerArray[i].cellRelay1;
                                let AC_Relay = answerArray[i].cellRelay2;
                                let falseAlarmFlag = false;
                                if (benchStatusData.selectedDevice.number_IR_Channels === 1){
                                    if (benchStatusData.selectedDevice.number_AC_Channels === 1){
                                        // совмещенный извещатель
                                        if (benchStatusData.selectedDevice.reverseOutOrder === 0){
                                            // прямой порядок выходов
                                            IR_Relay = answerArray[i].cellRelay1;
                                            AC_Relay = answerArray[i].cellRelay2;
                                        }
                                        else{
                                            // обратный порядок выходов
                                            IR_Relay = answerArray[i].cellRelay2;
                                            AC_Relay = answerArray[i].cellRelay1;
                                        }
                                        falseAlarmFlag = ((IR_Relay+AC_Relay) < 2) ? true: false;
                                    }
                                    else{
                                        // извещатель только с ИК каналом
                                        IR_Relay = answerArray[i].cellRelay1;
                                        AC_Relay = 1;
                                        falseAlarmFlag = (IR_Relay === 0) ? true: false;
                                    }
                                }
                                else{
                                    // извещатель только с акустическим каналом
                                    IR_Relay = 1;
                                    AC_Relay = answerArray[i].cellRelay1;
                                    falseAlarmFlag = (AC_Relay === 0) ? true: false;
                                }

                                if (falseAlarmFlag) {
                                    if ((IR_Relay === 0)){
                                        glVars.resultData[i].increaseFalseAlarmsIR();
                                    }
                                    if (AC_Relay === 0){
                                        glVars.resultData[i].increaseFalseAlarmsAC();
                                    }
                                    
                                    if ((benchStatusData.selectedDevice.number_IR_Channels + 
                                        benchStatusData.selectedDevice.number_AC_Channels) === 1){
                                            // одноканальный извещатель
                                            if (benchStatusData.selectedDevice.number_IR_Channels > 0){
                                                // ИК
                                                if (glVars.resultData[i].getFalseAlarmIR() > 99) 
                                                    benchStatusData.runningPanelCellValues[i] == 99;
                                                else
                                                    benchStatusData.runningPanelCellValues[i] =  glVars.resultData[i].getFalseAlarmIR();
                                            }
                                            else{
                                                //акустический
                                                if (glVars.resultData[i].getFalseAlarmAC() > 99)
                                                    benchStatusData.runningPanelCellValues[i] =  99;
                                                else
                                                    benchStatusData.runningPanelCellValues[i] =  glVars.resultData[i].getFalseAlarmAC();
                                            }
                                        
                                    }
                                    else{
                                        // двухканальный извещатель
                                        let falseAlarmsIR = glVars.resultData[i].getFalseAlarmIR() > 99 ? 99: glVars.resultData[i].getFalseAlarmIR();
                                        let falseAlarmsAC = glVars.resultData[i].getFalseAlarmAC() > 99 ? 99: glVars.resultData[i].getFalseAlarmAC();
                                        benchStatusData.runningPanelCellValues[i] = falseAlarmsIR + "-" + falseAlarmsAC;
                                    }
                                    
                                    if ((glVars.resultData[i].getCurrentHighCounter() === 0) && (glVars.resultData[i].getCurrentLowCounter() === 0)){
                                        benchStatusData.runningPanelCellColors[i] = glVars.ORANGE_COLOR;
                                    }                                             
                                }                                        
                                                                 
                                
                                if (convertCurrent(answerArray[i].cellCurrent, i+1, glVars) > glVars.shortcutCurrentThreshold){
                                    glVars.resultData[i].increaseCurrentHighCounter();
                                    benchStatusData.runningPanelCellColors[i] = glVars.RED_COLOR;
                                    currentOutOfRangeFlag = true;
                                }
                                else{
                                    if (convertCurrent(answerArray[i].cellCurrent, i+1, glVars) < glVars.currentLoadingThreshold){
                                        glVars.resultData[i].increaseCurrentLowCounter();
                                        if (glVars.resultData[i].getCurrentHighCounter() === 0){
                                            benchStatusData.runningPanelCellColors[i] = glVars.GREY_COLOR;
                                        }                                            
                                        currentOutOfRangeFlag = true;
                                    }
                                }
                            }
                            else{
                                // если ячейка не ответила во время
                                glVars.resultData[i].increaseCellErrorConnectionCounter();
                                benchStatusData.runningPanelCellColors[i] = glVars.BLUE_COLOR;
                                logger(getTimeString() + "Ячейка " + (i+1) + ": ошибка связи");
                            }
                        }
                    }
                    benchStatusData.runningTimeIndicatorValue =  
                                    convertSecondsToTimeString(Math.trunc( benchStatusData.selectedDevice.runningTime - currentRunningTime));
                    // если были обнаружены ячейки с КЗ или отсутствием потребления тока
                    if (currentOutOfRangeFlag){
                        let i = 0;
                        const turnOFF_lineLEDs = () => {
                            if (i < glVars.NUM_CELLS){
                                if (!numberInArray(i+1, glVars.faultyCellsNumArray)){
                                    // если ячейка не в списке незаполненных/неисправных
                                    if (glVars.resultData[i].getCurrentHighCounter() > 0){
                                        //
                                        // снимаем питание ячейки, включаем красный светодиод
                                        synchronizeCell((i+1), "RED", "OFF", 0, glVars)
                                        .then(() => {
                                            i++;
                                            turnOFF_lineLEDs();
                                        });
                                    }
                                    else{
                                        if (glVars.resultData[i].getCurrentLowCounter() > 0){
                                            // снимаем питание, отключаем светодиоды
                                            synchronizeCell((i+1), "OFF", "OFF", 0, glVars)
                                            .then(() => {
                                                i++;
                                                turnOFF_lineLEDs();
                                            });
                                        }
                                    }
                                }
                                else{
                                    i++;
                                    turnOFF_lineLEDs();
                                }
                            }
                            else{
                                nextFunc();
                            }
                        }
                        turnOFF_lineLEDs();                                
                    }
                    else{// во всех ячейках нет КЗ и ток в норме
                        nextFunc();
                    };                        
                });

            }
            else{
                // режим наработки завершен
                glVars.mainIndicatorStatus = "BOTH";
                glVars.mainIndicatorFlashPeriod = 1000;
                glVars.waitingForCheckUpFlag = true;
                glVars.runningStartFlag = false;
                glVars.buzzerTime = 1000;

                benchStatusData.benchStatusIndicatorValue = glVars.BENCH_STATUS_RUNNING_COMPLETE_STRING
                benchStatusData.runningTimeIndicatorValue = "--";
                
                // разблокируем кнопку "Далее"
                benchStatusData.toControlButtonEnabled = true;
                benchStatusData.toControlButtonColor = glVars.GREEN_COLOR;
                logger("Наработка извещателей завершена");
                nextFunc();
            }



        }
    }
    else{
        benchStatusData.benchStatusIndicatorValue = glVars.BENCH_STATUS_DOOR_OPEN_STRING;
        benchStatusData.runningTimeIndicatorValue = "--";
        nextFunc();
    }
};
