

/**
 * @brief
 * Класс CheckUpResultObject
 * Для хранения результатов проверки работоспособности извещателей до наработки
 * 
 * 
 */

class CheckUpResultObject{
    cellNum = 0; // номер ячейки
    IR_OperationFlag = false; // флаг работоспособности ИК канал
    AC_LFD_ResponseFlag = false; // флаг отклика на воздействие НЧ акустической помехи
    AC_HFD_ResponseFlag = false; // флаг отклика на воздействие ВЧ акустической помехи
    AC_OperationFlag = false; // флаг работоспособности акустического канала
    HighCurrentFlag = false; // флаг превышения максимального тока
    LowCurrentFlag = false; // флаг отсутствия тока потребления
    constructor (cellNum, IR_OperationFlag, AC_LFD_ResponseFlag, AC_HFD_ResponseFlag, AC_OperationFlag, HighCurrentFlag, LowCurrentFlag){
        this.cellNum = cellNum;
        this.IR_OperationFlag = IR_OperationFlag;
        this.AC_LFD_ResponseFlag = AC_LFD_ResponseFlag;
        this.AC_HFD_ResponseFlag = AC_HFD_ResponseFlag;
        this.AC_OperationFlag = AC_OperationFlag;
        this.HighCurrentFlag = HighCurrentFlag;
        this.LowCurrentFlag = LowCurrentFlag;
    }
}

exports.CheckUpResultObject = CheckUpResultObject;