# Протокол взаимодействия с REST cлужбой СУБД стенда ТЭ-1570

REST служба запущена по адресу http://localhost:3034

##  Перечень команд для чтения и сохранения информациив БД стенда

### Выполнение произвольного SQL-запроса
Адрес: http://localhost:3034/api/db_query?q=query_string
q - строка запроса в формате SQL без точки с запятой в конце
Возвращает массив JSON объектов с результатами, либо null в случае ошибки

### Запрос значения параметра конфигурации из таблицы configuration
http://localhost:3034/api/get_config_param?param=paramname&machineserial=machineserial
param - имя параметра
machineserial - серийный номер стенда, к которому применяется значение (0 - значение  применяется ко всем стендам)
Возвращает массив JSON объектов с полем parameterValue, либо null в случае ошибки

### Запрос списка всех параметров из таблицы configuration для стенда с заданным серийным номером
http://localhost:3034/api/get_configuration?machineserial=machineserial
machineserial - серийный номер стенда, к которому применяется значение (0 - значение  применяется ко всем стендам)
Возвращает массив JSON объектов, либо null в случае ошибки.

### Запрос списка устройств для отображения на экране стенда, при выборе устройства для проверки
http://localhost:3034/api/get_devicelist
Возвращает массив JSON объектов, либо null в случае ошибки.
Возвращает записи из таблицы deviceList, у которых поле actuality = 1 (либо TRUE),
т.е. возвращает перечень актуальных устройств

### Запрос данных оператора
http://localhost:3034/api/get_operatordata?id=operatorcode
id - код оператора
Возвращает JSON объект, либо null в случае ошибки.
Возвращает записи из таблицы operators

### Отправка данных на сервер для сохранения в таблице  tests
http://localhost:3034/api/post_testdata
Выполняет сохранение объекта в таблице tests
В теле HTTP POST-запроса содержится JSON-объект в текстовом виде
{
    "barcode": "504381010",
    "date_time": "2026-04-17 11:50:47",
    "productId": 1,
    "testResult": "Good",
    "operatorCode": "950202001",
    "machineSerial": 26157001,
    "cellNumber": 1
}
Возвращает JSON-объект с полем статуса statusString (success/error)

### Запрос ID-теста для заданных barcode и date_time
http://localhost:3034/api/get_test_id?barcode=barcode&date_time=date_time
Возвращает JSON-объект с полем id, либо null

### Отправка данных на сервер для сохранения в таблице  testoperations
http://localhost:3034/api/post_testoperation
Выполняет сохранение объекта в таблице testoperations
В теле HTTP POST-запроса содержится JSON-объект в текстовом виде
{
    testID: 1,
    testType: "testTypeLabel",
    testResult: "Good",
    parameterValue: 1,
    lowerLimit: 1,
    upperLimit: 4294967295
}
Значения меток для testType:
    - falseAlarmIR - количество ложных срабатываний ИК канала
    - falseAlarmAC - количество ложных срабатываний акустического канала
    - operIR - проверка работоспособности ИК канала
    - operAC - проверка работоспособности акустического канала
    - curAboveLowLim - потребляемый ток выше нижней границы допуска
    - curBelowHighLim - потребляемый ток ниже верхней границы допуска
    - connErrors - количество ошибок связи
Возвращает JSON-объект с полем статуса statusString (success/error)

### Запрос записи калибровочных данных для ячейки стенда 
http://localhost:3034/api/get_calibration?machineserial=machineserial&cellnumber=cellnumber
Возвращает массив JSON объектов, либо null в случае ошибки.
Вид возвращаемого объекта
{
    machineSerial: 1,
    cellNumber: 1,
    current_0: 0.0,
    current_ratio: 1.0
}

### Отправка данных на сервер для сохранения в таблице  calibration
http://localhost:3034/api/post_calibration
Выполняет сохранение объекта в таблице calibration
В теле HTTP POST-запроса содержится JSON-объект в текстовом виде
{
    machineSerial: 1,
    cellNumber: 1,
    current_0: 0.0,
    current_ratio: 1.0
}
Возвращает JSON-объект с полем статуса statusString (success/error)

### Обновление данных в таблице  calibration
http://localhost:3034/api/update_calibration
Выполняет обновление объекта в таблице calibration
В теле HTTP POST-запроса содержится JSON-объект в текстовом виде
{
    machineSerial: 1,
    cellNumber: 1,
    current_0: 0.0,
    current_ratio: 1.0
}
Возвращает JSON-объект с полем статуса statusString (success/error)

### Отправка лог для сохранения в БД
http://localhost:3034/api/post_log
Выполняет сохранение JSON объекта записи логгера
{
    datetime: "timestring",
    message: "log message"
}
Возвращает строку "success", либо "error"

