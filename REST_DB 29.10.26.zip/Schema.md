# Схема БД стенда ТЭ-1570

## Имя БД
b1570_db

## Перечень таблиц в БД:

Имя таблицы                 |                       Описание                                |    
configuration               | Таблица настроек стендов                                      |
devicelist                  | Список устройств и их характеристик                           |
operators                   | Данные операторов                                             |
machines                    | Данные стендов                                                |
tests                       | Таблица записей о проведенных проверках единицы изделия       |
operations                  | Таблица записей о проведенных отдельных процедурах проверок   |

## Структура таблиц

### Таблица machines
    - machineSerial  INT UNSIGNED PRIMARY KEY
    - machine VARCHAR(30)           |   (наименование стенда ТЭ-1570)
    - LOCATION VARCHAR(150)         |   (информация о местонахождении стенда)

### Таблица configuration
    - id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT
    - parameterName VARCHAR(100)
    - parameterValue VARCHAR(200)
    - machineSerial  INT UNSIGNED       | (0 - параметр применяется для всех стендов)
    - FOREIGN KEY (machineSerial) REFERENCES machines (machineSerial) 

### Таблица devicelist
    - id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT
    - deviceName VARCHAR(50)
    - productVersion VARCHAR(30)
    - firmwareVersion VARCHAR(30)
    - numberChannels TINYINT UNSIGNED
    - maxCurrentmA TINYINT UNSIGNED     | предельный потребляемый ток
    - startupTime INT UNSIGNED          | время выхода на режим, с
    - runningTime INT UNSIGNED          | время наработки, с
    - actuality BOOL                    | актуальность изделия (FALSE для временного исключения из списка выбираемых изделий)

### Таблица operators
    - operatorCode CHAR(9) PRIMARY KEY
    - firstname VARCHAR(40)                  | Имя
    - lastname  VARCHAR(40)                  | Фамилия
    - role_code  TINYINT UNSIGNED            | Код роли, 0 - инженер, 1 - оператор
    - operatorValidity BOOL                  | Действительность учетной записи оператора (FALSE - для недействительной записи)


### Таблица tests
    - id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT
    - barcode VARCHAR(30)
    - date_time DATETIME
    - productId INT UNSIGNED
    - testResult VARCHAR(30)
    - operatorCode CHAR(9)
    - machineSerial  INT UNSIGNED
    - cellNumber INT                         | номер ячейки стенда, в которую установлен извещатель
    - FOREIGN KEY (productId) REFERENCES devicelist (id) 
    - FOREIGN KEY (operatorCode) REFERENCES operators (operatorCode) 
    - FOREIGN KEY (machineSerial) REFERENCES machines (machineSerial) 



### Таблица testOperations
    - testOperationID INT UNSIGNED PRIMARY KEY AUTO_INCREMENT           | id отдельной операции проверки
    - testID INT UNSIGNED                       | id общей проверки извещателя
    - testType VARCHAR (50)                     | тип проверки
    - testResult VARCHAR (30)
    - parameterValue INT UNSIGNED 
    - lowerLimit INT UNSIGNED
    - upperLimit INT UNSIGNED
    - FOREIGN KEY (id) REFERENCES tests (id) 


### Таблица calibration
    - id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT           | id записи
    - machineSerial  INT UNSIGNED
    - cellNumber INT UNSIGNED                   | номер ячейки
    - current_0 FLOAT                           | ток покоя, мА
    - current_ratio FLOAT                       | коэффициент коррекции измеряемого тока (истинный ток = измеренный ток * current_ratio)
    - FOREIGN KEY (machineSerial) REFERENCES machines (machineSerial) 
