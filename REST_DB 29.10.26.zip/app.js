/**
 * @brief REST-служба базы данных стенда ТЭ-1570
 * 
 * 
 * - Выполняем команду инициализации проекта
 *          npm init -y
 * - Устанавливаем модуль фреймворка Express (локально)
 *          npm install express --save
 * - Устанавливаем ядро шаблонов EJS
 *          npm install ejs --save
 * - Устанавливаем пакет для взаимодействия с БД MySql 
 * (при использовании MySQL8 следует применять пакет mysql2, иначе при соединении будет возникать
 * ошибка аутентификации) * 
 *          npm install mysql2 --save
 * - устанавливаем модуль CORS для определения перечня доменов с которых разрешен доступ к сервису
 *      npm install cors --save
 * - Создаем конфигурацию запуска в VSCode: Run->Add Configuration->Node.js
 */

const main = () => {
    console.log("TE-1570 database REST-service");
    const cors = require("cors");
    const express = require("express");
    const process = require("node:process");
    const app = express(); // экземпляр web-приложения
    let appInstance = null; // ссылка на экземпляр потока прослушивания порта
    const path = require("path");

    //  настраиваем путь к директории с шаблонами страниц
    // необходимо для корректной работы при запуске не из под VSCode
    app.set('public', path.join(__dirname, "public"));
    
    // установка директории статических файлов
    app.use(express.static(path.join(__dirname, 'public')));

    app.use(cors({
        origin: "http://localhost:3000" // разрешает доступ только с localhost:3000
    }));
    
    // подключаем парсер данных для получения JSON от клиента
    app.use(express.json());

    // устанавливаем порт из переменной окружения, если там ничего нет, то порт 3000
    // по команде "PORT=3001 node app.js" в переменную окружения будет записано 
    // значение 3001 и приложение будет слушать порт 3001
    //app.set("port", process.env.PORT || 3034);
    // порт задаем в аргументах запуска
    app.set("port", process.argv[2] || 3034);

    // Создаем объект подключения к БД
    const mysql = require("mysql2");
    console.log("Connection to database");
    const connection = mysql.createConnection(
        {
            host    : "localhost",
            user    : "b1570",
            password: "gfhjkmcrk1!",
            database: "b1570_db"
        }
    );

    const performDB_Query = (queryString) => {
        return new Promise((resolve) => {
            // выполняем запрос к БД
            connection.query(queryString, (err,results,fields) => {
                if (err) 
                    {
                        console.log(err.message);
                        resolve(null);
                    }
                else{
                    if (results.length > 0){
                        results.forEach((row) => {
                        console.log(row);
                        });                        
                    }                    
                    resolve(results);
                }
            }); 
        });
    }

    // Определяем обработчики запросов к серверу
    // Обработчик GET запроса с путём /api/db_query
    // вид запроса от Web-приложения
    // http://localhost:3034/api/db_query?q=query_string
    // http://localhost:3034/api/db_query?q=SELECT%20*%20FROM%20operations 
    app.get("/api/db_query", (req,res) => {
        console.log("Query \"/api/db_query\". Sending answer ...");
        let queryString = req.query.q;
        console.log("queryString: " + queryString);
        // выполняем запрос к БД
        performDB_Query(queryString).
        then((result) => {
            res.send(result);
        });
    
    });

    // Обработчик GET запроса с путём /api/get_config_param?param=paramname&machineserial=machineserial
    app.get("/api/get_config_param", (req,res) => {
        let paramName = req.query.param;
        let machineSerial = req.query.machineserial;
        let queryString = "SELECT parameterValue FROM configuration WHERE parameterName=\'"+ paramName +
        "\' AND machineSerial=\'"+machineSerial+"\';";
        performDB_Query(queryString).
        then((result) => {
            res.send(result);
        });       
    });

    // Обработчик GET запроса с путём /api/get_configuration?machineserial=machineserial
    app.get("/api/get_configuration", (req,res) => {
        let machineSerial = req.query.machineserial;
        let queryString = "SELECT parameterName, parameterValue FROM configuration WHERE machineSerial=\'"+machineSerial+"\';";
        performDB_Query(queryString).
        then((result) => {
            res.send(result);
        });       
    });


    // Обработчик GET запроса с путём /api/get_devicelist
    app.get("/api/get_devicelist", (req,res) => {
        let queryString = "SELECT * FROM devicelist WHERE actuality=1";
        performDB_Query(queryString).
        then((result) => {
            res.send(result);
        });       
    });

    // Обработчик GET запроса с путём /api/get_operatordata?id=operatorcode
    app.get("/api/get_operatordata", (req,res) => {
        let operatorCode = req.query.id;
        let queryString = "SELECT * FROM operators WHERE operatorCode=\'" +  operatorCode + "\';";
        performDB_Query(queryString).
        then((result) => {
            res.send(result);
        });       
    });

    // Обработчик POST запроса с путём /api/post_testdata
    app.post("/api/post_testdata", (req,res) => {
        let testData = req.body;
        let queryString = "INSERT INTO tests (barcode, date_time, productId, testResult, operatorCode, machineSerial, cellNumber) " + 
        "VALUES (\'" + testData.barcode + "\', \'" + 
        testData.date_time + "\', " + testData.productId + ", \'" + 
        testData.testResult + "\', " + testData.operatorCode + ", " +
        testData.machineSerial + ", " + testData.cellNumber + ");";
        console.log(testData);
        console.log(queryString);
        performDB_Query(queryString).
        then((result) => {
            let answerObject = {
                statusString: "success"
            };
            if (result === null) answerObject.statusString = "error";
            res.send(answerObject);
        });
    });

    // Обработчик GET запроса с путём /api/get_calibration?machineserial=machineserial&cellnumber=cellnumber
    app.get("/api/get_calibration", (req,res) => {
        let cellNumber = req.query.cellnumber;
        let machineSerial = req.query.machineserial;
        let queryString = "SELECT * FROM calibration WHERE machineSerial="+ machineSerial +
        " AND cellNumber="+cellNumber+";";
        performDB_Query(queryString).
        then((result) => {
            res.send(result);
        });       
    });

    // Обработчик POST запроса с путём /api/post_calibration
    app.post("/api/post_calibration", (req,res) => {
        let calibrationData = req.body;
        let queryString = "INSERT INTO calibration (machineSerial, cellNumber, current_0, current_ratio) " + 
        "VALUES (" + calibrationData.machineSerial + ", " + 
        calibrationData.cellNumber + ", " + calibrationData.current_0 + ", " + 
        calibrationData.current_ratio + ");";
        console.log(calibrationData);
        console.log(queryString);
        performDB_Query(queryString).
        then((result) => {
            let answerObject = {
                statusString: "success"
            };
            if (result === null) answerObject.statusString = "error";
            res.send(answerObject);
        });
    });

    // Обработчик POST запроса с путём /api/update_calibration
    app.post("/api/update_calibration", (req,res) => {
        let calibrationData = req.body;
        let queryString = "UPDATE calibration " + 
        "SET current_0=" + calibrationData.current_0 + ", current_ratio=" + 
        calibrationData.current_ratio + " WHERE machineSerial=" + calibrationData.machineSerial + " AND cellNumber=" + calibrationData.cellNumber + ";";
        console.log(calibrationData);
        console.log(queryString);
        performDB_Query(queryString).
        then((result) => {
            let answerObject = {
                statusString: "success"
            };
            if (result === null) answerObject.statusString = "error";
            res.send(answerObject);
        });
    });

    // обработчик GET-запроса id теста с путём /api/get_test_id?barcode=barcode&date_time=date_time
    app.get("/api/get_test_id", (req,res) => {
        const barcode = req.query.barcode;
        const date_time = req.query.date_time;
        console.log("get_test_id");
        console.log(barcode);
        console.log(date_time);
        let queryString = "SELECT * FROM tests WHERE barcode=\'" +  barcode + "\' AND date_time=\'" + date_time +"\';";
        performDB_Query(queryString).
        then((result) => {
            if (result !== null){
                if (result.length > 0){
                    res.send({
                        "id": result[0].id
                    });
                }
                else{
                    res.send(null);
                }                
            }                
            else{
                res.send(null);
            }
        });       
    });



    // Обработчик POST запроса с путём /api/post_testoperation
    app.post("/api/post_testoperation", (req,res) => {
        let testOperationData = req.body;
        let queryString = "INSERT INTO testoperations (testID, testType, testResult, parameterValue, lowerLimit, upperLimit) " + 
        "VALUES (" + testOperationData.testID + ", \'" + 
        testOperationData.testType + "\', \'" + testOperationData.testResult + "\', " + 
        testOperationData.parameterValue + ", " + testOperationData.lowerLimit + ", " +
        testOperationData.upperLimit + ");";
        performDB_Query(queryString).
        then((result) => {
            let answerObject = {
                statusString: "success"
            };
            if (result === null) answerObject.statusString = "error";
            console.log("Result of \"" + queryString + "\": " + answerObject.statusString);
            res.send(answerObject);
        });
    });

    // Обработчик POST запроса с путём /api/post_log
    app.use("/api/post_log", express.text());
    app.post("/api/post_log", (req,res) => {
        console.log("/api/post_log");
        const body = decodeURIComponent(req.body);
        const logObj = JSON.parse(body);
        console.log(logObj);

        //res.send("succes");
        
        let queryString = "INSERT INTO b1570logs (date_time, message) " + 
        "VALUES (\'" + logObj.datetime + "\', \'" + 
        logObj.message + "\');";
        console.log(queryString);
        performDB_Query(queryString).
        then((result) => {
            let answerObject = {
                statusString: "success"
            };
            if (result === null) answerObject.statusString = "error";
            console.log("Result of \"" + queryString + "\": " + answerObject.statusString);
            res.send(answerObject);
        });
    });

    // Обработчик GET запроса с путём /dbconsole
    app.get("/dbconsole", (req, res) => {
        res.sendFile(path.join(__dirname + "/public/pages/dbconsole.html"));
    });

    // определяем функцию завершения работы приложения 
    const cleanUp = () => {
        // останавливаем сервер
        appInstance.close(() => {
            console.log("Server closing ..."); 
            // закрываем соединение
            connection.end(() => {
            console.log("Database connection is closed ...");
            });
            // завершаем процесс 
            process.exit(0);
        });       
    };

    // назначаем обработчики сигналов на завершение работы приложения
    process.on('SIGINT', () => {
        console.log('process exit on SIGINT');
        cleanUp();        
    });

    process.on('SIGQUIT', () => {
        console.log('process exit on SIGQUIT');
        cleanUp();        
    });

    process.on('SIGTERM', () => {
        console.log('process exit on SIGTERM');
        cleanUp();        
    });    

    // соединяемся с БД
    console.log("Connection ...");
    // соединяемся с базой
    connection.connect((err) => {
        if (err){
            console.error("Сonnection error " + err.stack);
            return;
        }
        console.log("Connected to database. Connection id: " + connection.threadId);

        // запускаем сервер на прослушивание порта
        appInstance = app.listen(app.get("port"), () => {
        console.log("Application started on port ", app.get("port"));
        console.log("Press Ctrl+C for application close");

        });

    }); 
    

}


// Запуск основной функции приложения
main();
