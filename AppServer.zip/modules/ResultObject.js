/**
 * @brief
 * Класс ResultObject
 * Предоставляет методы для обработки результатов наработки ячейки
 * 
 * 
 */


class ResultObject{
        // _successRunning = false;
        _cellNum = 0;
        _serialNum = 0;
        _productID = 0;
        _number_IR_Channels = 0;
        _number_AC_Channels = 0;
        _falseAlarmIR = 0;
        _falseAlarmAC = 0;
        _operateIR =  false;
        _operateAC = false;
        _LFD_response = false;
        _HFD_response = false;
        _currentLowCounter = 0;
        _currentHighCounter = 0;
        _cellErrorConnectionCounter = 0;
        _isGoodDevice = false;
        _isUnknownResult = false;
        constructor(cellNum, serialNum, productID, numberIR, numberAC){
            this._cellNum = cellNum;
            this._serialNum = serialNum;
            this._productID = productID;
            this._number_IR_Channels = numberIR;
            this._number_AC_Channels = numberAC;                
        }

        getProductID(){
            return this._productID;
        }

        getSuccessRunning(){
            return this._successRunning;
        }
        getCellNum(){
            return this._cellNum;
        }
        getSerialNum(){
            return this._serialNum;
        }

        getNumber_IR_Channels(){
            return this._number_IR_Channels;
        }

        getNumber_AC_Channels(){
            return this._number_IR_Channels;
        }

        getTotalNumberChannels(){
            return this._number_IR_Channels + this._number_AC_Channels;
        }

        getFalseAlarmIR(){
            return this._falseAlarmIR;
        }

        getFalseAlarmAC(){
            return this._falseAlarmAC;
        }

        getOperateIR(){
            return this._operateIR;
        }

        getOperateAC(){
            return this._operateAC;
        }

        getLFD_response(){
            return this._LFD_response;
        }

        getHFD_response(){
            return this._HFD_response;
        }

        getCurrentLowCounter(){
            return this._currentLowCounter;
        }

        getCurrentHighCounter(){
            return this._currentHighCounter;
        }

        getCellErrorConnectionCounter(){
            return this._cellErrorConnectionCounter;
        }

        increaseFalseAlarmsIR(){
            this._falseAlarmIR++;
        }

        increaseFalseAlarmsAC(){
            this._falseAlarmAC++;
        }

        increaseCurrentLowCounter(){
            this._currentLowCounter++;
        }

        increaseCurrentHighCounter(){
            this._currentHighCounter++;
        }

        increaseCellErrorConnectionCounter(){
            this._cellErrorConnectionCounter++;
        }

        setOperabilityIR(){
            this._operateIR = true;
        }

        setOperabilityAC(){
            this._operateAC = true;
        }

        setLFD_response(){
            this._LFD_response = true;
        }

        setHFD_response(){
            this._HFD_response = true;
        }

        resetOperabilityIR(){
            this._operateIR = false;
        }

        resetOperabilityAC(){
            this._operateAC = false;
        }

        resetLFD_response(){
            this._LFD_response = false;
        }

        resetHFD_response(){
            this._HFD_response = false;
        }

        markDeviceAsGood(){
            this._isGoodDevice = true;
        }

        demarkDeviceAsGood(){
            this._isGoodDevice = false;
        }

        markDeviceAsUnknownResult(){
            this._isUnknownResult = true;
        }

        isGoodDevice(){
            return this._isGoodDevice;
        }

        isUnknownResult(){
            return this._isUnknownResult;
        }
    }

exports.ResultObject = ResultObject;