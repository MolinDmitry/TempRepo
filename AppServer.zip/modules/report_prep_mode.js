
const {
    REPORT_MODE
} = require("./model_constants.js");

const {
    getTestIdFromDB,
    postJSON_ToDB
} = require("./REST.js");

const {
    logger
} = require("./logger.js");




//=========================================================================================================================
/**
 * @brief Функция сохранения результатов наработки в БД
 * @param {*} glVars 
 */


const saveResultsToDB = (glVars) => {
    return new Promise((resolve) => {
        // определяем время и дату завершения наработки
        const t = new Date();
        const dateTimeString = t.getFullYear() + "-" + 
        (t.getMonth()+1) + "-" + t.getDate() + " " +
        t.getHours() + ":" + t.getMinutes() + ":" + t.getSeconds();
        const testData = {
                        "barcode": "",
                        "date_time": "",
                        "productId": 0,
                        "testResult": "",
                        "operatorCode": "",
                        "machineSerial": 0,
                        "cellNumber": 0
                    };
        const testOperation = {
                        testID: 0,
                        testType: "",
                        testResult: "",
                        parameterValue: 0,
                        lowerLimit: 0,
                        upperLimit: 0
                    };
        let testID = 0;

        const loopBody = () => {
            if (glVars.resultData[i].getSerialNum() !== ""){
                // для непустой ячейки
                testData.barcode = glVars.resultData[i].getSerialNum();
                testData.date_time = dateTimeString;
                testData.productId = glVars.resultData[i].getProductID();
                testData.operatorCode = glVars.operatorCode;
                testData.machineSerial = glVars.machineSerial;
                testData.cellNumber = glVars.resultData[i].getCellNum();
                console.log();
                if (glVars.resultData[i].isUnknownResult()){
                    testData.testResult = "Unknown";
                }
                else{
                    if (glVars.resultData[i].isGoodDevice())
                        testData.testResult = "Good";
                    else
                        testData.testResult = "Bad";
                }
                // сохраняем результаты теста
                postJSON_ToDB("/api/post_testdata", testData)
                    .then((answ) => {
                        logger("Статус сохранения теста для ш/к " + glVars.resultData[i].getSerialNum() + " от " + dateTimeString + "  в БД: " + answ.statusString);
                        // запрос id сохраненного теста
                        return getTestIdFromDB(testData.barcode, testData.date_time);                                    
                    })
                    .then((answ) => {
                        testID = answ.id;
                        logger("ID сохраненного теста: " + testID);
                        logger("Ячейка: " + glVars.resultData[i].getCellNum() + ", ш/к: " + glVars.resultData[i].getSerialNum() + ", Сохранение количества ложных срабатываний ИК канала...");
                        // сохраняем результаты тестовых операций                    
                        testOperation.testID = testID;
                        testOperation.testType = "falseAlarmIR";
                        testOperation.testResult = "Good";
                        testOperation.parameterValue = glVars.resultData[i].getFalseAlarmIR();
                        testOperation.lowerLimit = 0;
                        testOperation.upperLimit = glVars.falseAlarmIR_threshold;
                        if (testOperation.parameterValue > testOperation.upperLimit) testOperation.testResult = "Bad";                        
                        return postJSON_ToDB("/api/post_testoperation", testOperation);
                    })
                    .then((answ) => {
                        logger("Результат сохранения данных: " + answ.statusString);
                        logger("Ячейка: " + glVars.resultData[i].getCellNum() + ", ш/к: " + glVars.resultData[i].getSerialNum() + ", Сохранение данных о работоспособности ИК канала...");
                        testOperation.testType = "operIR";
                        testOperation.parameterValue = glVars.resultData[i].getOperateIR();
                        testOperation.testResult = "Good";
                        testOperation.lowerLimit = 1;
                        testOperation.upperLimit = 4294967295;
                        if (testOperation.parameterValue < testOperation.lowerLimit) testOperation.testResult = "Bad";
                        return postJSON_ToDB("/api/post_testoperation", testOperation);
                    })
                    .then((answ) => {
                        logger("Результат сохранения данных: " + answ.statusString);
                        logger("Ячейка: " + glVars.resultData[i].getCellNum() + ", ш/к: " + glVars.resultData[i].getSerialNum() + ", Сохранение данных счетчика значений тока ниже порога...");
                        testOperation.testType = "curAboveLowLim";
                        testOperation.parameterValue = glVars.resultData[i].getCurrentLowCounter();
                        testOperation.testResult = "Good";
                        testOperation.lowerLimit = 0;
                        testOperation.upperLimit = 0;
                        if (testOperation.parameterValue > testOperation.upperLimit) testOperation.testResult = "Bad";
                        return postJSON_ToDB("/api/post_testoperation", testOperation);
                    })
                    .then((answ) => {
                        logger("Результат сохранения данных: " + answ.statusString);
                        logger("Ячейка: " + glVars.resultData[i].getCellNum() + ", ш/к: " + glVars.resultData[i].getSerialNum() + ", Сохранение данных счетчика значений тока выше предела...");
                        testOperation.testType = "curBelowHighLim";
                        testOperation.parameterValue = glVars.resultData[i].getCurrentHighCounter();
                        testOperation.testResult = "Good";
                        testOperation.lowerLimit = 0;
                        testOperation.upperLimit = glVars.highCurrentCounter_threshold;
                        if (testOperation.parameterValue > testOperation.upperLimit) testOperation.testResult = "Bad";
                        return postJSON_ToDB("/api/post_testoperation", testOperation);
                    })
                    .then((answ) => {
                        logger("Результат сохранения данных: " + answ.statusString);
                        logger("Ячейка: " + glVars.resultData[i].getCellNum() + ", ш/к: " + glVars.resultData[i].getSerialNum() + ", Сохранение данных счетчика ошибок соединения...");
                        testOperation.testType = "connErrors";
                        testOperation.parameterValue = glVars.resultData[i].getCellErrorConnectionCounter();
                        testOperation.testResult = "Good";
                        testOperation.lowerLimit = 0;
                        testOperation.upperLimit = glVars.errorConnectionCounter_threshold;
                        if (testOperation.parameterValue > testOperation.upperLimit) testOperation.testResult = "Bad";
                        return postJSON_ToDB("/api/post_testoperation", testOperation);
                    })
                    .then((answ) => {
                        logger("Результат сохранения данных: " + answ.statusString);
                        if (glVars.resultData[i].getTotalNumberChannels() === 2){                        
                            logger("Ячейка: " + glVars.resultData[i].getCellNum() + ", ш/к: " + glVars.resultData[i].getSerialNum() + ", Сохранение количества ложных срабатываний акустического канала...");
                            testOperation.testType = "falseAlarmAC";
                            testOperation.parameterValue = glVars.resultData[i].getFalseAlarmAC();
                            testOperation.testResult = "Good";
                            testOperation.lowerLimit = 0;
                            testOperation.upperLimit = glVars.falseAlarmAC_threshold;
                            if (testOperation.parameterValue > testOperation.upperLimit) testOperation.testResult = "Bad";
                            postJSON_ToDB("/api/post_testoperation", testOperation)
                            .then((answ) => {
                                logger("Результат сохранения данных: " + answ.statusString);
                                logger("Ячейка: " + glVars.resultData[i].getCellNum() + ", ш/к: " + glVars.resultData[i].getSerialNum() + ", Сохранение данных о работоспособности акустического канала...");
                                testOperation.testType = "operAC";
                                testOperation.parameterValue = glVars.resultData[i].getOperateAC();
                                testOperation.testResult = "Good";
                                testOperation.lowerLimit = 1;
                                testOperation.upperLimit = 4294967295;
                                if (testOperation.parameterValue < testOperation.lowerLimit) testOperation.testResult = "Bad";
                                return postJSON_ToDB("/api/post_testoperation", testOperation);
                            })
                            .then((answ) => {
                                logger("Результат сохранения данных: " + answ.statusString);
                                i++;
                                if (i < glVars.NUM_CELLS) loopBody();
                                else resolve(0);
                            });
                        }
                        else{
                            i++;
                            if (i < glVars.NUM_CELLS) loopBody();
                            else resolve(0);
                        }
                    });
            }
            else{
                i++;
                if (i < glVars.NUM_CELLS) loopBody();
                else resolve(0);
            }        
        };

        let i = 0;
        loopBody();

    });
    
}

//=========================================================================================================================
/**
 * @brief Функция таймера в режиме подготовки отчета
 * @param {*} glVars 
 * @param {*} dataObjectsAddressPull 
 * @param {*} nextFunc 
 */

exports.onReportPreparingModeTimer = (glVars, benchStatusData, nextFunc) => {
    logger("Подготовка отчета о результатах наработки");
    benchStatusData.reportFormHeaderValue = "Отчет о наработке извещателей " + 
           benchStatusData.selectedDevice.deviceName;
    benchStatusData.reportPanelIsGenerated = false;
    benchStatusData.numBadDevices = 0;
    benchStatusData.numUnknownDevices = 0;
    glVars.numEmptyCells = 0;
    benchStatusData.numCellColumn.length = 0;   
    benchStatusData.serialColumn.length = 0;
    benchStatusData.falseIR_Column.length = 0;
    benchStatusData.falseAC_Column.length = 0;
    benchStatusData.checkIR_Column.length = 0;
    benchStatusData.checkLFD_Column.length = 0;
    benchStatusData.checkHFD_Column.length = 0;
    benchStatusData.checkAC_Column.length = 0;
    benchStatusData.currentColumn.length = 0;
    benchStatusData.errorsColumn.length = 0;
    benchStatusData.resultColumn.length = 0;
    benchStatusData.falseIR_Color_Column.length = 0;
    benchStatusData.falseAC_Color_Column.length = 0;
    benchStatusData.checkIR_Color_Column.length = 0;
    benchStatusData.checkAC_Color_Column.length = 0;
    benchStatusData.current_Color_Column.length = 0;
    benchStatusData.errors_Color_Column.length = 0;
    benchStatusData.result_Color_Column.length = 0;   

   
    for (let i = 0; i < (glVars.NUM_CELLS); i++){
        let verdict = false;
        emptyCellFlag = false;
        if (glVars.resultData[i].getSerialNum() !== ""){
            // для непустой ячейки
            // определяем годность извещателя в ячейке
            if (glVars.resultData[i].getNumber_IR_Channels() > 0){
                // при наличии ИК-канала
                if ((glVars.resultData[i].getOperateIR() === true) && 
                    (glVars.resultData[i]. getFalseAlarmIR() <= glVars.falseAlarmIR_threshold) &&
                    (glVars.resultData[i].getCurrentHighCounter() <= glVars.highCurrentCounter_threshold) &&
                    (glVars.resultData[i].getCellErrorConnectionCounter() <= glVars.errorConnectionCounter_threshold)){
                        verdict = true;
                        glVars.resultData[i].markDeviceAsGood();
                }
            }
            else{
                // если извещатель имеет только акустический канал
                if ((glVars.resultData[i].getOperateAC() === true) && 
                    (glVars.resultData[i]. getFalseAlarmAC() <= glVars.falseAlarmAC_threshold) &&
                    (glVars.resultData[i].getCurrentHighCounter() <= glVars.highCurrentCounter_threshold) &&
                    (glVars.resultData[i].getCellErrorConnectionCounter() <= glVars.errorConnectionCounter_threshold) &&
                    (glVars.resultData[i].getLFD_response() === false) && 
                    (glVars.resultData[i].getHFD_response() === false)){
                        verdict = true;
                        glVars.resultData[i].markDeviceAsGood();
                }                
            }
            
            
            // уточняем годность для двухканального извещателя
            if (((benchStatusData.selectedDevice.number_IR_Channels + 
                benchStatusData.selectedDevice.number_AC_Channels) === 2))
                if ((glVars.resultData[i]. getFalseAlarmAC() > glVars.falseAlarmAC_threshold) ||
                (glVars.resultData[i].getOperateAC() === false) || 
                (glVars.resultData[i].getLFD_response() === true) || 
                (glVars.resultData[i].getHFD_response() === true)){
                    verdict = false;
                    glVars.resultData[i].demarkDeviceAsGood();
                }
                    
            
            if (!verdict){ // для негодного извещателя
                benchStatusData.numBadDevices++;
                benchStatusData.numCellColumn.push(glVars.resultData[i].getCellNum());
                benchStatusData.serialColumn.push(glVars.resultData[i].getSerialNum());

                
                (glVars.resultData[i]. getFalseAlarmIR() > glVars.falseAlarmIR_threshold) ? 
                                        benchStatusData.falseIR_Column.push("Есть"): 
                                        benchStatusData.falseIR_Column.push("Нет");
                (glVars.resultData[i]. getFalseAlarmAC() > glVars.falseAlarmAC_threshold) ? 
                                        benchStatusData.falseAC_Column.push("Есть"): 
                                        benchStatusData.falseAC_Column.push("Нет");
                (glVars.resultData[i].getOperateIR() === true) ? 
                                        benchStatusData.checkIR_Column.push("Да"): 
                                        benchStatusData.checkIR_Column.push("Нет");
                (glVars.resultData[i]. getLFD_response() === true) ?
                                        benchStatusData.checkLFD_Column.push("Нет"):
                                        benchStatusData.checkLFD_Column.push("Да");
                (glVars.resultData[i]. getHFD_response() === true) ?
                                        benchStatusData.checkHFD_Column.push("Нет"):
                                        benchStatusData.checkHFD_Column.push("Да");                
                (glVars.resultData[i].getOperateAC() === true) ? 
                                        benchStatusData.checkAC_Column.push("Да"):
                                        benchStatusData.checkAC_Column.push("Нет");
                ((glVars.resultData[i].getCurrentLowCounter() > glVars.lowCurrentCounter_threshold) || 
                    (glVars.resultData[i].getCurrentHighCounter() > glVars.highCurrentCounter_threshold)) ? 
                                        benchStatusData.currentColumn.push("Вне диап.") : 
                                        benchStatusData.currentColumn.push("Норма");
                if (glVars.resultData[i].getCellErrorConnectionCounter() > glVars.connectionErrorCounter_threshold){
                    benchStatusData.errorsColumn.push("Есть");
                    benchStatusData.numUnknownDevices++;
                    glVars.resultData[i].markDeviceAsUnknownResult();
                }
                else{
                    benchStatusData.errorsColumn.push("Нет");
                }
                                        
                                        
                // маркировка цветом
                (glVars.resultData[i]. getFalseAlarmIR() > glVars.falseAlarmIR_threshold) ? 
                                        benchStatusData.falseIR_Color_Column.push(glVars.STRONG_RED_COLOR) : 
                                        benchStatusData.falseIR_Color_Column.push(glVars.BLACK_COLOR);
                (glVars.resultData[i]. getFalseAlarmAC() > glVars.falseAlarmAC_threshold) ? 
                                        benchStatusData.falseAC_Color_Column.push(glVars.STRONG_RED_COLOR) : 
                                        benchStatusData.falseAC_Color_Column.push(glVars.BLACK_COLOR);
                (glVars.resultData[i].getOperateIR() === true) ? 
                                        benchStatusData.checkIR_Color_Column.push(glVars.BLACK_COLOR): 
                                        benchStatusData.checkIR_Color_Column.push(glVars.STRONG_RED_COLOR);
                (glVars.resultData[i]. getLFD_response() === true) ?
                                        benchStatusData.checkLFD_Color_Column.push(glVars.STRONG_RED_COLOR):
                                        benchStatusData.checkLFD_Color_Column.push(glVars.BLACK_COLOR);
                (glVars.resultData[i]. getHFD_response() === true) ?
                                        benchStatusData.checkHFD_Color_Column.push(glVars.STRONG_RED_COLOR):
                                        benchStatusData.checkHFD_Color_Column.push(glVars.BLACK_COLOR);                
                (glVars.resultData[i].getOperateAC() === true) ? 
                                        benchStatusData.checkAC_Color_Column.push(glVars.BLACK_COLOR): 
                                        benchStatusData.checkAC_Color_Column.push(glVars.STRONG_RED_COLOR);

                ((glVars.resultData[i].getCurrentLowCounter() > glVars.lowCurrentCounter_threshold) || 
                (glVars.resultData[i].getCurrentHighCounter() > glVars.highCurrentCounter_threshold)) ? 
                                        benchStatusData.current_Color_Column.push(glVars.STRONG_RED_COLOR) : 
                                        benchStatusData.current_Color_Column.push(glVars.BLACK_COLOR);
                (glVars.resultData[i].getCellErrorConnectionCounter() > glVars.connectionErrorCounter_threshold) ? 
                                        benchStatusData.errors_Color_Column.push(glVars.STRONG_RED_COLOR) :
                                        benchStatusData.errors_Color_Column.push(glVars.BLACK_COLOR);
                
                if ((glVars.resultData[i].getCurrentLowCounter() > glVars.lowCurrentCounter_threshold) || 
                    (glVars.resultData[i].getCellErrorConnectionCounter() > glVars.connectionErrorCounter_threshold)){
                    benchStatusData.resultColumn.push(glVars.REPEAT_STRING);
                    benchStatusData.result_Color_Column.push(glVars.BLUE_COLOR);
                }
                else{
                    benchStatusData.resultColumn.push("Не годен");
                    benchStatusData.result_Color_Column.push(glVars.STRONG_RED_COLOR);
                }   
                            
                                                 
            }
        }
        else{
            glVars.numEmptyCells++;
        }
    }
    
    // сохраняем результаты теста в БД   
    saveResultsToDB(glVars)
    .then(() => {
        glVars.benchMode = REPORT_MODE;
        nextFunc();
    }); 
} 
