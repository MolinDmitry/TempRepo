

// константы настроек логгирования
const SAVE_LOGS_TO_DB = true;
const SHOW_LOGS_IN_CONSOLE = true;

const logs = [];

const fs = require("fs");
const path = require("path");




/**
 * @brief Функция получения стоки времени
 */
//=======================================================================================================
const getTimeString = () => {
    let t = new Date();
    let date = (t.getDate() < 10)?("0"+t.getDate()):t.getDate();
    let mounth = (t.getMonth() < 9)?("0"+(t.getMonth()+1)):(t.getMonth()+1);
    let hours = (t.getHours() < 10)?("0"+t.getHours()):t.getHours();
    let min = (t.getMinutes() < 10)?("0"+t.getMinutes()):t.getMinutes();
    let sec = (t.getSeconds() < 10)?("0"+t.getSeconds()):t.getSeconds();

    let timeStr = t.getFullYear()  + "-" + mounth + "-" +  date  + " " + hours + ":" + min + 
    ":" + sec;
    return timeStr;
};

/**
 * @brief Функция получения стоки даты
 */
//=======================================================================================================
const getDateString = () => {
    let t = new Date();
    let date = (t.getDate() < 10)?("0"+t.getDate()):t.getDate();
    let mounth = (t.getMonth() < 9)?("0"+(t.getMonth()+1)):(t.getMonth()+1);
    let hours = (t.getHours() < 10)?("0"+t.getHours()):t.getHours();

    let dateStr = t.getFullYear() +  "-" + mounth + "-" +  date;
    return dateStr;
};


//==================================================================================================================
const postLogObjectToDB = (logObject) => {
    return new Promise((resolve) => {
        const http = require("http");
        const path = "/api/post_log";
        const body = encodeURIComponent(JSON.stringify(logObject)); // чтобы корректно передавалась кириллица
        const options = {
            hostname: "localhost",
            port: 3034,
            path: path,
            method: "POST",
            headers: {
                "Content-Type": "text/plain; charset=UTF-8",
                "Content-Length": body.length
            }
        }
        const req = http.request(options, (res) => {
            let data = "";
            res.on("data", (chunk) => {
                data += chunk;
            });
            res.on("end", () => {
                resolve(data);
            });
        })
        .on("error", (err) => {
            logger("Ошибка соединения с  localhost:3034" + path);
            console.log(err);
            resolve(null);
        })
        .end(body);
    });    
}



//=======================================================================================================
/**
 * @brief Функция удаления файлов старых логов
 *  
 */

const deleteOldLogs = () => {
    let t = new Date();
    let cur_day = t.getDate();
    let cur_mounth = t.getMonth()+1;
    let cur_year = t.getFullYear();
    const delFile = (fileName) => {
                    try{
                        fs.unlinkSync(fileName);
                        console.log("File " + fileName + " is succesfully deleted");
                    } catch (err){
                        console.log("Ошибка удаления файла " + fileName + ": ", err);
                    }
                };

    let files = fs.readdirSync(path.join(__dirname, "../logs"));
    files.forEach(file => {
        if (path.extname(file) == ".log"){
            let dateString = path.parse(file).name.split("_")[1];
            if (dateString !== undefined){
                let splitingString = dateString.split("-");
                let year = +splitingString[0];
                let mounth = +splitingString[1];
                let day = +splitingString[2];                
                if (cur_year>year){
                    delFile(path.join(__dirname, "../logs", file));
                }
                else{
                    if ((cur_mounth-mounth) > 1){
                        delFile(path.join(__dirname, "../logs", file));
                    }
                    else{
                        if ((cur_mounth-mounth) === 1){
                            if ((cur_day+(31-day))>30){
                                delFile(path.join(__dirname, "../logs", file));
                            } 
                        }
                    }
                }
            }
            else{
                delFile(path.join(__dirname, "../logs", file));
            }  
        }
        else{
            delFile(path.join(__dirname, "../logs", file));
        }  
    });

}

//=======================================================================================================

/**
 * @brief Функция сохранения логов
 * @param {*} message 
 */


const logger = (message) => {
    const timeString = getTimeString();
    // if (SHOW_LOGS_IN_CONSOLE)
    //     console.log(timeString + " " + message);
    logs.push({
        datetime: timeString,
        message: message
    });
    fs.appendFile(path.join(__dirname, "../logs", "b1570_"+ getDateString() + ".log"), timeString + " " + message + "\n", (err) => {
        if (err) {
            console.log("Ошибка при записи файла лога: ", err);
            return;
        }
    if (SHOW_LOGS_IN_CONSOLE)
        console.log(timeString + " " + message);    
    });
}

const saveLogsToDB = () => {
    return new Promise((resolve) => {
        if (SAVE_LOGS_TO_DB){
            let i = 0;
            const logsLength = logs.length;
            const loop_func = () => {
                postLogObjectToDB(logs[i])
                .then((answ) => {
                    i++;
                    if (i < logsLength){                        
                        loop_func();
                    }
                    else{
                        resolve(answ);
                    }                    
                });
            }
            loop_func();            
        }
        else{
            console.log("ВНИМАНИЕ! Сохранение логов в БД: снят флаг разрешения сохранения, логи не сохранены");
            resolve("none");
        }
    });
    
}

const clearLogsArray = () => {
    logs.length = 0;
}

const errorCodeToString = (errorCode) => {
    switch(errorCode){
        case 0: return "";
        case 1: return "Параметр запроса содержит нечисловое значение";
        case 2: return "Недопустимый диапазон адреса устройства";
        case 3: return "Получен неизвестный тип команды";
        case 4: return "Помехи на линии, несовпадение контрольной суммы пакета";
        case 5: return "Ответ от устройства не поступил за требуемое время";
        case 6: return "Регистрация устройства не удалась";
        case 7: return "Удаление устройства не удалось ";
        case 8: return "Перегрузка по току потребления (более 1А)";
        case 9: return "Высокий ток потребления (более 150 мА)";
        case 10: return "Последовательный порт закрыт";
        case 11: return "Ошибка открытия COM-порта";
        case 12: return "Ошибка при закрытии COM-порта";
        default: return ("Неизвестная ошибка. Код " + errorCode);
    }
}

exports.logger = logger;
exports.getTimeString = getTimeString;
exports.saveLogsToDB = saveLogsToDB;
exports.clearLogsArray = clearLogsArray;
exports.deleteOldLogs = deleteOldLogs;
exports.errorCodeToString = errorCodeToString;