

//импорт констант и функций

const  {
        CELL_STATUS_IDLE, 
        CELL_STATUS_SERIAL_WAITING, 
        CELL_STATUS_LOADING_WAITING,
        CELL_STATUS_12V_TURNING_ON,
        CELL_STATUS_START_RUNNING_WAITING,
        CELL_STATUS_READY,
        LOADING_MODE_NONE_SIGNAL,
        LOADING_MODE_NEXT_CELL_SIGNAL,
        LOADING_MODE_PREV_CELL_SIGNAL,
        LOADING_MODE_GOTO_CELL_SIGNAL
    } = require("./model_constants.js");

const {
    synchronizeCell,
    getBenchStatus,
    getData
    } = require("./REST.js");

const {
    logger,
    errorCodeToString
    } = require("./logger.js");

//====================================================================================
const answerProcessingDecorator = (answerObject, errorMessage, onErrorFunc, processingFunc) => {
    if (answerObject.errorCode !== 0){
        logger("Error: " + errorMessage);
        onErrorFunc();
    }
    else{
        processingFunc();
    }
}

const convertCurrent = (current, glVars) => {
    let dI = current - glVars.calibrationData[glVars.activeCellModel.activeCellNumber-1].current_0;
    let realCurrent = dI*glVars.calibrationData[glVars.activeCellModel.activeCellNumber-1].current_ratio;
    return realCurrent;
}

//====================================================================================
const onCellSyncError = (glVars, benchStatusData, nextFunc) => {
    benchStatusData.cellStatusIndicatorColor = glVars.BLUE_COLOR;
    nextFunc();
}


//===========================================================================================================
/**
 * @brief Функция перехода к ячейке с указанным номером
 * @param numCell - номер ячейки, начиная с 1
 */
const goToCell = (numCell, glVars, benchStatusData, nextFunc) => {
    const changeCell = () => {
        glVars.activeCellModel.activeCellNumber = numCell;
        if (glVars.activeCellModel.activeCellNumber === 0) {
            glVars.activeCellModel.activeCellNumber = 1;                
        }
        if (glVars.activeCellModel.activeCellNumber > glVars.NUM_CELLS) {
            glVars.activeCellModel.activeCellNumber = glVars.NUM_CELLS;                
        }
        switch (glVars.activeCellModel.activeCellNumber){
            case 1:
                benchStatusData.prevCellButtonIsVisible = false;
                benchStatusData.nextCellButtonIsVisible = true;
                break;
            case glVars.NUM_CELLS:
                benchStatusData.prevCellButtonIsVisible = true;
                benchStatusData.nextCellButtonIsVisible = false;
                break;
            default:
                benchStatusData.prevCellButtonIsVisible = true;
                benchStatusData.nextCellButtonIsVisible = true;
                break;            
        }
        
        benchStatusData.activeCellNumberInputValue = glVars.activeCellModel.activeCellNumber;
        benchStatusData.cellStatusIndicatorValue = "";            
        glVars.activeCellModel.serial = glVars.cellsCondArray[glVars.activeCellModel.activeCellNumber-1].serial;
        benchStatusData.barcodeData = glVars.activeCellModel.serial;
        benchStatusData.newData = true;
        if (glVars.cellsCondArray[glVars.activeCellModel.activeCellNumber-1].serial === ""){
            // если у новой ячейки нет серийного номера
            glVars.activeCellModel.activeCellStatus = CELL_STATUS_SERIAL_WAITING;
        }
        else{
            // если серийный есть, то переходим в режим готовности
            glVars.activeCellModel.activeCellStatus = CELL_STATUS_READY;
        } 
    }

    // в любом режиме ячейки, кроме ожидания наработки и готовности выключаем светодиоды и отключаем питание
    if ((glVars.activeCellModel.activeCellStatus === CELL_STATUS_START_RUNNING_WAITING) || 
        (glVars.activeCellModel.activeCellStatus === CELL_STATUS_READY)){
            if (glVars.activeCellModel.activeCellStatus === CELL_STATUS_START_RUNNING_WAITING){
                // при переключении ячейки в режиме ожидания старта наработки, остаемся в этом режиме
                changeCell();
                glVars.activeCellModel.activeCellStatus = CELL_STATUS_START_RUNNING_WAITING;
            }
            else{
                // в остальных режимах для новой ячейки переходим либо в ожидание ввода серийника, либо в режим готовности
                changeCell();
            }; 
    nextFunc(); 
    }
    else{
        // выключаем светодиоды на текущей ячейке
        synchronizeCell(glVars.activeCellModel.activeCellNumber,"OFF","OFF", 0, glVars)
        .then((answerObject) => {
            answerProcessingDecorator(answerObject, "Ячейка " + glVars.activeCellModel.activeCellNumber + ". Ошибка " + errorCodeToString(answerObject.errorCode) + " при выключении светодиодов", () => {
                // при ошибке
                changeCell();
                nextFunc();
            },
                () => {
                glVars.activeCellModel.line_12V = 0;
                glVars.activeCellModel.redLED = 0;
                glVars.activeCellModel.greenLED = 0;
                glVars.activeCellModel.LED_flash_period = 0;
                changeCell();
                nextFunc();
            });            
        });
    }     
}

//====================================================================================
/**
 * @brief Функция таймера в режиме завески извещателей
 */

exports.onLoadingModeTimer = (glVars, benchStatusData, nextFunc) => {
    switch(glVars.loadingModeSignal){
        case LOADING_MODE_NEXT_CELL_SIGNAL:
            // переход на следующую ячейку
            glVars.loadingModeSignal = LOADING_MODE_NONE_SIGNAL;
            logger("Переход на ячейку " + (glVars.activeCellModel.activeCellNumber + 1));
            goToCell(glVars.activeCellModel.activeCellNumber + 1, glVars, benchStatusData, nextFunc);            
            break;
        case LOADING_MODE_PREV_CELL_SIGNAL:
            // переход на предыдущую ячейку
            glVars.loadingModeSignal = LOADING_MODE_NONE_SIGNAL;
            logger("Переход на ячейку " + (glVars.activeCellModel.activeCellNumber - 1));
            goToCell(glVars.activeCellModel.activeCellNumber - 1, glVars, benchStatusData, nextFunc);
            break;
        case LOADING_MODE_GOTO_CELL_SIGNAL:
            // переход на произвольную ячейку
            glVars.loadingModeSignal = LOADING_MODE_NONE_SIGNAL;
            if (glVars.newNumCell < 1) glVars.newNumCell = 1;
            if (glVars.newNumCell > glVars.NUM_CELLS) glVars.newNumCell = glVars.NUM_CELLS;
            logger("Переход на ячейку " + (glVars.newNumCell));
            goToCell(glVars.newNumCell, glVars, benchStatusData, nextFunc);
            break;
        case LOADING_MODE_NONE_SIGNAL:
            switch(glVars.activeCellModel.activeCellStatus){
                case CELL_STATUS_SERIAL_WAITING:
                    benchStatusData.cellStatusIndicatorValue = glVars.CELL_STATUS_SERIAL_WAITING_STRING;
                    //benchStatusData.cellStatusIndicatorColor = glVars.BLUE_COLOR;
                    benchStatusData.cellSerialWaitingStatusFlag = true;
                    // вложенная функция проверки введенного штрихкода
                    const barcodeChecking = () => {
                        // проверяем наличие отсканированного штрихкода
                        if (glVars.activeCellModel.serial !== ""){
                            // проверяем введенный штрихкод на предмет дублирования ранее введенных
                            benchStatusData.serialDuplicateFlag = false;
                            for(let i = 0; i < glVars.NUM_CELLS; i++){
                                if (glVars.cellsCondArray[i].serial === glVars.activeCellModel.serial){
                                    benchStatusData.serialDuplicateFlag = true;
                                    glVars.activeCellModel.serial = "";
                                    benchStatusData.barcodeData = "";
                                    benchStatusData.newData = true;
                                }                            
                            }

                            if (!benchStatusData.serialDuplicateFlag){
                                // проверка штрихкода на допуск к наработке
                                if (glVars.activeCellModel.serial === "504381004"){
                                    // Изделие не допущено к наработке
                                    benchStatusData.wrongDeviceFlag = true;
                                    glVars.activeCellModel.serial = "";    
                                }
                                else{
                                    benchStatusData.wrongDeviceFlag = false;
                                    // Переход к режиму включения 12 В
                                    glVars.activeCellModel.activeCellStatus = CELL_STATUS_12V_TURNING_ON;
                                    logger("Включение линии 12 В ячейки " + glVars.activeCellModel.activeCellNumber);
                                }
                            }                    
                        }
                    };
                    // включаем мигание красным светодиодом
                    if (glVars.activeCellModel.redLED !== 1){
                        synchronizeCell(glVars.activeCellModel.activeCellNumber,"RED","OFF", glVars.ledFlashingPeriod, glVars)
                        .then((answerObject) => {
                            answerProcessingDecorator(answerObject, "Ячейка " + glVars.activeCellModel.activeCellNumber +". Ошибка при включении красного светодиода",
                                () => {
                                    onCellSyncError(glVars, benchStatusData, nextFunc);
                                },
                                () => {
                                    benchStatusData.cellStatusIndicatorColor = glVars.BACKGROUND_COLOR;
                                    glVars.activeCellModel.redLED = glVars.cellsCondArray[glVars.activeCellModel.activeCellNumber-1].redLED;
                                    glVars.activeCellModel.greenLED = glVars.cellsCondArray[glVars.activeCellModel.activeCellNumber-1].greenLED;
                                    glVars.activeCellModel.line_12V = glVars.cellsCondArray[glVars.activeCellModel.activeCellNumber-1].line_12V;
                                    glVars.activeCellModel.LED_flash_period = glVars.cellsCondArray[glVars.activeCellModel.activeCellNumber-1].LED_flash_period;
                                    logger("Ожидание завески ячейки " + glVars.activeCellModel.activeCellNumber);
                                    barcodeChecking();
                                    nextFunc();
                            });
                        });                
                    }
                    else{
                        barcodeChecking();
                        nextFunc();
                    }                
                    break;
                case CELL_STATUS_12V_TURNING_ON:
                    benchStatusData.cellSerialWaitingStatusFlag = false;
                    // включаем линию 12 В  и мигание зеленого светодиода         
                    if (glVars.activeCellModel.greenLED !== 1){
                        synchronizeCell(glVars.activeCellModel.activeCellNumber,"GREEN","ON", glVars.ledFlashingPeriod, glVars)
                        .then((answerObject) => {
                            answerProcessingDecorator(answerObject, "Ячейка " + glVars.activeCellModel.activeCellNumber +". Ошибка при включении напряжения питания",
                                () => {
                                    // при ошибке
                                    onCellSyncError(glVars, benchStatusData, nextFunc);
                                },
                                () => {
                                        benchStatusData.cellStatusIndicatorColor = glVars.BACKGROUND_COLOR;
                                        logger("Ожидание завески извещателя в ячейку " + glVars.activeCellModel.activeCellNumber);
                                        glVars.activeCellModel.activeCellStatus = CELL_STATUS_LOADING_WAITING; 
                                        glVars.activeCellModel.greenLED = 1;
                                        glVars.activeCellModel.redLED = 0;
                                        glVars.activeCellModel.line_12V = 1;
                                        glVars.activeCellModel.LED_flash_period = glVars.cellsCondArray[glVars.activeCellModel.activeCellNumber-1].LED_flash_period;
                                        nextFunc();
                            });              
                        });
                    }
                    else{
                        nextFunc();
                    }                      
                    break;
                case CELL_STATUS_LOADING_WAITING:
                    benchStatusData.cellStatusIndicatorValue =  glVars.CELL_STATUS_LOADING_WAITING_STRING;
                    benchStatusData.cellSerialWaitingStatusFlag = false;
                    // запрашиваем статус ячейки
                    synchronizeCell(glVars.activeCellModel.activeCellNumber,"GREEN","ON", glVars.ledFlashingPeriod, glVars)
                    .then((answerObject) => {
                        answerProcessingDecorator(answerObject, "Ячейка " + glVars.activeCellModel.activeCellNumber +". Ошибка запроса статуса",
                            () => {
                                // при ошибке
                                onCellSyncError(glVars, benchStatusData, nextFunc);
                            },
                            () => {
                                benchStatusData.cellStatusIndicatorColor = glVars.BACKGROUND_COLOR;
                                glVars.activeCellModel.current_mA = convertCurrent(answerObject.cellCurrent, glVars);
                                if (glVars.activeCellModel.current_mA > glVars.currentLoadingThreshold){ // извещатель установлен
                                    // проверяем на КЗ
                                    if (glVars.activeCellModel.current_mA > glVars.shortcutCurrentThreshold){
                                        logger("Потребляемый ток выше предела. Ячейка " + glVars.activeCellModel.activeCellNumber);
                                        // отключаем линию 12 В, включаем красный светодиод
                                        synchronizeCell(glVars.activeCellModel.activeCellNumber,"RED","OFF", 0, glVars)
                                        .then((answerObject) => {
                                            answerProcessingDecorator(answerObject, "Ячейка " + glVars.activeCellModel.activeCellNumber +". Ошибка включения светодиода при КЗ",
                                                () => {
                                                    // при ошибке
                                                    onCellSyncError(glVars, benchStatusData, nextFunc);
                                                }, 
                                                () => {
                                                glVars.activeCellModel.activeCellStatus = CELL_STATUS_IDLE;
                                                glVars.activeCellModel.greenLED = 0;
                                                glVars.activeCellModel.redLED = 1;
                                                glVars.activeCellModel.line_12V = 0;
                                                glVars.activeCellModel.LED_flash_period = 0;
                                                setTimeout(() => {
                                                    // выдаем сигнал зуммера
                                                    getData("localhost", "3030","/te1570/exec?command=sync_pc&address=220&led_status=0&led_flash_period=0&buzzer_time=20&relay_status=0")
                                                    .then((answerObject) => {
                                                        answerProcessingDecorator(answerObject, "Ячейка " + glVars.activeCellModel.activeCellNumber +". Ошибка включения зуммера при КЗ",
                                                            () => {
                                                                // при ошибке
                                                                onCellSyncError(glVars, benchStatusData, nextFunc);
                                                            }, 
                                                            () => {
                                                            benchStatusData.cellStatusIndicatorColor = glVars.BACKGROUND_COLOR;
                                                            // устанавливаем флаг короткого замыкания
                                                            benchStatusData.shortcutFlag = true;
                                                            nextFunc();
                                                        });
                                                    });
                                                },  glVars.SPACE_TIME);
                                                
                                            });
                                        });                                
                                    }
                                    else{
                                        // ток в норме
                                        // фиксируем время завески извещателя (в мс от 1.01.1970).
                                        glVars.lastLoadedDeviceTime = Date.now();
                                        // включаем постоянное свечение зеленый светодиод
                                        synchronizeCell(glVars.activeCellModel.activeCellNumber,"GREEN","ON", 0, glVars)
                                        .then((answerObject) => {
                                            answerProcessingDecorator(answerObject, "Ячейка " + glVars.activeCellModel.activeCellNumber +". Ошибка включения зеленого светодиода",
                                                () => {
                                                    // при ошибке
                                                    onCellSyncError(glVars, benchStatusData, nextFunc);
                                                },
                                                () => {
                                                benchStatusData.cellStatusIndicatorColor = glVars.BACKGROUND_COLOR;
                                                glVars.activeCellModel.greenLED = 1;
                                                glVars.activeCellModel.redLED = 0;
                                                glVars.activeCellModel.LED_flash_period = 0;
                                                // сохраняем серийный номер в массиве состояния ячейки
                                                glVars.cellsCondArray[glVars.activeCellModel.activeCellNumber-1].serial = glVars.activeCellModel.serial;                            
                                                glVars.activeCellModel.activeCellStatus = CELL_STATUS_READY;
                                                logger("Извещатель установлен в ячейку " + glVars.activeCellModel.activeCellNumber);
                                                // разблокируем кнопку завершения завески
                                                benchStatusData.finishLoadingButtonEnabled = true;
                                                // после сохранения ячейки
                                                // проверяем полную заполненность стенда
                                                let numFirstEmptyCell = 0; // номер первой незаполненной ячейки
                                                let numFirstEmptyCellAfterCurrent = 0; // номер первой незаполненной ячейки после текущей
                                                for (let i = 1; i <= glVars.NUM_CELLS; i++){
                                                    if (glVars.cellsCondArray[i-1].serial === ""){
                                                        if (numFirstEmptyCell === 0) numFirstEmptyCell = i;
                                                        if (i > (glVars.activeCellModel.activeCellNumber-1) && (numFirstEmptyCellAfterCurrent === 0)){
                                                            numFirstEmptyCellAfterCurrent = i;
                                                        }
                                                    }
                                                    if ((numFirstEmptyCell > 0) && (numFirstEmptyCellAfterCurrent > 0))
                                                        break;  
                                                }
                                                if (numFirstEmptyCell === 0){
                                                    // если все ячейки заполнены, переходим в режим ожидания старта наработки
                                                    glVars.activeCellModel.activeCellStatus =  CELL_STATUS_START_RUNNING_WAITING;
                                                    nextFunc();

                                                }
                                                else{
                                                    // переход к следующей ячейке, если не в режиме замены неисправного извещателя
                                                    if (!glVars.removingBadDeviceFlag){                                                
                                                        // если есть незаполненные ячейки                                              
                                                        if (numFirstEmptyCellAfterCurrent > 0){
                                                            // если есть незаполненные ячейки, то переходим к следующей незаполненной от текущей
                                                            goToCell(numFirstEmptyCellAfterCurrent, glVars, benchStatusData, nextFunc);
                                                        }
                                                        else{
                                                            // если от текущей до конца все ячейки заполнены, то переходим к первой незаполненной от первой ячейки
                                                            goToCell(numFirstEmptyCell, glVars, benchStatusData, nextFunc);
                                                        }                                                    
                                                    }
                                                    else{// в режиме замены извещателя
                                                        glVars.removingBadDeviceFlag = false;
                                                        // остаемся на текущей ячейке в режиме готовности 
                                                        glVars.activeCellModel.activeCellStatus = CELL_STATUS_READY;
                                                        nextFunc();
                                                    }                                                
                                                }                                        
                                            });
                                        });                            
                                    }
                                }// извещатель не установлен
                                else{
                                    nextFunc();
                                }
                        }); 
                    });
                    
                break;
                case CELL_STATUS_READY:                    
                    benchStatusData.cellStatusIndicatorValue =  glVars.CELL_STATUS_READY_STRING;
                    benchStatusData.cellSerialWaitingStatusFlag = false;
                    // обновляем индикацию
                    let curCellIndex = glVars.activeCellModel.activeCellNumber-1;
                    let ledStatusString = "OFF";
                    if (glVars.cellsCondArray[curCellIndex].redLED === 1)  ledStatusString = "RED";
                    else if (glVars.cellsCondArray[curCellIndex].greenLED === 1) ledStatusString = "GREEN";
                    let lineStatus = "OFF";
                    if (glVars.cellsCondArray[curCellIndex].line_12V === 1) lineStatus = "ON";
                    synchronizeCell(glVars.activeCellModel.activeCellNumber, ledStatusString, lineStatus, glVars.cellsCondArray[curCellIndex].LED_flash_period, glVars)
                    .then((answerObject) => {
                        answerProcessingDecorator(answerObject, "Ячейка " + glVars.activeCellModel.activeCellNumber +". Ошибка синхронизации ячейки",
                        () => {
                            // при ошибке
                            onCellSyncError(glVars, benchStatusData, nextFunc);
                        },
                        () => {
                            benchStatusData.cellStatusIndicatorColor = glVars.BACKGROUND_COLOR;
                            nextFunc();
                        });
                    });
                    
                    break;
                case CELL_STATUS_START_RUNNING_WAITING:
                    benchStatusData.finishLoadingButtonEnabled = false;
                    benchStatusData.cellSerialWaitingStatusFlag = false;
                    // опрос статуса стенда
                    getBenchStatus(glVars)
                    .then((answerArray) => {
                        let i = 0;
                        let answerArrayLength = answerArray.length;

                        //  функция проверки завески
                        const checkLoading = () => {
                            // let startRunningButton = document.getElementById("startRunningButton");
                            // проверяем заполненность ячеек
                            // у ячейки должно быть: серийный номер, включено питание, ток в допустимых пределах
                            // очищаем массив неисправных ячеек
                            glVars.faultyCellsNumArray.length = 0;
                            for(let j = 0; j < glVars.NUM_CELLS; j++){
                                if (
                                    !((glVars.cellsCondArray[j].serial !== "") && 
                                    (glVars.cellsCondArray[j].line_12V === 1) && 
                                    (glVars.cellsCondArray[j].current_mA > glVars.currentLoadingThreshold) &&
                                    (glVars.cellsCondArray[j].current_mA < glVars.shortcutCurrentThreshold))
                                ){ // ячейка неисправна или заполнена неисправным извещателем
                                    logger("Обнаружена несправная ячейка " + j + " ток " + glVars.cellsCondArray[j].current_mA + " линия 12В: " + glVars.cellsCondArray[j].line_12V);
                                    glVars.faultyCellsNumArray.push(j+1);
                                }
                            }

                            if (glVars.faultyCellsNumArray.length === glVars.NUM_CELLS){ // нет заполненных ячеек
                                benchStatusData.cellStatusIndicatorValue =  glVars.CELL_STATUS_START_RUNNING_WAITING_STRING_3;
                                // блокируем кнопку
                                benchStatusData.startStandbyEnteringButtonEnabled = false;
                                benchStatusData.startStandbyEnteringButtonColor =  glVars.BACKGROUND_COLOR;
                            }
                            else{
                                // разблокируем кнопку начала процесса наработки
                                // разблокируем кнопку перехода к наработке
                                if (benchStatusData.startStandbyEnteringButtonEnabled === false){
                                    logger("Ожидание нажатия кнопки старта выхода в дежурный режим");
                                }                                
                                benchStatusData.startStandbyEnteringButtonEnabled = true;                              
                                if (glVars.faultyCellsNumArray.length === 0){
                                    // все ячейки заполнены
                                    benchStatusData.cellStatusIndicatorValue =  glVars.CELL_STATUS_START_RUNNING_WAITING_STRING_1;
                                    benchStatusData.startStandbyEnteringButtonColor =  glVars.GREEN_COLOR;
                                }
                                else{
                                    benchStatusData.cellStatusIndicatorValue =  glVars.CELL_STATUS_START_RUNNING_WAITING_STRING_2;
                                    benchStatusData.startStandbyEnteringButtonColor =  glVars.ORANGE_COLOR;
                                }                            
                            }
                            nextFunc();
                        }

                        const runCycle = () => {
                            answerProcessingDecorator(answerArray[i], "Loading mode E07", nextFunc,
                            () => {
                                // обновляем значение ячейки в массиве состояния ячеек 
                                glVars.cellsCondArray[answerArray[i].deviceAddress-1].current_mA = convertCurrent(answerArray[i].cellCurrent, glVars);
                                glVars.cellsCondArray[i].line_12V = answerArray[i].line12Vstatus;

                                if (glVars.cellsCondArray[i].line_12V === 1){    
                                // если питание ячейки присутствует
                                    if (convertCurrent(answerArray[i].cellCurrent, glVars) > glVars.shortcutCurrentThreshold){
                                        logger("Потребляемый ток ячейки " + glVars.activeCellModel.activeCellNumber + " выше предела");
                                        // отключаем линию 12 В, включаем красный светодиод
                                        synchronizeCell(answerArray[i].deviceAddress,"RED","OFF", 0, glVars)
                                        .then((answerObject) => {
                                            answerProcessingDecorator(answerObject, "Loading mode E08", nextFunc, 
                                                () => {
                                                if (i < answerArrayLength){
                                                    runCycle();                                                                                              
                                                } 
                                                else{
                                                    checkLoading();
                                                }
                                            });
                                        });
                                    }
                                    else{// если ток ниже порога - значит неконтакт
                                        if (convertCurrent(answerArray[i].cellCurrent, glVars) < glVars.currentLoadingThreshold){ 
                                            logger("Ячейка " + glVars.activeCellModel.activeCellNumber + " ток(" + convertCurrent(answerArray[i].cellCurrent, glVars) +") меньше порога");                                  
                                            //отключаем зеленый светодиод
                                            synchronizeCell(answerArray[i].deviceAddress,"OFF","ON", 0, glVars)
                                            .then((answerObject) => {
                                                answerProcessingDecorator(answerObject, "Loading mode E08", nextFunc,
                                                    () => {
                                                    i++;  
                                                    if (i < answerArrayLength){
                                                        runCycle();                                                                                              
                                                    } 
                                                    else{
                                                        checkLoading();
                                                    }
                                                });
                                            });              
                                        }
                                        else{// если ток в норме оставляем все как есть
                                            i++;
                                            if (i < answerArrayLength){                                         
                                                runCycle();
                                            }
                                            else{
                                                checkLoading();
                                            } 
                                        }
                                    }
                                }
                                else{
                                    // если питание ячейки выключено
                                    i++;
                                    if (i < answerArrayLength){                                         
                                        runCycle();
                                    }
                                    else{
                                        checkLoading();
                                    }
                                }
                            });
                        };
                        // обновляем  массив состояния ячеек рекурсивно               
                        runCycle();
                    });           
                    
                    break;
                case CELL_STATUS_IDLE:
                    benchStatusData.cellSerialWaitingStatusFlag = false;
                    nextFunc(); 
                    break;
            }
            break;
    }  
}
exports.goToCell = goToCell;
exports.convertCurrent = convertCurrent;