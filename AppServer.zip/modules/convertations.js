




const convertCurrent = (current, glVars) => {
    let dI = current - glVars.calibrationData[glVars.activeCellModel.activeCellNumber-1].current_0;
    let realCurrent = dI*glVars.calibrationData[glVars.activeCellModel.activeCellNumber-1].current_ratio;
    realCurrent = Math.round(realCurrent*100)/100;
    return realCurrent;
}

exports.convertCurrent = convertCurrent;