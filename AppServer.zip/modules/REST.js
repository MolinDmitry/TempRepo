/**
 * @brief Модуль функций взаимодействия с REST-сервисом драйвера стенда
 * 
 * 
 * 
 */


const {
    logger
} = require("./logger.js");

const {
        convertCurrent
    } = require("./loading_mode.js");

//===========================================================================================================
    /**
     * @brief Обновление состояния ячейки в массиве
     * 
     * 
    */

const updateCellCondArray = (address, answerObject, globalVars) => {
    if (address <= globalVars.NUM_CELLS){
        globalVars.cellsCondArray[address-1].line_12V = answerObject.line12Vstatus;
        globalVars.cellsCondArray[address-1].current_mA = convertCurrent(answerObject.cellCurrent, globalVars)
        globalVars.cellsCondArray[address-1].redLED = answerObject.LED1status;
        globalVars.cellsCondArray[address-1].greenLED = answerObject.LED2status;
        globalVars.cellsCondArray[address-1].LED_flash_period = answerObject.LEDflashPeriod;             
    }    
}

//===========================================================================================================

const getData = (hostname, port, path) => {
    return new Promise((resolve) => {
        const http = require("http");
        const options = {
            hostname: hostname,
            port: port,
            path: path,
            method: "GET"
        }
        const req = http.request(options, (res) => {
            let data = "";
            res.on("data", (chunk) => {
                data += chunk;
            });
            res.on("end", () => {
                resolve(JSON.parse(data));
            });
        })
        .on("error", (err) => {
            //console.log(err);
            logger("Ошибка соединения с  " + hostname + ":" + port + path);
        })
        .end();
    });
       
}


//===========================================================================================================
/**
 * @brief Синхронизирует состояние ячейки
 * 
 * @param address - адрес
 * @param LED_status - статус светодиодов ("RED", "GREEN", "BOTH", "OFF")
 * @param lineStatus - статус линии 12 В ("ON", "OFF")
 * @param LED_flashPeriod - период мигания светодиода, 0 - включен постоянно, 1 ед. = 10 мс
 */

const synchronizeCell = (address, LED_status, lineStatus, LED_flashPeriod, glVars) => {
    let ledStatus = 0;
    let redLEDstatus = 0;
    let greenLEDstatus = 0;
    switch(LED_status){
        case "RED":
            ledStatus = 192;
            redLEDstatus =  1;
            break;
        case "GREEN":
            ledStatus = 48;
            greenLEDstatus = 1;
            break;
        case "BOTH":
            ledStatus = 240;
            redLEDstatus =  1;
            greenLEDstatus = 1;
            break;
    }
    let line_status = 0;
    if (lineStatus === "ON") line_status = 6;
    let pathString  = "/te1570/exec?command=sync&address=" 
    + address + "&led_status=" + ledStatus + 
    "&line_status=" + line_status + "&led_flash_period=" + LED_flashPeriod;
    return new Promise((resolve) => {
        setTimeout(() => {
            getData("localhost", "3030", pathString)
            .then((answerObject) => {
                updateCellCondArray(address, answerObject, glVars);
                if (address === 255){
                   for(let i = 0; i < glVars.NUM_CELLS; i++){                        
                        glVars.cellsCondArray[i].line_12V = (line_status > 0) ? 1: 0;                        
                        glVars.cellsCondArray[i].greenLED = greenLEDstatus;
                        glVars.cellsCondArray[i].redLED = redLEDstatus;  
                        glVars.cellsCondArray[i].LED_flash_period = 0;                     
                    }
                }
                resolve(answerObject);
            });
        }, glVars.SPACE_TIME);
        
    });
   
}


//===========================================================================================================
/**
 * @brief Синхронизирует состояние первичного контроллера
 * Одновременное включение красного и зеленого светодиодов соответсвует желтому цвету
 * 
 * @param LED_status - статус цвета основного индикатора стенда ("RED", "GREEN", "BOTH", "OFF")
 * @param LED_flashPeriod - период мигания основного индикатора, 0 - включен постоянно, 1 ед. = 1 мс
 * @param buzzer_time - 0 - зуммер выключен, 1 ед. = 1 мс
*/


//getData("localhost", "3030","/te1570/exec?command=sync_pc&address=220&led_status=0&led_flash_period=0&buzzer_time=2&relay_status=0")
const synchronizePC = (LED_status, LED_flashPeriod, buzzer_time, glVars) => {
    let ledStatus = 0;
    //let redLEDstatus = 0;
    //let greenLEDstatus = 0;
    switch(LED_status){
        case "RED":
            ledStatus = 192;
            //redLEDstatus =  1;
            break;
        case "GREEN":
            ledStatus = 12;
            //greenLEDstatus = 1;
            break;
        case "BOTH":
            ledStatus = 204;
            //redLEDstatus =  1;
            //greenLEDstatus = 1;
            break;
    }
    let pathString  = "/te1570/exec?command=sync_pc&address=220&led_status=" + ledStatus + 
    "&led_flash_period=" + LED_flashPeriod/10 + 
    "&buzzer_time=" + buzzer_time/50 + "&relay_status=" +  glVars.relayStatus;
    return new Promise((resolve) => {
        setTimeout(() => {
            getData("localhost", "3030", pathString)
            .then((answerObject) => {
                resolve(answerObject);
            });
        }, glVars.SPACE_TIME);
        
    });
   
}




//===========================================================================================================
const getBenchStatus = (glVars) => {
    return new Promise((resolve) => {
        let cellAddress = 1;
        let answer = [];
        const getCellStatus = () =>{
            let LED_status = "OFF";
            let line_status = "OFF";
            let flash_period = 0;
            if (cellAddress <= glVars.NUM_CELLS){
                if ((glVars.cellsCondArray[cellAddress-1].redLED === 1) && (glVars.cellsCondArray[cellAddress-1].greenLED === 0)) LED_status = "RED";
                if ((glVars.cellsCondArray[cellAddress-1].greenLED === 1) && (glVars.cellsCondArray[cellAddress-1].redLED === 0)) LED_status = "GREEN";
                if ((glVars.cellsCondArray[cellAddress-1].greenLED === 1) && (glVars.cellsCondArray[cellAddress-1].redLED === 1)) LED_status = "BOTH"; 
                if (glVars.cellsCondArray[cellAddress-1].line_12V === 1) line_status = "ON";
                flash_period = glVars.cellsCondArray[cellAddress-1].LED_flash_period;           
            }
            
            
            synchronizeCell(cellAddress, LED_status, line_status, flash_period, glVars)
            .then((answerObject) => {
                answer.push(Object.assign({}, answerObject));// assign копирует все поля answerObject[0] в пустой объект и возвращает новый объект
                cellAddress++;
                if (cellAddress <= glVars.NUM_CELLS){
                   getCellStatus();                    
                }
                else{
                    resolve(answer);
                }
            });     
        };
        getCellStatus();
    });
        
}

//=======================================================================================================
/**
 * @brief Возврщает значение параметра из БД
 * @param paramName  - имя параметра
 * @param machineSerial - серийный номер стенда (0 - значение параметра применяется ко всем стендам)
 */
const getParamValueFromDB = (paramName, machineSerial) => {
    return new Promise((resolve) => {
        const pathString = "/api/get_config_param?param=" + paramName + "&machineserial=" + machineSerial;
        getData("localhost", "3034", pathString)
        .then((answerArray) => {
            if (answerArray !== null){
                if (answerArray.length > 0){
                    resolve(answerArray[0].parameterValue);
                }
                else{
                    logger("Ошибка чтения параметра  " + paramName + " из БД");
                    resolve("");
                }
            }
        });
    });    
}

//==================================================================================================================
const getConfigurationFromDB = (machineSerial) => {
    return new Promise((resolve) => {
        const pathString = "/api/get_configuration?machineserial=" + machineSerial;
        getData("localhost", "3034", pathString)
        .then((answerArray) => {
            if (answerArray !== null){
                if (answerArray.length > 0){
                    resolve(answerArray);
                }
                else{
                    logger("Ошибка чтения значения параметров конфигурации для стенда  " + machineSerial + " из БД");
                    resolve(null);
                }
            }
            else{
                logger("Ошибка соединения с REST-службой драйвера БД");
                resolve(null);
            }
        });
    });    

}

//==================================================================================================================
const getDeviceListFromDB = () => {
    return new Promise((resolve) => {
        const pathString = "/api/get_devicelist";
        getData("localhost", "3034", pathString)
        .then((answerArray) => {
            if (answerArray !== null){
                if (answerArray.length > 0){
                    resolve(answerArray);
                }
                else{
                    logger("Ошибка получения списка устройств из БД");
                    resolve(null);
                }
            }
        });
    });  
    
}

//==================================================================================================================
const getOperatorDataFromDB = (operatorCode) => {
    return new Promise((resolve) => {
        const pathString = "/api/get_operatordata?id=" + operatorCode;
        logger("Запрос данных оператора с кодом " + operatorCode);
        getData("localhost", "3034", pathString)
        .then((answerArray) => {
            if (answerArray !== null){
                if (answerArray.length > 0){
                    resolve(answerArray[0]);
                }
                else{
                    logger("Оператор с кодом " + operatorCode + " отсутствует в БД или его учетная запись не актуальна");
                    resolve(null);
                }
            }
        });
    });  
}


//==================================================================================================================
const postJSON_ToDB = (path, jsonObject) => {
    return new Promise((resolve) => {        
        const http = require("http");
        const options = {
            hostname: "localhost",
            port: 3034,
            path: path,
            method: "POST",
            headers: {
                "Content-Type": "application/json; charset=UTF-8",
                "User-Agent": "Node.js"
            }
        }
        options.headers["Content-Length"] = JSON.stringify(jsonObject).length;
        const req = http.request(options, (res) => {
            let data = "";
            res.on("data", (chunk) => {
                data += chunk;
            });
            res.on("end", () => {                
                resolve(JSON.parse(data));      
            });
        })
        .on("error", (err) => {
            logger("Ошибка соединения с  localhost:3034" + path);
            console.log(err);
            resolve(null);
        });
        req.write(JSON.stringify(jsonObject));
        req.end();
    });
}



//==================================================================================================================
const getTestIdFromDB = (barcode, date_time) => {
    return new Promise((resolve) => {
        const pathString = "/api/get_test_id?barcode=" + barcode + "&date_time=" + encodeURIComponent(date_time);
        logger("Запрос id теста для извещателя " + barcode + " и времени " + date_time);
        getData("localhost", "3034", pathString)
        .then((answ) => {
            if (answ !== null){
                    resolve(answ);                   
                }
                else{
                    logger("Ошибка получения id теста для извещателя " + barcode + " и времени " + date_time);
                    resolve(null);                 
                }
        });

    });
}




exports.getData = getData;
exports.getBenchStatus = getBenchStatus;
exports.synchronizeCell = synchronizeCell;
exports.synchronizePC = synchronizePC;
exports.getParamValueFromDB = getParamValueFromDB;
exports.getConfigurationFromDB = getConfigurationFromDB;
exports.getDeviceListFromDB = getDeviceListFromDB;
exports.getOperatorDataFromDB = getOperatorDataFromDB;
exports.postJSON_ToDB = postJSON_ToDB;
exports.getTestIdFromDB = getTestIdFromDB;



